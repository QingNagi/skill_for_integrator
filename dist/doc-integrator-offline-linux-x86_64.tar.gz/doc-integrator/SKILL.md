---
name: doc-integrator
description: Use when filling a Word template from specs, scanned PDFs or test data with source citations. 按批注摘抄、填表，可离线识别中英文扫描页。Do not use for standalone summaries.
metadata:
  author: QingNagi
  tags: "word, document-integration, source-tracing, verification-records"
---

# 文档整合助手

## Purpose

从规范、任务书或测试数据中摘取内容，按批注、章节或记录行填入 Word 模板。交付可溯源的草稿和审核报告，用户确认后生成终稿。原文件只读，默认输出到发起任务时当前工作目录下的 `整合输出/`。

## Prerequisites

保留调用者当前工作目录。Claude Code 中本技能目录为 `${CLAUDE_SKILL_DIR}`；其他宿主用已加载的 SKILL.md 所在目录。用户指定项目内的 skill 时优先使用该项目入口。只定位一次，后续命令复用同一入口和任务目录。 项目已部署时，Claude 的 Bash 工具可直接执行 `bash .claude/skills/doc-integrator/run.sh …`。同名个人版和项目版并存时，沿用用户指定的项目入口。

| 运行环境 | 执行下文的 DI |
|---|---|
| Windows 项目离线包，PowerShell | `& "<技能目录>/run.ps1" <子命令> ...` |
| Windows Git Bash 或 Linux 的 Claude Bash 工具 | `bash "<技能目录>/run.sh" <子命令> ...`。两种发布包的 Bash 入口相同。 |
| GNU/Linux x86_64 或 aarch64 离线包 | `bash "<技能目录>/run.sh" <子命令> ...` |
| 展开版或源码 | 有内置解释器时用它执行 `scripts/di.py`；纯源码用本机 Python 3.8+。 |

入口会自行完成首次部署。同版已就绪即执行原命令。`doctor` 只在用户要求检查或遇到运行故障时使用。模板和来源需可读，输出目录需可写。旧格式转换与 DOC/PDF 导出使用本机的办公软件。[依赖说明](vendor/README.md)

## Available Scripts

| Script | Purpose | Arguments |
|---|---|---|
| `scripts/di.py` | 检查环境，或单独验证已有 DOCX/XLSX 的结构 | `doctor` 或 `doctor --selfcheck 文件` |
| `scripts/di.py` | 建任务并生成映射方案 | `run -t 目标 -s 来源 --task 用户原话`，多来源重复 `-s` |
| `scripts/di.py` | 核对指定来源、记录回答、交付文稿 | `show 任务目录 引用`、`answer 任务目录 Q编号=选项号`、`draft/review/final 任务目录`（每次选一个子命令） |

文件参数相对于当前工作目录解析。任务有多个来源时，逐个传入文件路径。

## Instructions

1. **选文件。** 路径已经给全，直接进入任务。只给文件名时，在指定输入目录运行 `find 文件名 --exact --dir 目录`；多个名称可一次传入。若路径、批次仍不唯一，列出候选路径，立即等用户选择。只有用户指定时才将成品示例作为来源。
2. **建任务与核对。** 用一次 `run -t 模板 -s 来源 --task 用户原话` 完成建任务和规划，读取它返回的任务路径、待确认项和引用。将不同来源的引用合并到一次 `show 任务目录 引用1 引用2 --full`；可用 `S1:page1` 回读整页 PDF。来源查不到或规划与请求不符时，再用 `outline/search` 和 [手工操作](reference/手工操作.md)。一次 CLI 调用已给出的结论直接用于下一步。只有需要排查具体差异时才展开 XML 或阅读实现。宿主使用 Python 包装命令时可用 `from subprocess import run as run_script`，以 `run_script(argv, check=True)` 执行同一入口。
3. 将实际待确认问题和选项交给用户，每批最多四题。Claude Code 可用 `questions --ask-json` 生成表单，用选项描述里的原编号记录回答。其他环境显示任务目录内的 `questions.md`。来源所属批次、样品号无交集、取值方式冲突或字段无来源时，由用户决定。数字相近不能确认来源；保留超限实测值和警告，0/1 标志不作测量值。用 `answer` 记录用户的实际选择，重规划后核对新问题。文件换版重新确认，各任务的回答按版本保存。仅在用户要求记住对应规则时加 `--remember`。[规则与提问](reference/规则与提问.md)
4. 运行 `draft`，确认命令输出了草稿路径。使用草稿自带的结构检查和审核报告核对结果。成功后交付，仅遇到警告或用户指定时再做额外检查。只有用户同意按推荐出草稿时才用 `--defaults`，默认值只对本版草稿有效。交付 DOCX、来源快照位置和 `审核报告.md`，报出未填、原有值未核和未读项的实际数量。旧值保持原样并提示本批未核。请用户打开批注核对来源，修改或加批注后保存并关闭。
5. 有修改意见时用 `review` 读取，按意见调整后重新 `draft`。新草稿会尝试并入上版的直接修改和批注；核对合并摘要和冲突，向用户说明未能带入的修改。只有用户明确要舍弃修改时才使用 `--discard-edits`。
6. 用户确认后运行 `final`。有审核人批注时由用户选择 `--reviewer-comments keep` 或 `drop`。若终稿被拦，按 `终稿拦截清单.md` 的类别、数量说明问题。补答或更正，必要时重新出草稿；正式选择与默认草稿不同时须重新生成。只有用户明确接受列出的遗留项才用 `--accept-unverified`，将 `终稿/终稿遗留项.md` 留作内部记录。核实实际生成的文件，转达脚本对个人信息、外链、隐藏文字等内容的提示。

## Examples

用户说“按报告批注摘入任务书的进度要求，先给我审核”。保留项目工作目录，模板和来源路径换成用户提供的文件。

```sh
DI run -t "报告.docx" -s "任务书.docx" --task "按报告批注摘入任务书的进度要求，先给我审核"
```

例如输出的任务目录为 `整合输出/报告_示例`，规划引用为 `S1:H2`，核对及草稿命令如下。若有待答问题，收到用户回答后先运行 `answer`。请求只到草稿时，交付草稿即停。

```sh
DI show "整合输出/报告_示例" S1:H2 --full
DI questions "整合输出/报告_示例"
DI draft "整合输出/报告_示例"
```

“把规范电特性填进记录，再从 B.xlsx 取中间电压的范围值”需要两次 `-s`，核对测试条件、样品号、单位和范围算法。详细示范见 [摘抄与填表](reference/示例.md)。多个模板用 `batch init` 配对来源，逐任务核对批次；排版用 `profile`。参数及批量示例见 [命令参考](reference/命令参考.md)。

## Limitations

- 草稿、终稿的原生目标为 DOCX。旧版 Word 模板须能在本机转换为 DOCX。Excel 工作簿可作数据来源，CLI 目前无法写入 Excel 目标。
- PDF 表格、图片提取随本地后端变化。完整套装会对纯扫描页及命中检测条件的图文混排页执行本地中英文 OCR。按原页复核识别片段，尤其是数值、单位、型号和表格行列，再记录用户确认。未读取项须标出页码。Word 内嵌位图、独立图片和手写表格没有自动结构化识别保证。批注跳转效果也取决于阅读器。
- `profile` 控制摘抄章节和题注的排版。填写已有表格时沿用模板单元格格式。

## Troubleshooting

- **File or format error** — 对照 `doctor` 检查转换后端；没有可用办公软件时，请用户提供另存的 DOCX/XLSX。离线 PDF 优先使用可用的 PyMuPDF，缺少时可用已安装的 pdfplumber 或 pypdf 提取内容。降级为纯文本后，逐项核对表格和图形来源。
- **Validation failed** — 用 `doctor --selfcheck 文件` 定位结构问题。保存并关闭仍有锁文件的草稿后重试；有未核问题时按审核报告或终稿拦截清单处理。以工具列出的实际输出路径判断哪份草稿、终稿或额外格式已生成。
