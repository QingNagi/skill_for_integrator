# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Bounded, non-executing reconstruction of explicitly declared text markers."""

from __future__ import annotations

import json
import re
from array import array
from bisect import bisect_right
from collections import Counter
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from html.parser import HTMLParser
from io import StringIO
from typing import Final

from skillspector.artifacts import SecurityTextView
from skillspector.javascript_ast import MAX_JAVASCRIPT_SOURCE_CHARS, parse_javascript_source
from skillspector.yaml_tokens import yaml_source_spans

MAX_MARKER_LENGTH: Final = 16
MAX_MARKER_SCOPE_CHARS: Final = 768
MAX_MARKER_LOOKAHEAD_CHARS: Final = 8192
MAX_PAYLOAD_CHARS: Final = 700
MAX_ACTIVE_DIRECTIVES: Final = 8
MAX_MARKER_REMOVALS: Final = 64
MAX_NEGATION_PREFIX_CHARS: Final = 80
MAX_DIRECTIVE_HEADER_CHARS: Final = 256
MAX_DECLARED_MARKER_RIGHT_CONTEXT_CHARS: Final = (
    MAX_DIRECTIVE_HEADER_CHARS + 2 * MAX_MARKER_LOOKAHEAD_CHARS
)
_MAX_DIRECTIVE_HEADER_SPACING_CHARS: Final = 8
_MAX_FALLBACK_PREFIX_CHARS: Final = MAX_DIRECTIVE_HEADER_CHARS
_MAX_ENTITY_ZERO_PADDING: Final = 8
_ENTITY_ZERO_PADDING = rf"0{{0,{_MAX_ENTITY_ZERO_PADDING}}}"
_FALLBACK_ENTITY_ZERO_PADDING = r"0{0,64}"

_TAKE_OUT_VERBS = (
    rf"take[ \t]{{0,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}out|"
    rf"taking[ \t]{{0,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}out"
)
_FALLBACK_TAKE_OUT_VERBS = (
    rf"take[ \t]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}out|"
    rf"taking[ \t]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}out"
)
_REMOVAL_VERBS = (
    r"remove|removing|strip|stripping|delete|deleting|drop|dropping|"
    r"omit|omitting|erase|erasing|ignore|ignoring|excise|excising|"
    rf"{_TAKE_OUT_VERBS}"
)
_FALLBACK_REMOVAL_VERBS = (
    r"remove|removing|strip|stripping|delete|deleting|drop|dropping|"
    r"omit|omitting|erase|erasing|ignore|ignoring|excise|excising|"
    rf"{_FALLBACK_TAKE_OUT_VERBS}"
)
_REPLACEMENT_VERBS = r"replace|replacing|substitute|substituting"
_DIRECTIVE_CUES = rf"(?:{_FALLBACK_REMOVAL_VERBS}|{_REPLACEMENT_VERBS})"
_DECLARED_MARKER_PREFIX = (
    rf"[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}"
    rf"(?:(?:(?:the|this|both|all|every|each|literal|declared|specified|"
    rf"following|next|invisible)[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}})"
    rf"{{0,3}}(?:"
    rf"(?:markers?|tokens?|substrings?|strings?|text|characters?|occurrences?)"
    rf"(?:[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}of)?"
    rf"[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}})?)?"
)
_QUOTE_OPEN_TO_CLOSE: Final = {
    "'": "'",
    '"': '"',
    "`": "`",
    "‘": "’",
    "“": "”",
}
_QUOTE_OPEN_CLASS = "'\"`‘“"
_MARKDOWN_FENCE_MIN_BACKTICKS: Final = 3
_FENCE_INFO_RE: Final = re.compile(r"[ \t]*[A-Za-z0-9_+#.-]*[ \t\r]*")
_ALL_QUOTE_CHARACTERS = frozenset((*_QUOTE_OPEN_TO_CLOSE, *_QUOTE_OPEN_TO_CLOSE.values()))
_PAYLOAD_QUOTE_OPEN_RE: Final = re.compile(rf"[{_QUOTE_OPEN_CLASS}]")
_DIRECTIVE_PREFILTER_RE: Final = re.compile(
    rf"\b{_DIRECTIVE_CUES}\b",
    re.IGNORECASE,
)
_ASCII_LETTER_ENTITY_RE: Final = re.compile(
    r"&#(?:(?P<hex>x[0-9a-f]{1,6})|(?P<decimal>[0-9]{1,7}));",
    re.IGNORECASE,
)
_PASSIVE_DIRECTIVE_PREFILTER_RE: Final = re.compile(
    r"\b(?:with|once|after)\b[^.!?\n]{0,64}\b"
    r"(?:removed|stripped|deleted|dropped|omitted|erased|ignored|excised|"
    r"taken[ \t]+out)\b",
    re.IGNORECASE,
)
_SPACED_SECURITY_WORDS = (
    "remove",
    "removing",
    "strip",
    "stripping",
    "delete",
    "deleting",
    "drop",
    "dropping",
    "omit",
    "omitting",
    "erase",
    "erasing",
    "ignore",
    "ignoring",
    "excise",
    "excising",
    "takeout",
    "takingout",
    "replace",
    "replacing",
    "substitute",
    "substituting",
    "run",
    "execute",
    "invoke",
    "issue",
    "launch",
    "perform",
    "carryout",
    "call",
    "eval",
    "type",
    "submit",
    "enter",
    "paste",
)
_SPACED_DIRECTIVE_PREFILTER_RE: Final = re.compile(
    r"(?<!\w)(?:"
    + "|".join(
        rf"(?:[^\w\r\n]|_){{0,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}".join(
            re.escape(character) for character in word
        )
        for word in _SPACED_SECURITY_WORDS
    )
    + r")(?!\w)",
    re.IGNORECASE,
)
_OVERPADDED_ENCODED_ENTITY_RE: Final = re.compile(
    rf"&(?:#x?0{{{_MAX_ENTITY_ZERO_PADDING + 1}}})",
    re.IGNORECASE,
)
_QUOTED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REMOVAL_VERBS})\b{_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>[{_QUOTE_OPEN_CLASS}])",
    re.IGNORECASE,
)
_PASSIVE_QUOTED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:with|once|after){_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>[{_QUOTE_OPEN_CLASS}])",
    re.IGNORECASE,
)
_PASSIVE_ENCODED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:with|once|after){_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>&(?:#x{_ENTITY_ZERO_PADDING}27|#{_ENTITY_ZERO_PADDING}39|apos|"
    rf"#x{_ENTITY_ZERO_PADDING}22|#{_ENTITY_ZERO_PADDING}34|quot);|"
    r"\\(?:x27|u0027|x22|u0022))",
    re.IGNORECASE,
)
_PASSIVE_REMOVAL_SUFFIX_RE: Final = re.compile(
    rf"[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}}"
    rf"(?:(?:the[ \t]+)?(?:markers?|tokens?|substrings?|strings?|text|characters?)"
    rf"[ \t]{{1,{_MAX_DIRECTIVE_HEADER_SPACING_CHARS}}})?"
    r"(?:is[ \t]+)?"
    r"(?:removed|stripped|deleted|dropped|omitted|erased|ignored|excised|"
    r"taken[ \t]+out)\b",
    re.IGNORECASE,
)
_UNSUPPORTED_QUOTED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_FALLBACK_REMOVAL_VERBS})\b[^.!?\n]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}?"
    rf"(?P<quote>[{_QUOTE_OPEN_CLASS}])",
    re.IGNORECASE,
)
_EMPTY_REPLACEMENT_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REPLACEMENT_VERBS})\b{_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>[{_QUOTE_OPEN_CLASS}])",
    re.IGNORECASE,
)
_EMPTY_REPLACEMENT_SUFFIX_RE: Final = re.compile(
    r"[ \t]{1,32}with[ \t]+(?:(?:an?|the)[ \t]+)?"
    r"(?:nothing\b|empty[ \t]+(?:string|text|value)\b|''|\"\")",
    re.IGNORECASE,
)
_ENCODED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REMOVAL_VERBS})\b{_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>&(?:#x{_ENTITY_ZERO_PADDING}27|#{_ENTITY_ZERO_PADDING}39|apos|"
    rf"#x{_ENTITY_ZERO_PADDING}22|#{_ENTITY_ZERO_PADDING}34|quot);|"
    r"\\(?:x27|u0027|x22|u0022))",
    re.IGNORECASE,
)
_UNSUPPORTED_ENCODED_REPLACEMENT_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REPLACEMENT_VERBS})\b{_DECLARED_MARKER_PREFIX}"
    rf"(?P<quote>&(?:#x{_ENTITY_ZERO_PADDING}27|#{_ENTITY_ZERO_PADDING}39|apos|"
    rf"#x{_ENTITY_ZERO_PADDING}22|#{_ENTITY_ZERO_PADDING}34|quot);|"
    r"\\(?:x27|u0027|x22|u0022))",
    re.IGNORECASE,
)
_UNSUPPORTED_ENCODED_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_FALLBACK_REMOVAL_VERBS})\b[^.!?\n]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}?"
    rf"(?P<quote>&(?:#x{_FALLBACK_ENTITY_ZERO_PADDING}27|"
    rf"#{_FALLBACK_ENTITY_ZERO_PADDING}39|apos|"
    rf"#x{_FALLBACK_ENTITY_ZERO_PADDING}22|#{_FALLBACK_ENTITY_ZERO_PADDING}34|quot);|"
    r"\\(?:x27|u0027|x22|u0022))",
    re.IGNORECASE,
)
_TAG_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REMOVAL_VERBS})\b{_DECLARED_MARKER_PREFIX}(?P<open><)",
    re.IGNORECASE,
)
_UNSUPPORTED_TAG_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_FALLBACK_REMOVAL_VERBS})\b"
    rf"(?P<header>[^.!?\n]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}?)"
    r"(?P<open><)",
    re.IGNORECASE,
)
# Characters the loose fallback header above can never cross.
_FALLBACK_HEADER_BOUNDARY_RE: Final = re.compile(r"[.!?\n]")
_ENCODED_TAG_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_REMOVAL_VERBS})\b{_DECLARED_MARKER_PREFIX}"
    rf"(?P<open>&(?:lt|#{_ENTITY_ZERO_PADDING}60|#x{_ENTITY_ZERO_PADDING}3c);)",
    re.IGNORECASE,
)
_UNSUPPORTED_ENCODED_TAG_DIRECTIVE_START_RE: Final = re.compile(
    rf"\b(?:{_FALLBACK_REMOVAL_VERBS})\b[^.!?\n]{{0,{_MAX_FALLBACK_PREFIX_CHARS}}}?"
    rf"(?P<open>&(?:lt|#{_FALLBACK_ENTITY_ZERO_PADDING}60|"
    rf"#x{_FALLBACK_ENTITY_ZERO_PADDING}3c);)",
    re.IGNORECASE,
)
_ENCODED_TAG_END_RE: Final = re.compile(
    rf"&(?:gt|#{_ENTITY_ZERO_PADDING}62|#x{_ENTITY_ZERO_PADDING}3e);",
    re.IGNORECASE,
)
_ENCODED_SINGLE_QUOTE_RE: Final = re.compile(
    rf"&(?:#x{_FALLBACK_ENTITY_ZERO_PADDING}27|"
    rf"#{_FALLBACK_ENTITY_ZERO_PADDING}39|apos);|\\(?:x27|u0027)",
    re.IGNORECASE,
)
_ENCODED_DOUBLE_QUOTE_RE: Final = re.compile(
    rf"&(?:#x{_FALLBACK_ENTITY_ZERO_PADDING}22|"
    rf"#{_FALLBACK_ENTITY_ZERO_PADDING}34|quot);|\\(?:x22|u0022)",
    re.IGNORECASE,
)
_TAG_MARKER_RE: Final = re.compile(r"</?[A-Za-z][A-Za-z0-9:_-]*(?:[ \t]*/)?\>")
# Accepts at least every prefix of a _TAG_MARKER_RE match. It also accepts
# blanks with no ``/`` (``<br  ``), which _TAG_MARKER_RE rejects, so a marker
# padded with blanks past the lookahead still reads as viable and fails closed.
_TAG_MARKER_PREFIX_RE: Final = re.compile(r"</?[A-Za-z][A-Za-z0-9:_-]*[ \t]*/?")
_UNAMBIGUOUS_ACTION_RE: Final = re.compile(
    r"\b(?:run|execute|invoke|issue|launch|perform|carry[ \t]+out)\b",
    re.IGNORECASE,
)
_CONTEXTUAL_ACTION_RE: Final = re.compile(
    r"\b(?:call|eval|type|submit|enter)\b",
    re.IGNORECASE,
)
_PASTE_ACTION_RE: Final = re.compile(r"\bpaste\b", re.IGNORECASE)
_ACTION_PAYLOAD_PREFIX_RE: Final = re.compile(
    r"[ \t]*(?:(?:exactly|verbatim|literally|directly|immediately)[ \t]+){0,2}"
    r"(?:(?:the|this|following|next)[ \t]+)?"
    r"(?:(?:command|instruction|payload|request|shell[ \t]+command)\b[ \t]*)?"
    r"(?::|=)?[ \t]*",
    re.IGNORECASE,
)
_EXPLICIT_ACTION_PAYLOAD_PREFIX_RE: Final = re.compile(
    r"[ \t]*(?:(?:the|this|following|next)[ \t]+)?"
    r"(?:command|instruction|payload|request|shell[ \t]+command)\b[ \t]*(?::|=)?[ \t]*",
    re.IGNORECASE,
)
_PASTE_TARGET_RE: Final = re.compile(
    r"[ \t]+into[ \t]+(?:(?:the|a)[ \t]+)?"
    r"(?:terminal|shell|console|command[ \t]+prompt|bash|zsh|powershell|cmd(?:\.exe)?)\b",
    re.IGNORECASE,
)
_REMOVAL_PAYLOAD_PREFIX_RE: Final = re.compile(
    r"[ \t]*(?:from|in)[ \t]+"
    r"(?:(?:the|this|following|next)[ \t]+){0,2}"
    r"(?:(?:command|instruction|payload|request)[ \t]*)?(?::|=)?[ \t]*",
    re.IGNORECASE,
)
_COPY_PAYLOAD_PREFIX_RE: Final = re.compile(
    r"[ \t]*(?:,|;)?[ \t]*(?:then[ \t]+)?copy[ \t]+"
    r"(?:(?:the|this|following|next)[ \t]+)?"
    r"(?:(?:command|instruction|payload|request)[ \t]*)?(?::|=)?[ \t]*",
    re.IGNORECASE,
)
_ANAPHORIC_ACTION_RE: Final = re.compile(
    r"\b(?P<action>run|execute|invoke|issue|launch|perform|call|eval|type|submit|"
    r"enter|paste)\b[ \t]+(?:it|this|that|(?:the|this|that)[ \t]+"
    r"(?:result|command|instruction|payload))\b",
    re.IGNORECASE,
)
_INLINE_SHELL_WRAPPER_RE: Final = re.compile(
    r"(?:sudo|command|nohup)[ \t]+[^\s]*$",
    re.IGNORECASE,
)
_DECODED_ACTIVE_TOKEN_RE: Final = re.compile(
    r"\b(?:run|execute|invoke|issue|launch|perform|call|eval|type|submit|enter|curl|"
    r"rm|del|erase|sudo|bash|zsh|powershell)\b",
    re.IGNORECASE,
)
_AFFIRMATIVE_NEGATION_PREFIX_RE: Final = re.compile(
    r"(?:(?:\bdo[ \t]+not|\bdon't|\bnever)[ \t,]+"
    r"(?:forget|fail|hesitate|neglect)(?:[ \t]+at[ \t]+all)?[ \t]+to"
    r"(?:[ \t]+(?!(?:never|not|don't)\b)\w+){0,2}|"
    r"(?:\bdo[ \t]+not|\bdon't|\bnever)[ \t,]+forget"
    r"(?:[ \t]+that)?(?:[ \t]+you)?[ \t]+(?:must|should|shall|will|need[ \t]+to)|"
    r"\bnot[ \t]+(?:only|just)(?:[ \t]+\w+){0,2}|"
    r"(?:\bdo[ \t]+not|\bdon't|\bnever|\bavoid)[ \t]+"
    r"(?:only|just|merely)|"
    r"(?:\bdo[ \t]+not|\bdon't|\bnever)[ \t]+stop[ \t]+at)[ \t]*$",
    re.IGNORECASE,
)
_NEGATED_ACTION_PREFIX_RE: Final = re.compile(
    r"(?:(?:\bdo[ \t]+not|\bdon't|\bnever|\bavoid|\bmust[ \t]+not)"
    r"(?:(?:[ \t]*,[ \t]*|[ \t]+)"
    r"(?!(?:so|but|yet|then|therefore|however|instead)\b)\w+){0,8}[ \t,]*|"
    r"\bnot[ \t,]*|"
    r"\bnot(?:[ \t]*,[ \t]*|[ \t]+)"
    r"(?:ever|directly|immediately|actually)[ \t,]*|"
    r"\bnot(?:[ \t]*,[ \t]*|[ \t]+)(?:under|in)"
    r"(?:[ \t]*,[ \t]*|[ \t]+)(?:any|all|these|those)"
    r"(?:(?:[ \t]*,[ \t]*|[ \t]+)\w+){0,4}[ \t,]*|"
    r"\bunder(?:[ \t]*,[ \t]*|[ \t]+)no"
    r"(?:[ \t]*,[ \t]*|[ \t]+)(?:circumstances?|conditions?)[ \t,]*|"
    r"\bin(?:[ \t]*,[ \t]*|[ \t]+)no"
    r"(?:[ \t]*,[ \t]*|[ \t]+)case[ \t,]*|"
    r"\brefrain(?:ing)?[ \t]+from[ \t]*)$",
    re.IGNORECASE,
)
_FORWARD_PAYLOAD_REFERENCE_RE: Final = re.compile(
    r"\b(?:next|following|coming)[ \t]+"
    r"(?:command|instruction|prompt|payload|request)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class DeclaredMarkerViewResult:
    """Deterministic payload views and whether any active form was unsupported."""

    views: tuple[SecurityTextView, ...]
    limited: bool
    first_limited_source_offset: int | None = None


@dataclass(frozen=True)
class _Directive:
    marker: str
    start: int
    end: int
    is_tag: bool = False
    encoded: bool = False
    unsupported: bool = False
    exhausted: bool = False


@dataclass(frozen=True)
class _Payload:
    start: int
    end: int


@dataclass(frozen=True)
class _ProjectionCandidate:
    directive: _Directive
    payload: _Payload
    positions: tuple[int, ...]


@dataclass(frozen=True)
class _DirectiveClassification:
    candidate: _ProjectionCandidate | None
    active: bool
    limited: bool


def _decode_ascii_letter_entities_view(view: SecurityTextView) -> SecurityTextView:
    """Decode bounded numeric HTML entities only when they spell ASCII letters."""
    replacements: list[tuple[re.Match[str], str]] = []
    for match in _ASCII_LETTER_ENTITY_RE.finditer(view.text):
        digits = match.group("hex") or match.group("decimal")
        base = 16 if match.group("hex") is not None else 10
        value = int(digits[1:] if base == 16 else digits, base)
        character = chr(value) if value <= 0x7F else ""
        if character.isascii() and character.isalpha():
            replacements.append((match, character))
    if not replacements:
        return view

    output = StringIO()
    offsets = array("I")
    ends = array("I") if view.source_end_offsets is not None else None
    cursor = 0
    for match, character in replacements:
        output.write(view.text[cursor : match.start()])
        if view.source_offsets is None:
            offsets.extend(range(cursor, match.start()))
        else:
            offsets.extend(view.source_offsets[cursor : match.start()])
        if ends is not None:
            ends.extend(view.source_end_offsets[cursor : match.start()])
        output.write(character)
        offsets.append(view.source_offset(match.start()))
        if ends is not None:
            ends.append(view.source_end_offset(match.end() - 1))
        cursor = match.end()
    output.write(view.text[cursor:])
    if view.source_offsets is None:
        offsets.extend(range(cursor, len(view.text)))
    else:
        offsets.extend(view.source_offsets[cursor:])
    if ends is not None:
        ends.extend(view.source_end_offsets[cursor:])
    return SecurityTextView(
        f"entity-{view.name}", output.getvalue(), offsets, source_end_offsets=ends
    )


def _compact_spaced_security_word_view(view: SecurityTextView) -> SecurityTextView:
    """Collapse bounded separators inside exact directive and action words.

    The shared compact view intentionally requires six letters before removing
    spacing. Several directive verbs are shorter, so relying on that generic
    threshold creates a security-only eligibility mismatch. This projection is
    restricted to complete allowlisted verbs and retains exact source offsets.
    """
    matches = tuple(
        match
        for match in _SPACED_DIRECTIVE_PREFILTER_RE.finditer(view.text)
        if not match.group().isalpha()
    )
    if not matches:
        return view

    output = StringIO()
    offsets = array("I")
    ends = array("I") if view.source_end_offsets is not None else None
    cursor = 0
    for match in matches:
        output.write(view.text[cursor : match.start()])
        if view.source_offsets is None:
            offsets.extend(range(cursor, match.start()))
        else:
            offsets.extend(view.source_offsets[cursor : match.start()])
        if ends is not None:
            ends.extend(view.source_end_offsets[cursor : match.start()])
        for source_offset in range(match.start(), match.end()):
            character = view.text[source_offset]
            if not character.isalpha():
                continue
            output.write(character)
            offsets.append(view.source_offset(source_offset))
            if ends is not None:
                ends.append(view.source_end_offset(source_offset))
        cursor = match.end()
    output.write(view.text[cursor:])
    if view.source_offsets is None:
        offsets.extend(range(cursor, len(view.text)))
    else:
        offsets.extend(view.source_offsets[cursor:])
    if ends is not None:
        ends.extend(view.source_end_offsets[cursor:])
    return SecurityTextView(
        f"marker-{view.name}", output.getvalue(), offsets, source_end_offsets=ends
    )


# Only bounded, complete JSON values establish quote ownership. Arbitrary
# key/value-looking prose is not a JSON representation. Keep fence syntax
# aligned with analyzers.common without importing its auto-discovered registry.
_MAX_JSON_QUOTE_DECODE_CHARS: Final = 65_536
_MAX_JSON_FRONTMATTER_CHARS: Final = 65_536
_MAX_JSON_QUOTE_CONTAINER_CHARS: Final = 131_072
# A tab in a Markdown container can expand to at most four validation columns.
# This bounds the validation copy separately from the raw source-size ceiling.
_MAX_JSON_QUOTE_VALIDATION_CHARS: Final = 4 * _MAX_JSON_QUOTE_CONTAINER_CHARS
MAX_STANDALONE_JSON_SOURCE_CHARS: Final = 2 * 1024 * 1024
_JSON_FENCE_OPEN_RE: Final = re.compile(r"^[ ]{0,3}(`{3,}|~{3,})([^\r\n]*)$")
_JSON_FENCE_CLOSE_RE: Final = re.compile(r"^[ ]{0,3}(`{3,}|~{3,})[ \t]*$")
_JSON_LIST_MARKER_RE: Final = re.compile(r"(?:[-+*]|[0-9]{1,9}[.)])")


@dataclass
class _JsonContainerCursor:
    """Read container columns without expanding JSON or losing raw positions.

    A consumed tab advances the raw index once; its remaining visual columns
    stay in ``pending`` until another container or the validation copy uses
    them. Tab stops therefore remain relative to the original line.
    """

    line: str
    check_runtime: Callable[[], None] | None
    index: int = 0
    column: int = 0
    pending: int = 0

    def character(self) -> str:
        if self.pending:
            return " "
        return self.line[self.index] if self.index < len(self.line) else ""

    def advance(self) -> None:
        if self.check_runtime is not None:
            self.check_runtime()
        if self.pending:
            self.pending -= 1
        else:
            if self.line[self.index] == "\t":
                self.pending = 3 - self.column % 4
            self.index += 1
        self.column += 1

    def spaces(self, limit: int) -> int:
        start = self.column
        while self.column - start < limit and self.character() in (" ", "\t"):
            self.advance()
        return self.column - start

    def quote(self) -> bool:
        self.spaces(3)
        if self.character() != ">":
            return False
        self.advance()
        self.spaces(1)
        return True

    def remainder(self) -> str:
        # Fence recognition needs at most four leading columns: the fourth
        # proves overindentation. Only that bounded prefix is normalized;
        # literal tabs after the JSON's first token remain untouched.
        start = self.column
        self.spaces(4)
        return " " * (self.column - start + self.pending) + self.line[self.index :]


def _json_fence_prefix(
    line: str, check_runtime: Callable[[], None] | None
) -> tuple[str, tuple[tuple[str, int], ...]]:
    """Recognize explicit container prefixes without changing source text."""
    context: list[tuple[str, int]] = []
    cursor = _JsonContainerCursor(line, check_runtime)
    while True:
        if check_runtime is not None:
            check_runtime()
        start = cursor.index, cursor.column, cursor.pending
        cursor.spaces(3)
        if cursor.character() == ">":
            context.append(("quote", 0))
            cursor.advance()
            cursor.spaces(1)
            continue
        item = None if cursor.pending else _JSON_LIST_MARKER_RE.match(line, cursor.index)
        if item is not None:
            # The marker is bounded ASCII, so raw and visual widths agree.
            cursor.column += item.end() - cursor.index
            cursor.index = item.end()
            padding = cursor.spaces(5)
            if 1 <= padding <= 4:
                context.append(("indent", cursor.column - start[1]))
                continue
        cursor.index, cursor.column, cursor.pending = start
        return cursor.remainder(), tuple(context)


def _json_fence_body(
    line: str,
    context: tuple[tuple[str, int], ...],
    check_runtime: Callable[[], None] | None,
    *,
    last_quote_index: int,
) -> str | None:
    """Remove only the opener's proven container prefixes for JSON validation."""
    cursor = _JsonContainerCursor(line, check_runtime)
    for index, (kind, width) in enumerate(context):
        if check_runtime is not None:
            check_runtime()
        if kind == "quote":
            if not cursor.quote():
                return None
        else:
            if cursor.spaces(width) != width:
                # Empty list-body lines may omit indentation. A missing quote
                # prefix is different: it ends that explicit container.
                return (
                    "\n" if index > last_quote_index and not line[cursor.index :].strip() else None
                )
    return cursor.remainder()


def _json_body_after_frontmatter(text: str, check_runtime: Callable[[], None] | None) -> int | None:
    """Recognize a bounded, explicitly delimited metadata prefix at offset zero.

    This only identifies the JSON body's boundary. Manifest parsing continues
    to validate metadata independently; none of its quotes acquires ownership.
    """
    prefix = text[:_MAX_JSON_FRONTMATTER_CHARS]
    opening = re.match(r"\A---[ \t]*\r?\n", prefix)
    if opening is None:
        return None
    offset = opening.end()
    for line in prefix[offset:].splitlines(keepends=True):
        if check_runtime is not None:
            check_runtime()
        # A complete delimiter line prevents a bounded prefix ending in the
        # middle of a longer line from manufacturing a closing delimiter.
        if line.endswith("\n") and line.rstrip("\r\n").rstrip(" \t") in {"---", "..."}:
            return offset + len(line)
        offset += len(line)
    return None


def _validate_json_without_decoding(
    body: str,
    check_runtime: Callable[[], None] | None,
    *,
    max_characters: int = _MAX_JSON_QUOTE_VALIDATION_CHARS,
) -> bool:
    """Validate one bounded JSON value without recursion or decoded allocations.

    Every grammar transition consumes source; only a byte per open container
    is retained. The caller also bounds raw source, which bounds the number of
    tokens and later quote spans. No ownership escapes a partially read value.
    """
    length = len(body)
    if length > max_characters or max_characters > MAX_STANDALONE_JSON_SOURCE_CHARS:
        return False
    next_check = 0

    def checkpoint(offset: int) -> None:
        nonlocal next_check
        if offset >= next_check:
            if check_runtime is not None:
                check_runtime()
            # A Unicode escape advances at most six positions in one step.
            # Checking every 128 keeps even that overshoot below 256 chars.
            next_check = offset + 128

    def string_end(start: int) -> int:
        offset = start + 1
        while offset < length:
            checkpoint(offset)
            character = body[offset]
            if character == '"':
                return offset + 1
            if ord(character) < 0x20:
                return -1
            if character == "\\":
                offset += 1
                if offset >= length:
                    return -1
                escape = body[offset]
                if escape == "u":
                    for _ in range(4):
                        offset += 1
                        if offset >= length or body[offset] not in "0123456789abcdefABCDEF":
                            return -1
                elif escape not in '\\"/bfnrt':
                    return -1
            offset += 1
        return -1

    def number_end(start: int) -> int:
        offset = start
        if body[offset] == "-":
            offset += 1
        if offset >= length:
            return -1
        if body[offset] == "0":
            offset += 1
        elif "1" <= body[offset] <= "9":
            while offset < length and "0" <= body[offset] <= "9":
                checkpoint(offset)
                offset += 1
        else:
            return -1
        if offset < length and body[offset] == ".":
            offset += 1
            digits = offset
            while offset < length and "0" <= body[offset] <= "9":
                checkpoint(offset)
                offset += 1
            if offset == digits:
                return -1
        if offset < length and body[offset] in "eE":
            offset += 1
            if offset < length and body[offset] in "+-":
                offset += 1
            digits = offset
            while offset < length and "0" <= body[offset] <= "9":
                checkpoint(offset)
                offset += 1
            if offset == digits:
                return -1
        return offset

    (
        root_value,
        root_done,
        array_first,
        array_value,
        array_end,
        object_first,
        object_key,
        object_colon,
        object_value,
        object_end,
    ) = range(10)
    stack = bytearray([root_value])
    cursor = 0
    while True:
        checkpoint(cursor)
        while cursor < length and body[cursor] in " \t\r\n":
            checkpoint(cursor)
            cursor += 1
        if cursor == length:
            if check_runtime is not None:
                check_runtime()
            return len(stack) == 1 and stack[0] == root_done
        state = stack[-1]
        character = body[cursor]
        if state == root_done:
            return False
        if state in (object_first, object_key):
            if character == "}" and state == object_first:
                stack.pop()
                cursor += 1
                continue
            if character != '"':
                return False
            cursor = string_end(cursor)
            if cursor < 0:
                return False
            stack[-1] = object_colon
            continue
        if state == object_colon:
            if character != ":":
                return False
            stack[-1] = object_value
            cursor += 1
            continue
        if state in (array_end, object_end):
            if character == ",":
                stack[-1] = array_value if state == array_end else object_key
            elif character == ("]" if state == array_end else "}"):
                stack.pop()
            else:
                return False
            cursor += 1
            continue
        if state == array_first and character == "]":
            stack.pop()
            cursor += 1
            continue
        # Advance the parent before pushing a child. A close is legal only
        # in the explicit empty-container or after-value states above.
        stack[-1] = (
            root_done if state == root_value else object_end if state == object_value else array_end
        )
        if character in "[{":
            stack.append(array_first if character == "[" else object_first)
            cursor += 1
        elif character == '"':
            cursor = string_end(cursor)
            if cursor < 0:
                return False
        elif character == "-" or "0" <= character <= "9":
            cursor = number_end(cursor)
            if cursor < 0:
                return False
        elif body.startswith("true", cursor):
            cursor += 4
        elif body.startswith("false", cursor):
            cursor += 5
        elif body.startswith("null", cursor):
            cursor += 4
        else:
            return False


def _validated_json_ranges(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    on_capacity_limit: Callable[[int, int], None] | None = None,
) -> list[tuple[int, int]]:
    """Return raw source ranges whose complete JSON syntax has been validated.

    List and blockquote prefixes are removed only in a bounded validation copy.
    They contain no string delimiters, so quote offsets in the original ranges
    remain exact. Invalid, incomplete or oversized containers grant no
    ownership. Non-JSON fences also establish block boundaries.
    """

    def check() -> None:
        if check_runtime is not None:
            check_runtime()

    def reject_constant(value: str) -> None:
        raise ValueError("Non-JSON numeric constant")

    def valid(start: int, end: int, body: str | None = None) -> bool:
        check()
        if end - start > _MAX_JSON_QUOTE_CONTAINER_CHARS:
            # Oversized candidates are NOT parsed. A fence explicitly claims
            # JSON; standalone candidates need a plausible first token in the
            # bounded prefix. Neither test establishes validity or ownership.
            if on_capacity_limit is not None and (
                body is not None
                or text[start : start + _MAX_JSON_QUOTE_CONTAINER_CHARS]
                .lstrip(" \t\r\n")
                .startswith(("{", "[", '"'))
            ):
                on_capacity_limit(start, end)
            return False
        candidate = text[start:end] if body is None else body
        if end - start > _MAX_JSON_QUOTE_DECODE_CHARS:
            result = _validate_json_without_decoding(candidate, check_runtime)
        else:
            # Preserve the established small-input acceptance contract,
            # including decoder depth/numeric limits. Never retry a rejected
            # small value through the larger-input path.
            try:
                json.loads(candidate, parse_constant=reject_constant)
            except (ValueError, RecursionError):
                result = False
            else:
                result = True
        check()
        return result

    if valid(0, len(text)):
        return [(0, len(text))]
    body_start = _json_body_after_frontmatter(text, check_runtime)
    if body_start is not None and valid(body_start, len(text)):
        return [(body_start, len(text))]
    ranges: list[tuple[int, int]] = []
    fence: tuple[str, int, tuple[tuple[str, int], ...], bool] | None = None
    body_lines: list[str] = []
    last_quote_index = -1
    start = 0
    offset = 0
    for line in text.splitlines(keepends=True):
        check()
        body = None
        if fence is not None:
            body = _json_fence_body(
                line, fence[2], check_runtime, last_quote_index=last_quote_index
            )
            if body is None:
                # The explicit container ended. Discard its partial payload,
                # then consider this same line once as a new fence opener.
                # No recursion, rewind or repeated suffix scan is needed.
                fence = None
                body_lines = []
        if fence is None:
            body, context = _json_fence_prefix(line.rstrip("\r\n"), check_runtime)
            opening = _JSON_FENCE_OPEN_RE.fullmatch(body)
            if opening and not (opening[1][0] == "`" and "`" in opening[2]):
                language = opening[2].strip().split(maxsplit=1)
                last_quote_index = -1
                for index, (kind, _) in enumerate(context):
                    check()
                    if kind == "quote":
                        last_quote_index = index
                fence = (
                    opening[1][0],
                    len(opening[1]),
                    context,
                    bool(language and language[0].lower() == "json"),
                )
                start = offset + len(line)
                body_lines = []
        else:
            assert body is not None
            closing = _JSON_FENCE_CLOSE_RE.fullmatch(body.rstrip("\r\n"))
            if closing and closing[1][0] == fence[0] and len(closing[1]) >= fence[1]:
                if fence[3] and valid(start, offset, "".join(body_lines)):
                    ranges.append((start, offset))
                fence = None
                body_lines = []
            elif offset + len(line) - start <= _MAX_JSON_QUOTE_CONTAINER_CHARS:
                if fence[3]:
                    body_lines.append(body)
            else:
                body_lines = []
        offset += len(line)
    return ranges


def json_quote_capacity_limit(
    text: str, check_runtime: Callable[[], None] | None, *, containing_offset: int
) -> tuple[int, int] | None:
    """Describe the first oversized candidate without granting quote ownership.

    Offsets are zero-based, end-exclusive source characters, including body
    whitespace and Markdown container prefixes. Closed fences exclude their
    delimiters. Only one diagnostic is retained regardless of candidate count.
    Callers use this to explain already-incomplete reconstruction, not to infer
    either maliciousness or completeness from a JSON-looking prefix.
    """
    first: tuple[int, int] | None = None

    def record(start: int, end: int) -> None:
        nonlocal first
        if first is None and start <= containing_offset < end:
            first = (start, end)

    _validated_json_ranges(text, check_runtime, on_capacity_limit=record)
    return first


def _json_string_spans(
    text: str, check_runtime: Callable[[], None] | None
) -> Iterator[tuple[int, int]]:
    """Lex all complete JSON strings in one forward, escape-aware pass.

    This intentionally includes array elements and object keys, unlike the old
    key/string-value-pair grammar. Only the caller's validated ranges establish
    ownership. Malformed prose still cannot grant structural quote ownership.
    """
    cursor = 0
    limit = len(text)
    start: int | None = None
    next_check = 0
    while cursor < limit:
        if cursor >= next_check:
            if check_runtime is not None:
                check_runtime()
            next_check = cursor + 256
        character = text[cursor]
        if start is None:
            if character == '"':
                start = cursor
        elif character == "\\":
            # JSON escapes consume the following character, including quotes.
            # Unicode escape digits contain no delimiters; validation proves
            # their syntax before these lexical spans can establish ownership.
            cursor += 1
        elif character == '"':
            yield start, cursor + 1
            start = None
        elif character in "\r\n":
            start = None
        cursor += 1
    if check_runtime is not None:
        check_runtime()


def validated_json_string_spans(
    text: str, check_runtime: Callable[[], None] | None
) -> list[tuple[int, int]]:
    """Return exact string spans owned by complete JSON values, including both quotes."""
    ranges = _validated_json_ranges(text, check_runtime)
    spans: list[tuple[int, int]] = []
    for start, end in ranges:
        for string_start, string_end in _json_string_spans(text[start:end], check_runtime):
            spans.append((start + string_start, start + string_end))
    return spans


def validated_json_string_closers(text: str, check_runtime: Callable[[], None] | None) -> set[int]:
    """Return exact closing-quote offsets owned by complete JSON values."""
    return {end - 1 for _, end in validated_json_string_spans(text, check_runtime)}


_HTML_ATTRIBUTE_RE = re.compile(
    r"[^\s/=>\"'`<]+(?:\s*=\s*(?P<value>\"[^\"]*\"|'[^']*'|[^\s\"'=<>`]+))?"
)
_HTML_START_TAG_RE = re.compile(
    rf"<([A-Za-z][A-Za-z0-9:-]*)(?:\s+{_HTML_ATTRIBUTE_RE.pattern})*\s*/?>\Z"
)
_BACKTICK_RUN_RE = re.compile(r"`+")
_MARKDOWN_INLINE_TOKEN_RE = re.compile(r"`+|<")
_MARKDOWN_ATTRIBUTE = (
    r"[ \t]++[A-Za-z_:][A-Za-z0-9_.:-]*+"
    r"(?:[ \t]*+=[ \t]*+(?:\"[^\"]*+\"|'[^']*+'|[^ \t\n\r\"'=<>`]++))?+"
)
_MARKDOWN_INLINE_CONSTRUCT_RE = re.compile(
    r"<(?:[A-Za-z][A-Za-z0-9+.-]{1,31}:[^\x00-\x20<>\x7f]*+"
    r"|[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]++@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
    r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*+"
    rf"|[A-Za-z][A-Za-z0-9-]*+(?:{_MARKDOWN_ATTRIBUTE})*+[ \t]*+/?"
    r"|/[A-Za-z][A-Za-z0-9-]*+[ \t]*+)>"
)
# A tag still open at the end of a line can continue on the next one.
_MARKDOWN_OPEN_TAG_TAIL_RE = re.compile(
    r"<(?:[A-Za-z][A-Za-z0-9-]*+(?:[ \t]++[A-Za-z_:][A-Za-z0-9_.:-]*+"
    r"(?:[ \t]*+=[ \t]*+(?:\"[^\"]*+(?:\"|\Z)|'[^']*+(?:'|\Z)|[^ \t\n\r\"'=<>`]++|\Z))?+)*+"
    r"|/[A-Za-z][A-Za-z0-9-]*+)[ \t]*+\Z"
)
_MARKDOWN_INLINE_TERMINATORS = (("<!--", "-->"), ("<?", "?>"), ("<![CDATA[", "]]>"))
_HTML_BLOCK_TAG_RE = re.compile(
    r"</?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|"
    r"dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|"
    r"h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|"
    r"optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|"
    r"track|ul)(?=[ \t>]|/?>|$)",
    re.IGNORECASE,
)
_HTML_MARKDOWN_TAG_NAME_RE = re.compile(r"</?([A-Za-z][A-Za-z0-9-]*)(?=[ \t/>]|$)")
_HTML_MARKDOWN_CLOSE_TAG_RE = re.compile(r"</[A-Za-z][A-Za-z0-9-]*[ \t]*>")


def markdown_html_block(
    raw: str, *, paragraph_open: bool = False
) -> tuple[bool, re.Pattern[str] | None]:
    """Recognize HTML block starts without treating angle-bracket autolinks as tags."""
    if not raw.startswith("<"):
        return False, None
    if re.match(r"<(script|pre|style|textarea)(?=[ \t>]|$)", raw, re.IGNORECASE):
        return True, re.compile(r"</(?:script|pre|style|textarea)>", re.IGNORECASE)
    for opening, closing in (("<!--", "-->"), ("<?", "?>"), ("<![CDATA[", "]]>")):
        if raw.startswith(opening):
            return True, re.compile(re.escape(closing))
    if re.match(r"<![A-Za-z]", raw):
        return True, re.compile(">")
    if _HTML_BLOCK_TAG_RE.match(raw):
        return True, None
    if paragraph_open:
        # A type-7 custom tag cannot interrupt a CommonMark paragraph.
        return False, None
    name = _HTML_MARKDOWN_TAG_NAME_RE.match(raw)
    if name is not None and name[1].lower() not in {"script", "pre", "style", "textarea"}:
        complete = raw.rstrip(" \t")
        if _HTML_START_TAG_RE.fullmatch(complete) or _HTML_MARKDOWN_CLOSE_TAG_RE.fullmatch(
            complete
        ):
            return True, None
    return False, None


def _html_attribute_closers(content: str, check_runtime: Callable[[], None]) -> set[int]:
    """Own only quoted attribute delimiters inside individually valid start tags."""
    line_starts = [0, *(match.end() for match in re.finditer("\n", content))]
    closers: set[int] = set()

    class Tags(HTMLParser):
        def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
            check_runtime()
            raw = self.get_starttag_text()
            parsed = _HTML_START_TAG_RE.fullmatch(raw)
            if parsed is None:
                return
            row, column = self.getpos()
            start = line_starts[row - 1] + column
            for attribute in _HTML_ATTRIBUTE_RE.finditer(raw, parsed.end(1)):
                value = attribute.group("value")
                if value and value[0] in "\"'":
                    closers.add(start + attribute.end("value") - 1)

        handle_startendtag = handle_starttag

    parser = Tags(convert_charrefs=False)
    parser.feed(content)
    parser.close()
    check_runtime()
    return closers


def _markdown_inline_construct_end(
    text: str, start: int, check_runtime: Callable[[], None]
) -> int | None:
    """Return where an autolink or raw inline HTML at ``start`` ends.

    ``-1`` means ``start`` is ordinary text. ``None`` means a construct may
    continue past the end of the line, so the boundary is not proved.
    """
    check_runtime()
    if text.startswith(("<!-->", "<!--->"), start):
        return text.index(">", start + 4) + 1
    for opening, closing in _MARKDOWN_INLINE_TERMINATORS:
        if text.startswith(opening, start):
            end = text.find(closing, start + len(opening))
            return None if end < 0 else end + len(closing)
    if re.match(r"<![A-Za-z]", text[start : start + 3]):
        end = text.find(">", start)
        return None if end < 0 else end + 1
    construct = _MARKDOWN_INLINE_CONSTRUCT_RE.match(text, start)
    if construct is not None:
        return construct.end()
    if _MARKDOWN_OPEN_TAG_TAIL_RE.match(text, start):
        return None
    return -1


def _markdown_inline_closers(content: str, check_runtime: Callable[[], None]) -> set[int]:
    """Own same-line CommonMark code delimiters outside recognized fenced blocks."""
    closers: set[int] = set()
    fence: tuple[str, int, tuple[tuple[str, int], ...], int] | None = None
    html_end: re.Pattern[str] | None = None
    html_context: tuple[tuple[str, int], ...] = ()
    html_last_quote = -1
    in_html = False
    offset = 0
    for line in content.splitlines(keepends=True):
        check_runtime()
        body, context = _json_fence_prefix(line.rstrip("\r\n"), check_runtime)
        if in_html:
            html_body = _json_fence_body(
                line, html_context, check_runtime, last_quote_index=html_last_quote
            )
            if html_body is not None:
                if (html_end is None and not html_body.strip()) or (
                    html_end is not None and html_end.search(html_body) is not None
                ):
                    in_html = False
                offset += len(line)
                continue
            in_html = False
        if fence is not None:
            fenced_body = _json_fence_body(line, fence[2], check_runtime, last_quote_index=fence[3])
            if fenced_body is not None:
                closing = _JSON_FENCE_CLOSE_RE.fullmatch(fenced_body.rstrip("\r\n"))
                if closing and closing[1][0] == fence[0] and len(closing[1]) >= fence[1]:
                    fence = None
                offset += len(line)
                continue
            fence = None
        # Indented code does not establish inline-code ownership.
        if body.startswith("    "):
            offset += len(line)
            continue
        # Type-7 HTML starts are treated conservatively even when their
        # ability to interrupt an existing paragraph has not been proved.
        raw = body.lstrip()
        html_start, html_terminator = markdown_html_block(raw)
        if html_start:
            html_end = html_terminator
            html_context = context
            html_last_quote = max(
                (i for i, entry in enumerate(context) if entry[0] == "quote"), default=-1
            )
            in_html = html_end is None or html_end.search(raw) is None
            offset += len(line)
            continue
        opening = _JSON_FENCE_OPEN_RE.fullmatch(body)
        if opening and not (opening[1][0] == "`" and "`" in opening[2]):
            last_quote = max(
                (i for i, entry in enumerate(context) if entry[0] == "quote"), default=-1
            )
            fence = opening[1][0], len(opening[1]), context, last_quote
        else:
            opener: re.Match[str] | None = None
            text = line.rstrip("\r\n")
            skip_to = 0
            for run in _MARKDOWN_INLINE_TOKEN_RE.finditer(text):
                if run.start() < skip_to:
                    continue
                if opener is None:
                    cursor = run.start() - 1
                    while cursor >= 0 and line[cursor] == "\\":
                        cursor -= 1
                    if (run.start() - 1 - cursor) % 2:
                        continue
                    if run[0] == "<":
                        # Autolinks and raw inline HTML bind before code spans,
                        # so a backtick inside one is literal and cannot open a
                        # span. One that may continue on the next line withholds
                        # ownership, like an unmatched run.
                        end = _markdown_inline_construct_end(text, run.start(), check_runtime)
                        if end is None:
                            return closers
                        skip_to = end
                        continue
                    opener = run
                elif run[0] != "<" and len(run[0]) == len(opener[0]):
                    closers.update(range(offset + run.start(), offset + run.end()))
                    opener = None
            if opener is not None:
                # A code span can continue on another line. This helper proves
                # same-line pairs only, so an unmatched run makes later quote
                # state ambiguous and cannot grant more delimiter ownership.
                return closers
        offset += len(line)
    return closers


class StructuredStringClosers:
    """Lazily prove structural closing delimiters against a complete bounded artifact.

    Only the loose declared-marker fallback consumes this proof. Literal contents
    and explicit marker declarations continue through ordinary security matching.
    """

    def __init__(
        self,
        content: str,
        file_type: str,
        check_runtime: Callable[[], None],
        *,
        shell_quote_closers: Callable[[], set[int]] | None = None,
    ) -> None:
        self._content = content
        self._file_type = file_type
        self._check_runtime = check_runtime
        self._shell_quote_closers = shell_quote_closers
        self._closers: set[int] | None = None

    def closes_string(self, offset: int) -> bool:
        self._check_runtime()
        if self._closers is None:
            self._closers = self._compute()
        return offset in self._closers

    def _compute(self) -> set[int]:
        content = self._content
        if len(content) > MAX_JAVASCRIPT_SOURCE_CHARS:
            return set()
        if self._file_type == "shell" and self._shell_quote_closers is not None:
            return self._shell_quote_closers()
        if self._file_type == "javascript":
            program = parse_javascript_source(content, self._check_runtime)
            if program is None:
                return set()
            return {
                program.span(node)[1] - 1
                for node in program.nodes
                if node.type in {"string", "template_string"}
            }
        if self._file_type == "json":

            def reject_constant(value: str) -> None:
                raise ValueError(value)

            try:
                json.loads(content, parse_constant=reject_constant)
            except (ValueError, RecursionError):
                return set()
            self._check_runtime()
            return {end - 1 for _, end in _json_string_spans(content, self._check_runtime)}
        if self._file_type == "markdown":
            closers = _markdown_inline_closers(content, self._check_runtime)
            header_end = _json_body_after_frontmatter(content, self._check_runtime)
            if header_end is not None:
                header = yaml_source_spans(content[:header_end], self._check_runtime)
                if header is not None:
                    closers.update(
                        scalar.end - 1 for scalar in header.scalars if scalar.style in {"'", '"'}
                    )
            return closers
        if self._file_type == "html":
            return _html_attribute_closers(content, self._check_runtime)
        return set()


def _is_quoted_mapping_key(text: str, start: int) -> bool:
    """Return whether the exact quoted removal verb is followed by a key colon."""
    if start == 0 or text[start - 1] not in _ALL_QUOTE_CHARACTERS:
        return False
    closing_quote = _QUOTE_OPEN_TO_CLOSE[text[start - 1]]
    closing = text.find(closing_quote, start)
    if (
        closing < 0
        or re.fullmatch(_FALLBACK_REMOVAL_VERBS, text[start:closing], re.IGNORECASE) is None
    ):
        return False
    cursor = closing + len(closing_quote)
    while cursor < len(text) and text[cursor].isspace():
        cursor += 1
    return cursor < len(text) and text[cursor] == ":"


def _verb_is_in_cli_flag_token(text: str, start: int) -> bool:
    """Return whether a fallback verb is part of a hyphen-prefixed token."""
    token_start = start
    while token_start > 0 and (text[token_start - 1].isalnum() or text[token_start - 1] in "_-"):
        token_start -= 1
    return token_start < start and text[token_start] == "-"


def _verb_is_make_strip_function(text: str, match: re.Match[str]) -> bool:
    """Recognize the bounded Make built-in around one simple variable reference.

    This is native function syntax, not a prose marker-removal header. Nested
    functions, dynamic names and incomplete calls retain the lexical fallback.
    """
    start, quote = match.start(), match.start("quote")
    return (
        text[max(0, start - 2) : start] == "$("
        and re.fullmatch(r"strip[ \t]+\$\([A-Za-z_][A-Za-z0-9_]*\)\)[ \t]*", text[start:quote])
        is not None
    )


def _quoted_verb_in_string_sequence(text: str, match: re.Match[str]) -> bool:
    """Return whether the fallback header's quote ends a verb in a string sequence.

    The loose fallback header reads ``verb <filler> '`` as a marker opener.
    When the removal verb is itself a quoted string literal (``'delete'``),
    the matched quote is that literal's closing delimiter, and the literal is
    followed by a separator and another quoted literal, the text is a sequence
    of quoted strings (a list, tuple, or mapping), not a prose instruction:
    reading the closing quote as a marker opener misreads ordinary code such
    as ``['delete', 'run', 'list']`` as an obfuscated directive and fails the
    deterministic layer closed. Matches with any filler between the verb and
    the quote (``delete 'x'``), and quoted verbs not followed by another quoted
    literal (``mode="omit", flag=...``), are unaffected. Backtick identifier
    lists also allow a prefix before the verb, as in ``biome-ignore``.
    """
    quote_index = match.start("quote")
    verb = re.match(_FALLBACK_REMOVAL_VERBS, text[match.start() :], re.IGNORECASE)
    if verb is None or match.start() + verb.end() != quote_index:
        return False
    opener_index = match.start() - 1
    if text[quote_index] == "`" and (opener_index < 0 or text[opener_index] != "`"):
        opener_index = text.rfind(
            "`", max(0, match.start() - MAX_DIRECTIVE_HEADER_CHARS), match.start()
        )
        if (
            opener_index < 0
            or re.fullmatch(r"[A-Za-z0-9_.@-]+", text[opener_index + 1 : quote_index]) is None
        ):
            return False
    if opener_index < 0:
        return False
    opener = text[opener_index]
    if opener not in _QUOTE_OPEN_TO_CLOSE or _QUOTE_OPEN_TO_CLOSE[opener] != text[quote_index]:
        return False
    cursor = quote_index + 1
    while cursor < len(text) and text[cursor] in " \t\r\n,":
        cursor += 1
    return cursor < len(text) and text[cursor] in _ALL_QUOTE_CHARACTERS


def _view_string_closer(
    view: SecurityTextView, validated_string_closer: Callable[[int], bool]
) -> Callable[[int], bool]:
    """Map a source-offset string-closer test onto ``view`` character indexes.

    A derived view keeps the source offset of every character, so only an ASCII
    quote that maps onto a proven closing delimiter is that delimiter.
    """

    def closes_owned_string(index: int) -> bool:
        return view.text[index] in "'\"`" and validated_string_closer(view.source_offset(index))

    return closes_owned_string


def _quoted_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
    closes_owned_string: Callable[[int], bool] | None = None,
    pattern: re.Pattern[str] = _QUOTED_DIRECTIVE_START_RE,
    unsupported_header: bool = False,
) -> Iterator[_Directive]:
    # A complete JSON representation owns its closing quotes; JSON-looking
    # fragments in prose and instructions do not. Only structural closing
    # delimiters are excluded; instruction contents remain available below.
    # ``closes_owned_string`` extends this to proven host-language strings.
    # Like JSON closers, it only stops the loose fallback header: an explicit
    # declared-marker header keeps reading any quote as a marker opener.
    json_value_closers = (
        validated_json_string_closers(text, check_runtime) if unsupported_header else set()
    )
    for match in pattern.finditer(text):
        if check_runtime is not None:
            check_runtime()
        if unsupported_header and _verb_is_in_cli_flag_token(text, match.start()):
            continue
        if unsupported_header and _verb_is_make_strip_function(text, match):
            continue
        if unsupported_header and _is_quoted_mapping_key(text, match.start()):
            continue
        if unsupported_header and _quoted_verb_in_string_sequence(text, match):
            continue
        if match.end() - 1 in json_value_closers:
            continue
        if (
            unsupported_header
            and closes_owned_string is not None
            and closes_owned_string(match.start("quote"))
        ):
            continue
        quote = _QUOTE_OPEN_TO_CLOSE[match.group("quote")]
        marker_start = match.end()
        if quote == "`":
            opener = _BACKTICK_RUN_RE.match(text, match.start("quote"))
            assert opener is not None
            quote = opener[0]
            marker_start = opener.end()
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        cursor = marker_start
        unsupported = unsupported_header or len(quote) > 1
        while cursor < marker_end_limit:
            character = text[cursor]
            if (
                cursor + len(quote) <= marker_end_limit
                and text.startswith(quote, cursor)
                and (
                    len(quote) == 1
                    or (
                        (cursor == marker_start or text[cursor - 1] != "`")
                        and text[cursor + len(quote) : cursor + len(quote) + 1] != "`"
                    )
                )
            ):
                if cursor > marker_start:
                    yield _Directive(
                        text[marker_start:cursor],
                        match.start(),
                        cursor + len(quote),
                        unsupported=unsupported,
                    )
                break
            if character.isspace() or character in _ALL_QUOTE_CHARACTERS:
                unsupported = True
            cursor += 1
        else:
            if marker_end_limit < len(text) or end_is_truncated:
                yield _Directive("", match.start(), marker_end_limit, exhausted=True)


def _passive_quoted_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
) -> Iterator[_Directive]:
    """Parse bounded ``with '<marker>' removed`` declarations."""
    for match in _PASSIVE_QUOTED_DIRECTIVE_START_RE.finditer(text):
        if check_runtime is not None:
            check_runtime()
        close = _QUOTE_OPEN_TO_CLOSE[match.group("quote")]
        marker_start = match.end()
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end = text.find(close, marker_start, marker_end_limit)
        if marker_end < 0:
            if marker_end_limit < len(text) or end_is_truncated:
                yield _Directive("", match.start(), marker_end_limit, exhausted=True)
            continue
        suffix = _PASSIVE_REMOVAL_SUFFIX_RE.match(
            text,
            marker_end + len(close),
            min(len(text), marker_end + len(close) + MAX_DIRECTIVE_HEADER_CHARS),
        )
        if suffix is None or marker_end == marker_start:
            continue
        marker = text[marker_start:marker_end]
        unsupported = any(
            character.isspace() or character in _ALL_QUOTE_CHARACTERS for character in marker
        )
        yield _Directive(
            marker,
            match.start(),
            suffix.end(),
            unsupported=unsupported,
        )


def _passive_encoded_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
) -> Iterator[_Directive]:
    """Parse passive declarations using an encoded quote delimiter."""
    for match in _PASSIVE_ENCODED_DIRECTIVE_START_RE.finditer(text):
        if check_runtime is not None:
            check_runtime()
        opening = match.group("quote")
        closing_pattern = (
            _ENCODED_SINGLE_QUOTE_RE
            if _ENCODED_SINGLE_QUOTE_RE.fullmatch(opening) is not None
            else _ENCODED_DOUBLE_QUOTE_RE
        )
        marker_start = match.end()
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end = closing_pattern.search(text, marker_start, marker_end_limit)
        if marker_end is None:
            if marker_end_limit < len(text) or end_is_truncated:
                yield _Directive(
                    "",
                    match.start(),
                    marker_end_limit,
                    encoded=True,
                    exhausted=True,
                )
            continue
        suffix = _PASSIVE_REMOVAL_SUFFIX_RE.match(
            text,
            marker_end.end(),
            min(len(text), marker_end.end() + MAX_DIRECTIVE_HEADER_CHARS),
        )
        marker = text[marker_start : marker_end.start()]
        if suffix is not None and marker:
            yield _Directive(
                marker,
                match.start(),
                suffix.end(),
                encoded=True,
            )


def _empty_replacement_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
) -> Iterator[_Directive]:
    """Parse bounded declarations that explicitly replace a literal with emptiness."""
    for match in _EMPTY_REPLACEMENT_DIRECTIVE_START_RE.finditer(text):
        if check_runtime is not None:
            check_runtime()
        close = _QUOTE_OPEN_TO_CLOSE[match.group("quote")]
        marker_start = match.end()
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end = text.find(close, marker_start, marker_end_limit)
        if marker_end < 0:
            if marker_end_limit < len(text) or end_is_truncated:
                yield _Directive("", match.start(), marker_end_limit, exhausted=True)
            continue
        marker = text[marker_start:marker_end]
        suffix = _EMPTY_REPLACEMENT_SUFFIX_RE.match(
            text,
            marker_end + len(close),
            min(len(text), marker_end + len(close) + MAX_DIRECTIVE_HEADER_CHARS),
        )
        if not marker or suffix is None:
            continue
        unsupported = any(
            character.isspace() or character in _ALL_QUOTE_CHARACTERS for character in marker
        )
        yield _Directive(
            marker,
            match.start(),
            suffix.end(),
            unsupported=unsupported,
        )


def _can_open_tag_marker(text: str, start: int, limit: int) -> bool:
    """Return whether the ``<`` at ``start`` can still begin a tag marker.

    Code such as ``len(value.strip()) < 12`` or ``a<=b`` puts a comparison
    operator after a removal verb. ``_TAG_MARKER_RE`` can never accept it, so
    the loose fallback header must not search for a distant ``>`` and report
    lookahead exhaustion. A tag name that is still open at ``limit`` remains
    viable so a padded marker keeps failing closed.
    """
    prefix = _TAG_MARKER_PREFIX_RE.match(text, start, limit)
    return prefix is not None and (prefix.end() == limit or text[prefix.end()] == ">")


def _next_tag_opener(
    text: str,
    start: int,
    header_end: int,
    check_runtime: Callable[[], None] | None,
) -> int | None:
    """Return the first ``<`` in ``text[start:header_end]`` that can open a tag marker.

    The loose fallback header stops lazily at the first ``<`` after the verb,
    but it reaches every later ``<`` up to ``header_end`` that no sentence
    boundary or newline separates from the verb. A comparison such as
    ``1 < 2`` must not hide a real marker later in that span, so non-viable
    openers are passed over rather than ending the search. Openers are
    examined left to right and each prefix match stops at the next ``<``, so
    the work stays linear in the bounded header span plus one lookahead.
    """
    boundary = _FALLBACK_HEADER_BOUNDARY_RE.search(text, start, header_end)
    end = boundary.start() if boundary is not None else header_end
    opener = text.find("<", start, end)
    while opener >= 0:
        if check_runtime is not None:
            check_runtime()
        limit = min(len(text), opener + MAX_MARKER_LOOKAHEAD_CHARS)
        if _can_open_tag_marker(text, opener, limit):
            return opener
        opener = text.find("<", opener + 1, end)
    return None


def _tag_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
    pattern: re.Pattern[str] = _TAG_DIRECTIVE_START_RE,
    unsupported_header: bool = False,
    closes_owned_string: Callable[[int], bool] | None = None,
) -> Iterator[_Directive]:
    for match in pattern.finditer(text):
        if check_runtime is not None:
            check_runtime()
        if unsupported_header and _verb_is_in_cli_flag_token(text, match.start()):
            continue
        marker_start = match.start("open")
        if unsupported_header:
            # The header's filler may be at most _MAX_FALLBACK_PREFIX_CHARS
            # long, so an opener can sit at most that far past the verb.
            opener = _next_tag_opener(
                text,
                marker_start,
                match.start("header") + _MAX_FALLBACK_PREFIX_CHARS + 1,
                check_runtime,
            )
            if opener is None:
                continue
            if closes_owned_string is not None and any(
                text[index] in "\"'`" and closes_owned_string(index)
                for index in range(match.start(), opener)
            ):
                continue
            marker_start = opener
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end = text.find(">", marker_start + 1, marker_end_limit)
        if marker_end < 0:
            if marker_end_limit < len(text) or end_is_truncated:
                yield _Directive("", match.start(), marker_end_limit, is_tag=True, exhausted=True)
            continue
        marker = text[marker_start : marker_end + 1]
        if _TAG_MARKER_RE.fullmatch(marker) is not None:
            yield _Directive(
                marker,
                match.start(),
                marker_end + 1,
                is_tag=True,
                unsupported=unsupported_header,
            )


def _encoded_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
    pattern: re.Pattern[str] = _ENCODED_DIRECTIVE_START_RE,
    unsupported_header: bool = False,
) -> Iterator[_Directive]:
    for match in pattern.finditer(text):
        if check_runtime is not None:
            check_runtime()
        if unsupported_header and _verb_is_in_cli_flag_token(text, match.start()):
            continue
        quote = match.group("quote")
        closing_pattern = (
            _ENCODED_SINGLE_QUOTE_RE
            if _ENCODED_SINGLE_QUOTE_RE.fullmatch(quote) is not None
            else _ENCODED_DOUBLE_QUOTE_RE
        )
        marker_start = match.end()
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end_match = closing_pattern.search(text, marker_start, marker_end_limit)
        if marker_end_match is None:
            overpadded_end = _OVERPADDED_ENCODED_ENTITY_RE.search(
                text,
                marker_start,
                marker_end_limit,
            )
            if overpadded_end is not None:
                marker = text[marker_start : overpadded_end.start()]
                if marker:
                    yield _Directive(
                        marker,
                        match.start(),
                        overpadded_end.end(),
                        encoded=True,
                        unsupported=True,
                    )
            elif marker_end_limit < len(text) or end_is_truncated:
                yield _Directive("", match.start(), marker_end_limit, encoded=True, exhausted=True)
            continue
        marker = text[marker_start : marker_end_match.start()]
        if marker and not any(character.isspace() for character in marker):
            yield _Directive(
                marker,
                match.start(),
                marker_end_match.end(),
                encoded=True,
                unsupported=unsupported_header,
            )


def _encoded_tag_directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
    pattern: re.Pattern[str] = _ENCODED_TAG_DIRECTIVE_START_RE,
    unsupported_header: bool = False,
) -> Iterator[_Directive]:
    for match in pattern.finditer(text):
        if check_runtime is not None:
            check_runtime()
        if unsupported_header and _verb_is_in_cli_flag_token(text, match.start()):
            continue
        marker_start = match.start("open")
        marker_end_limit = min(len(text), marker_start + MAX_MARKER_LOOKAHEAD_CHARS)
        marker_end = _ENCODED_TAG_END_RE.search(text, match.end(), marker_end_limit)
        if marker_end is None:
            overpadded_end = _OVERPADDED_ENCODED_ENTITY_RE.search(
                text,
                match.end(),
                marker_end_limit,
            )
            if overpadded_end is not None:
                marker = text[marker_start : overpadded_end.end()]
                yield _Directive(
                    marker,
                    match.start(),
                    overpadded_end.end(),
                    is_tag=True,
                    encoded=True,
                    unsupported=True,
                )
            elif marker_end_limit < len(text) or end_is_truncated:
                yield _Directive(
                    "",
                    match.start(),
                    marker_end_limit,
                    is_tag=True,
                    encoded=True,
                    exhausted=True,
                )
            continue
        yield _Directive(
            text[marker_start : marker_end.end()],
            match.start(),
            marker_end.end(),
            is_tag=True,
            encoded=True,
            unsupported=unsupported_header,
        )


def _directives(
    text: str,
    check_runtime: Callable[[], None] | None,
    *,
    end_is_truncated: bool,
    closes_owned_string: Callable[[int], bool] | None = None,
) -> list[_Directive]:
    candidates = [
        *_passive_quoted_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
        ),
        *_passive_encoded_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
        ),
        *_empty_replacement_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
        ),
        *_quoted_directives(text, check_runtime, end_is_truncated=end_is_truncated),
        *_quoted_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
            closes_owned_string=closes_owned_string,
            pattern=_UNSUPPORTED_QUOTED_DIRECTIVE_START_RE,
            unsupported_header=True,
        ),
        *_tag_directives(text, check_runtime, end_is_truncated=end_is_truncated),
        *_tag_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
            pattern=_UNSUPPORTED_TAG_DIRECTIVE_START_RE,
            unsupported_header=True,
            closes_owned_string=closes_owned_string,
        ),
        *_encoded_directives(text, check_runtime, end_is_truncated=end_is_truncated),
        *_encoded_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
            pattern=_UNSUPPORTED_ENCODED_REPLACEMENT_DIRECTIVE_START_RE,
            unsupported_header=True,
        ),
        *_encoded_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
            pattern=_UNSUPPORTED_ENCODED_DIRECTIVE_START_RE,
            unsupported_header=True,
        ),
        *_encoded_tag_directives(text, check_runtime, end_is_truncated=end_is_truncated),
        *_encoded_tag_directives(
            text,
            check_runtime,
            end_is_truncated=end_is_truncated,
            pattern=_UNSUPPORTED_ENCODED_TAG_DIRECTIVE_START_RE,
            unsupported_header=True,
        ),
    ]
    candidates.sort(key=lambda item: (item.start, item.end, item.marker))
    unique: list[_Directive] = []
    seen: set[tuple[int, int, str]] = set()
    for candidate in candidates:
        key = (candidate.start, candidate.end, candidate.marker)
        if key not in seen:
            unique.append(candidate)
            seen.add(key)
    return unique


def _bounded_sentence_end(
    text: str,
    start: int,
    maximum_end: int,
    *,
    end_is_truncated: bool,
    closes_owned_string: Callable[[int], bool] | None = None,
    context_start: int | None = None,
) -> tuple[int, bool]:
    # A directive can be inside a quoted string; retain that quote's state.
    scan_start = start if context_start is None else context_start
    for boundary_start, _ in _sentence_boundaries(
        text,
        scan_start,
        min(len(text), maximum_end + 1),
        closes_owned_string=closes_owned_string,
    ):
        if start <= boundary_start <= maximum_end:
            return boundary_start, False
    exhausted = maximum_end < len(text) or end_is_truncated
    return maximum_end, exhausted


def _previous_sentence_boundary(text: str, end: int, maximum_span: int) -> int:
    start = max(0, end - maximum_span)
    last_end = start
    for _, boundary_end in _sentence_boundaries(text, start, end):
        last_end = boundary_end
    return last_end


def _is_fence_line(text: str, cursor: int) -> bool:
    """Return whether the backtick run at ``cursor`` opens or closes a CommonMark fence.

    The run must hold at least three backticks and start its line after at most
    three spaces. Only a bare language label (or nothing) may follow it, so a
    run after text, an inline span, or an info string that carries prose stays
    an ordinary quote and keeps failing closed.
    """
    run_end = cursor
    while run_end < len(text) and text[run_end] == "`":
        run_end += 1
    if run_end - cursor < _MARKDOWN_FENCE_MIN_BACKTICKS:
        return False
    line_start = cursor
    while line_start > 0 and cursor - line_start < 3 and text[line_start - 1] == " ":
        line_start -= 1
    if line_start > 0 and text[line_start - 1] != "\n":
        return False
    line_end = text.find("\n", run_end)
    return (
        _FENCE_INFO_RE.fullmatch(text, run_end, len(text) if line_end < 0 else line_end) is not None
    )


def _sentence_boundaries(
    text: str,
    start: int,
    end: int,
    *,
    closes_owned_string: Callable[[int], bool] | None = None,
    quote_spans: tuple[list[int], list[int]] | None = None,
    check_runtime: Callable[[], None] | None = None,
) -> Iterator[tuple[int, int]]:
    """Yield prose boundaries while ignoring punctuation inside balanced quotes."""
    quote_close: str | None = None
    quote_start = start
    cursor = start
    next_runtime_check = start
    while cursor < end:
        if check_runtime is not None and cursor >= next_runtime_check:
            check_runtime()
            next_runtime_check = cursor + 1024
        character = text[cursor]
        if quote_close is None and character == "`" and _is_fence_line(text, cursor):
            # A Markdown code fence line delimits a block; it does not open a
            # quote that would swallow every line break up to the next fence.
            # Any other run of backticks keeps its lexical quote reading.
            while cursor < end and text[cursor] == "`":
                cursor += 1
            continue
        if quote_close is not None:
            if character == "\\" and quote_close in {"'", '"', "`"}:
                cursor += 2
                continue
            if character == quote_close:
                if quote_spans is not None:
                    quote_spans[0].append(quote_start)
                    quote_spans[1].append(cursor + 1)
                quote_close = None
            cursor += 1
            continue
        if character in _QUOTE_OPEN_TO_CLOSE and not (
            character == "'"
            and cursor > 0
            and cursor + 1 < len(text)
            and text[cursor - 1].isalnum()
            and text[cursor + 1].isalnum()
        ):
            # A scan can begin inside an embedded program/string. Its host's
            # proven closing delimiter does not open a new prose quotation
            # that swallows subsequent line boundaries. Existing open quotes
            # still close normally above, and literal contents remain scanned.
            if closes_owned_string is None or not closes_owned_string(cursor):
                quote_start = cursor
                quote_close = _QUOTE_OPEN_TO_CLOSE[character]
        elif character == "\n":
            yield cursor, cursor + 1
        elif character in ".!?" and (cursor + 1 == len(text) or text[cursor + 1].isspace()):
            yield cursor, cursor + 1
        cursor += 1


def _verb_is_negated(text: str, verb_start: int, lower_bound: int) -> bool:
    prefix_start = max(lower_bound, verb_start - MAX_NEGATION_PREFIX_CHARS)
    if _AFFIRMATIVE_NEGATION_PREFIX_RE.search(text, prefix_start, verb_start) is not None:
        return False
    return _NEGATED_ACTION_PREFIX_RE.search(text, prefix_start, verb_start) is not None


def _contextual_action_is_imperative(text: str, action_start: int, lower_bound: int) -> bool:
    prefix = text[max(lower_bound, action_start - 48) : action_start].rstrip()
    if not prefix or prefix[-1] in ".!?;:\n":
        return True
    previous = re.search(r"([A-Za-z]+)[^A-Za-z]*$", prefix)
    return previous is not None and previous.group(1).casefold() in {
        "and",
        "then",
        "please",
        "to",
        "do",
        "must",
        "should",
        "shall",
        "can",
        "will",
        "now",
        "next",
        "only",
        "just",
        "immediately",
    }


def _actions(
    text: str,
    start: int,
    end: int,
    *,
    include_contextual: bool = True,
) -> list[re.Match[str]]:
    matches = [
        action
        for action in _UNAMBIGUOUS_ACTION_RE.finditer(text, start, end)
        if not _verb_is_negated(text, action.start(), start)
    ]
    if include_contextual:
        matches.extend(
            action
            for action in _CONTEXTUAL_ACTION_RE.finditer(text, start, end)
            if _contextual_action_is_imperative(text, action.start(), start)
            and not _verb_is_negated(text, action.start(), start)
        )
        matches.extend(
            action
            for action in _PASTE_ACTION_RE.finditer(text, start, end)
            if _contextual_action_is_imperative(text, action.start(), start)
            and not _verb_is_negated(text, action.start(), start)
        )
    return sorted(matches, key=lambda action: action.start())


def _action_governs_quoted_payload(
    text: str,
    action: re.Match[str],
    quote_start: int,
    quote_end: int,
    scope_end: int,
) -> bool:
    """Require a direct action-to-payload edge instead of word co-occurrence."""
    gap = text[action.end() : quote_start]
    if _ACTION_PAYLOAD_PREFIX_RE.fullmatch(gap) is None:
        return False
    if action.group().casefold() != "paste":
        return True
    return _PASTE_TARGET_RE.match(text, quote_end, scope_end) is not None


def _unsupported_form_actions(
    text: str,
    start: int,
    end: int,
    *,
    include_contextual: bool = False,
) -> list[re.Match[str]]:
    """Return actions strong enough to fail closed without a parsed payload."""
    return _actions(text, start, end, include_contextual=include_contextual)


def _has_action_continuation(text: str, boundary: int, end: int) -> bool:
    cursor = boundary + 1
    while cursor < end and text[cursor].isspace():
        cursor += 1
    then = re.match(r"then\b[ \t]*", text[cursor:end], re.IGNORECASE)
    if then is not None:
        cursor += then.end()
    actions = _actions(text, cursor, min(end, cursor + 64))
    return bool(actions) and actions[0].start() == cursor


def _action_immediately_precedes_boundary(text: str, start: int, boundary: int) -> bool:
    actions = _actions(text, start, boundary)
    if not actions:
        return False
    return text[actions[-1].end() : boundary].strip() in {"", ":"}


def _quoted_spans(text: str, start: int, end: int) -> Iterator[tuple[int, int, int, int]]:
    """Yield bounded quote/body spans for ASCII and typographic quote pairs."""
    cursor = start
    while cursor < end:
        opening = _PAYLOAD_QUOTE_OPEN_RE.search(text, cursor, end)
        if opening is None:
            return
        close = _QUOTE_OPEN_TO_CLOSE[opening.group()]
        body_start = opening.end()
        close_at = text.find(close, body_start, min(end, body_start + MAX_PAYLOAD_CHARS + 1))
        if close_at < 0:
            cursor = opening.end()
            continue
        if any(character in _ALL_QUOTE_CHARACTERS for character in text[body_start:close_at]):
            cursor = close_at + 1
            continue
        yield opening.start(), body_start, close_at, close_at + len(close)
        cursor = close_at + len(close)


def _quoted_payloads(text: str, directive: _Directive, scope_end: int) -> list[_Payload]:
    actions = _actions(text, directive.end, scope_end)
    if not actions:
        return []
    payloads: set[tuple[int, int]] = set()
    for quote_start, body_start, body_end, quote_end in _quoted_spans(
        text,
        directive.end,
        scope_end,
    ):
        if quote_end < len(text) and text[quote_end].isalnum():
            continue
        if text.find(directive.marker, body_start, body_end) < 0:
            continue
        if any(
            action.end() <= quote_start
            and _action_governs_quoted_payload(
                text,
                action,
                quote_start,
                quote_end,
                scope_end,
            )
            for action in actions
        ):
            payloads.add((body_start, body_end))
    return [_Payload(start, end) for start, end in sorted(payloads)]


def _anaphoric_payloads(text: str, directive: _Directive, lookahead_end: int) -> list[_Payload]:
    """Bind a declared source quote to a later explicit ``execute it/result`` action."""
    payloads: set[tuple[int, int]] = set()
    for quote_start, body_start, body_end, quote_end in _quoted_spans(
        text,
        directive.end,
        lookahead_end,
    ):
        source_prefix = text[directive.end : quote_start]
        if (
            _REMOVAL_PAYLOAD_PREFIX_RE.fullmatch(source_prefix) is None
            and _COPY_PAYLOAD_PREFIX_RE.fullmatch(source_prefix) is None
        ):
            continue
        if text.find(directive.marker, body_start, body_end) < 0:
            continue
        for action in _ANAPHORIC_ACTION_RE.finditer(text, quote_end, lookahead_end):
            if _verb_is_negated(text, action.start(), quote_end):
                continue
            if (
                action.group("action").casefold() == "paste"
                and _PASTE_TARGET_RE.match(
                    text,
                    action.end(),
                    lookahead_end,
                )
                is None
            ):
                continue
            payloads.add((body_start, body_end))
            break
    return [_Payload(start, end) for start, end in sorted(payloads)]


def _inline_payloads(text: str, directive: _Directive, scope_end: int) -> list[_Payload]:
    payloads: set[tuple[int, int]] = set()
    for action in _actions(text, directive.end, scope_end):
        if action.group().casefold() == "paste":
            continue
        explicit_prefix = _EXPLICIT_ACTION_PAYLOAD_PREFIX_RE.match(
            text,
            action.end(),
            scope_end,
        )
        prefix = explicit_prefix or _ACTION_PAYLOAD_PREFIX_RE.match(
            text,
            action.end(),
            scope_end,
        )
        start = prefix.end() if prefix is not None else action.end()
        if start >= scope_end or text[start] in _ALL_QUOTE_CHARACTERS:
            continue
        end = min(scope_end, start + MAX_PAYLOAD_CHARS)
        if explicit_prefix is None:
            first_token_end = start
            while first_token_end < end and not text[first_token_end].isspace():
                first_token_end += 1
            marker_at = text.find(directive.marker, start, end)
            if marker_at < 0:
                continue
            before_marker = text[start:marker_at]
            if (
                marker_at >= first_token_end
                and _INLINE_SHELL_WRAPPER_RE.fullmatch(before_marker) is None
            ):
                continue
        if text.find(directive.marker, start, end) >= 0:
            payloads.add((start, end))
    return [_Payload(start, end) for start, end in sorted(payloads)]


def _has_coordinated_marker(
    text: str,
    directive: _Directive,
    payloads: list[_Payload],
    scope_end: int,
) -> bool:
    """Return whether another declared literal also participates in the payload."""
    actions = _actions(text, directive.end, scope_end)
    if not actions or not payloads:
        return False
    for _, marker_start, marker_end, _ in _quoted_spans(
        text,
        directive.end,
        actions[0].start(),
    ):
        marker = text[marker_start:marker_end]
        if not marker or marker == directive.marker or len(marker) > MAX_MARKER_LENGTH:
            continue
        if any(marker in text[payload.start : payload.end] for payload in payloads):
            return True
    return False


def _has_active_unsupported_form(
    text: str,
    directive: _Directive,
    lookahead_end: int,
) -> bool:
    clause_start = _previous_sentence_boundary(text, directive.start, MAX_MARKER_LOOKAHEAD_CHARS)
    tail = text[directive.end : lookahead_end]
    marker_in_tail = directive.marker in tail
    actions_after = _unsupported_form_actions(
        text,
        directive.end,
        lookahead_end,
        include_contextual=True,
    )
    actions_before = _unsupported_form_actions(
        text,
        clause_start,
        directive.start,
        include_contextual=True,
    )

    for quote_start, body_start, body_end, quote_end in _quoted_spans(
        text,
        directive.end,
        lookahead_end,
    ):
        body = text[body_start:body_end]
        if directive.marker.casefold() not in body.casefold():
            continue
        if any(
            action.end() <= quote_start
            and _action_governs_quoted_payload(
                text,
                action,
                quote_start,
                quote_end,
                lookahead_end,
            )
            for action in actions_after
        ):
            return True
        for action in actions_after:
            if (
                action.end() > quote_start
                or _UNAMBIGUOUS_ACTION_RE.fullmatch(action.group()) is None
                or not _contextual_action_is_imperative(text, action.start(), directive.end)
            ):
                continue
            unsupported_gap = text[action.end() : quote_start]
            if len(unsupported_gap) <= 48 and re.fullmatch(
                r"[ \t]+(?:[A-Za-z-]+[ \t]+){0,2}",
                unsupported_gap,
            ):
                return True

    # ``Execute this after removing 'x' from '<payload>'`` puts the action
    # before the declaration but the governed source payload after it.  The
    # order is unambiguous enough to fail closed, but not to reconstruct and
    # claim a definite finding.
    if (
        actions_before
        and re.search(
            r"\bafter(?:[ \t]+(?:this|that|it|the[ \t]+result))?[ \t]+$",
            text[actions_before[-1].end() : directive.start],
            re.IGNORECASE,
        )
        is not None
    ):
        for quote_start, body_start, body_end, _ in _quoted_spans(
            text,
            directive.end,
            lookahead_end,
        ):
            if (
                _REMOVAL_PAYLOAD_PREFIX_RE.fullmatch(text[directive.end : quote_start]) is not None
                and directive.marker in text[body_start:body_end]
            ):
                return True

    if marker_in_tail:
        for action in actions_after:
            if action.group().casefold() == "paste":
                continue
            prefix = _ACTION_PAYLOAD_PREFIX_RE.match(text, action.end(), lookahead_end)
            if prefix is None:
                continue
            payload_start = prefix.end()
            while payload_start < lookahead_end and text[payload_start].isspace():
                payload_start += 1
            marker_at = text.find(directive.marker, payload_start, lookahead_end)
            if marker_at >= 0 and not any(
                character.isspace() for character in text[payload_start:marker_at]
            ):
                return True

    # Handle the natural reverse order: the governed payload appears first and
    # the literal-removal declaration follows ("execute '<payload>' after
    # removing '<marker>'").  This is ambiguous rather than safe, so callers
    # report an incomplete deterministic analysis instead of reconstructing it.
    for quote_start, body_start, body_end, quote_end in _quoted_spans(
        text,
        clause_start,
        directive.start,
    ):
        if text.find(directive.marker, body_start, body_end) < 0:
            continue
        if any(
            action.end() <= quote_start
            and _action_governs_quoted_payload(
                text,
                action,
                quote_start,
                quote_end,
                directive.start,
            )
            for action in actions_before
        ):
            return True

    for action in actions_before:
        if action.group().casefold() == "paste":
            continue
        explicit_prefix = _EXPLICIT_ACTION_PAYLOAD_PREFIX_RE.match(
            text,
            action.end(),
            directive.start,
        )
        prefix = explicit_prefix or _ACTION_PAYLOAD_PREFIX_RE.match(
            text,
            action.end(),
            directive.start,
        )
        if prefix is None:
            continue
        marker_at = text.find(directive.marker, prefix.end(), directive.start)
        if marker_at < 0:
            continue
        if explicit_prefix is not None or not text[prefix.end() : marker_at].strip():
            return True

    # A quoted payload may precede the declaration while an explicit anaphoric
    # action follows it: ``'<payload>'; remove '<marker>' and execute it``.
    if any(
        directive.marker in text[body_start:body_end]
        for _, body_start, body_end, _ in _quoted_spans(
            text,
            clause_start,
            directive.start,
        )
    ) and any(
        not _verb_is_negated(text, action.start(), directive.end)
        for action in _ANAPHORIC_ACTION_RE.finditer(text, directive.end, lookahead_end)
    ):
        return True

    if marker_in_tail:
        # A newly exposed command/action token matters only in instruction
        # text. Quoted examples are inert unless a parsed action explicitly
        # governs the quote, which is handled by the payload binders above.
        unquoted_tail = list(tail)
        for quote_start, _, _, quote_end in _quoted_spans(tail, 0, len(tail)):
            unquoted_tail[quote_start:quote_end] = " " * (quote_end - quote_start)
        active_tail = "".join(unquoted_tail)
        decoded_tail = active_tail.replace(directive.marker, "")
        original_action_names = Counter(
            action.group().casefold()
            for action in _unsupported_form_actions(
                active_tail,
                0,
                len(active_tail),
                include_contextual=True,
            )
        )
        decoded_actions = _unsupported_form_actions(
            decoded_tail,
            0,
            len(decoded_tail),
            include_contextual=True,
        )
        decoded_action_names = Counter(action.group().casefold() for action in decoded_actions)
        if any(count > original_action_names[name] for name, count in decoded_action_names.items()):
            return True
        original_active_tokens = Counter(
            match.group().casefold() for match in _DECODED_ACTIVE_TOKEN_RE.finditer(active_tail)
        )
        decoded_active_tokens = Counter(
            match.group().casefold() for match in _DECODED_ACTIVE_TOKEN_RE.finditer(decoded_tail)
        )
        if any(
            count > original_active_tokens[name] for name, count in decoded_active_tokens.items()
        ):
            return True
    return False


def _positions_and_overlap(
    text: str, marker: str, start: int, end: int
) -> tuple[tuple[int, ...], bool]:
    positions: list[int] = []
    cursor = start
    last_end = start
    overlapping = False
    while cursor < end:
        found = text.find(marker, cursor, end)
        if found < 0:
            break
        if found < last_end:
            overlapping = True
        else:
            positions.append(found)
            last_end = found + len(marker)
        cursor = found + 1
    return tuple(positions), overlapping


def _paired_tag(marker: str) -> str | None:
    opening = re.fullmatch(r"<([A-Za-z][A-Za-z0-9:_-]*)>", marker)
    if opening is not None:
        return f"</{opening.group(1)}>"
    closing = re.fullmatch(r"</([A-Za-z][A-Za-z0-9:_-]*)>", marker)
    if closing is not None:
        return f"<{closing.group(1)}>"
    return None


def _retained_ranges(
    start: int, end: int, marker: str, positions: tuple[int, ...]
) -> Iterator[tuple[int, int]]:
    cursor = start
    for position in positions:
        if cursor < position:
            yield cursor, position
        cursor = position + len(marker)
    if cursor < end:
        yield cursor, end


def _project_payload(view: SecurityTextView, candidate: _ProjectionCandidate) -> SecurityTextView:
    output = StringIO()
    offsets = array("I")
    ends = array("I") if view.source_end_offsets is not None else None
    for start, end in _retained_ranges(
        candidate.payload.start,
        candidate.payload.end,
        candidate.directive.marker,
        candidate.positions,
    ):
        output.write(view.text[start:end])
        if view.source_offsets is None:
            offsets.extend(range(start, end))
        else:
            offsets.extend(view.source_offsets[start:end])
        if ends is not None:
            ends.extend(view.source_end_offsets[start:end])
    return SecurityTextView(
        name=f"declared-marker-{view.name}",
        text=output.getvalue(),
        source_offsets=offsets,
        source_end_offsets=ends,
    )


def _classify_directive(
    view: SecurityTextView,
    directive: _Directive,
    *,
    end_is_truncated: bool,
    closes_owned_string: Callable[[int], bool] | None = None,
    context_start: int | None = None,
) -> _DirectiveClassification:
    if directive.exhausted:
        return _DirectiveClassification(None, False, True)

    baseline = None
    if context_start is not None or closes_owned_string is not None:
        baseline = _classify_directive(
            view,
            directive,
            end_is_truncated=end_is_truncated,
        )
        if baseline.active or not baseline.limited:
            return baseline
        if directive.unsupported and ("\n" in directive.marker or "\r" in directive.marker):
            # A marker crossing physical lines cannot borrow a later literal's
            # closing quote to clear its original incomplete interpretation.
            return baseline

    clause_start = _previous_sentence_boundary(
        view.text,
        directive.start,
        MAX_MARKER_LOOKAHEAD_CHARS,
    )
    scope_cap = min(len(view.text), directive.end + MAX_MARKER_SCOPE_CHARS)
    scope_end, _ = _bounded_sentence_end(
        view.text,
        directive.end,
        scope_cap,
        end_is_truncated=end_is_truncated,
        closes_owned_string=closes_owned_string,
        context_start=context_start,
    )
    lookahead_cap = min(len(view.text), directive.end + MAX_MARKER_LOOKAHEAD_CHARS)
    lookahead_end, lookahead_exhausted = _bounded_sentence_end(
        view.text,
        directive.end,
        lookahead_cap,
        end_is_truncated=end_is_truncated,
        closes_owned_string=closes_owned_string,
        context_start=context_start,
    )
    first_sentence_end = lookahead_end
    directive_clause = view.text[clause_start:first_sentence_end]
    if first_sentence_end < lookahead_cap and (
        _FORWARD_PAYLOAD_REFERENCE_RE.search(directive_clause) is not None
        or _has_action_continuation(view.text, first_sentence_end, lookahead_cap)
        or _action_immediately_precedes_boundary(
            view.text,
            directive.end,
            first_sentence_end,
        )
    ):
        lookahead_end, continuation_exhausted = _bounded_sentence_end(
            view.text,
            first_sentence_end + 1,
            lookahead_cap,
            end_is_truncated=end_is_truncated,
            closes_owned_string=closes_owned_string,
        )
        lookahead_exhausted = lookahead_exhausted or continuation_exhausted
    if baseline is not None and any(
        pattern.search(
            view.text,
            min(clause_start, context_start) if context_start is not None else clause_start,
            lookahead_end,
        )
        is not None
        for pattern in (
            _UNAMBIGUOUS_ACTION_RE,
            _CONTEXTUAL_ACTION_RE,
            _PASTE_ACTION_RE,
        )
    ):
        # Even an unbound action can acquire its payload through adjacent
        # literals. Wrapper proof may repair an inert method-like header, but
        # it cannot clear a prior limit for a potentially active instruction.
        # Proven host closers have the same restriction: adjacent literals can
        # supply the payload after a closer shortens the lexical sentence.
        # Ambiguous or negated action cues also retain that conservative result.
        return baseline
    payloads = _quoted_payloads(view.text, directive, scope_end)
    if not payloads:
        payloads = _anaphoric_payloads(view.text, directive, lookahead_end)
    if not payloads:
        payloads = _inline_payloads(view.text, directive, scope_end)
    coordinated_marker = _has_coordinated_marker(
        view.text,
        directive,
        payloads,
        scope_end,
    )
    active = bool(payloads) or _has_active_unsupported_form(
        view.text,
        directive,
        lookahead_end,
    )
    if not active:
        return _DirectiveClassification(None, False, lookahead_exhausted)

    if (
        directive.encoded
        or directive.unsupported
        or coordinated_marker
        or len(directive.marker) > MAX_MARKER_LENGTH
        or len(payloads) != 1
    ):
        return _DirectiveClassification(None, True, True)

    payload = payloads[0]
    if len(directive.marker) == 1 and directive.marker.isalnum():
        return _DirectiveClassification(None, True, True)
    paired_tag = _paired_tag(directive.marker) if directive.is_tag else None
    if paired_tag is not None and paired_tag in view.text[payload.start : payload.end]:
        return _DirectiveClassification(None, True, True)
    positions, overlapping = _positions_and_overlap(
        view.text,
        directive.marker,
        payload.start,
        payload.end,
    )
    if overlapping or len(positions) > MAX_MARKER_REMOVALS:
        return _DirectiveClassification(None, True, True)
    candidate = _ProjectionCandidate(directive, payload, positions) if positions else None
    return _DirectiveClassification(candidate, True, lookahead_exhausted)


def _resolve_candidates(
    view: SecurityTextView,
    candidates: list[_ProjectionCandidate],
) -> tuple[tuple[SecurityTextView, ...], bool]:
    by_payload: dict[tuple[int, int], list[_ProjectionCandidate]] = {}
    for candidate in candidates:
        by_payload.setdefault((candidate.payload.start, candidate.payload.end), []).append(
            candidate
        )

    limited = False
    views: list[SecurityTextView] = []
    seen_views: set[tuple[str, int, int]] = set()
    for payload_key, payload_candidates in by_payload.items():
        if len({candidate.directive.marker for candidate in payload_candidates}) > 1:
            limited = True
            continue
        projected = _project_payload(view, payload_candidates[0])
        key = (projected.text, *payload_key)
        if projected.text and key not in seen_views:
            views.append(projected)
            seen_views.add(key)
    return tuple(views), limited


def build_declared_marker_views(
    view: SecurityTextView,
    *,
    check_runtime: Callable[[], None] | None = None,
    owned_source_start: int | None = None,
    owned_source_end: int | None = None,
    source_end_is_truncated: bool = False,
    validated_string_closer: Callable[[int], bool] | None = None,
) -> DeclaredMarkerViewResult:
    """Build one-pass payload views for explicit literal-removal instructions.

    The function never evaluates projected text. It accepts one unnegated,
    action-bound payload per directive; ambiguous or resource-bounded active
    forms set ``limited`` so the caller can fail closed without guessing.

    The optional ownership bounds are source coordinates in the current raw
    window. Directives before ``owned_source_start`` belong to the previous
    window; directives at or beyond exclusive ``owned_source_end`` belong to
    the next window. ``source_end_is_truncated`` separately records whether the
    physical view ends before the source, so ownership alone never degrades a
    complete end-of-file directive.

    ``validated_string_closer`` optionally reports whether a source offset, in
    the same coordinates, is the closing delimiter of a string literal that a
    complete host-language parse has proven. Such a quote is syntax that ends a
    literal, so the loose fallback header never reads it as a marker opener,
    exactly as for a validated JSON string. Explicit declared-marker headers and
    callers without the test keep the lexical reading.
    """
    if check_runtime is not None:
        check_runtime()
    view = _decode_ascii_letter_entities_view(view)
    view = _compact_spaced_security_word_view(view)
    if (
        _DIRECTIVE_PREFILTER_RE.search(view.text) is None
        and _PASSIVE_DIRECTIVE_PREFILTER_RE.search(view.text) is None
    ):
        return DeclaredMarkerViewResult((), False)

    closes_owned_string = (
        None
        if validated_string_closer is None
        else _view_string_closer(view, validated_string_closer)
    )
    active_directives = 0
    limited = False
    first_limited_source_offset: int | None = None
    projection_blocked = False
    candidates: list[_ProjectionCandidate] = []
    quote_spans: tuple[list[int], list[int]] | None = None
    for directive in _directives(
        view.text,
        check_runtime,
        end_is_truncated=source_end_is_truncated,
        closes_owned_string=closes_owned_string,
    ):
        if check_runtime is not None:
            check_runtime()
        directive_source_start = view.source_offset(directive.start)
        if (owned_source_start is not None and directive_source_start < owned_source_start) or (
            owned_source_end is not None and directive_source_start >= owned_source_end
        ):
            continue

        clause_start = _previous_sentence_boundary(
            view.text,
            directive.start,
            MAX_MARKER_LOOKAHEAD_CHARS,
        )
        if _verb_is_negated(view.text, directive.start, clause_start):
            continue

        context_start = None
        marker_quote = directive.end - len(directive.marker) - 2
        if (
            not source_end_is_truncated
            and owned_source_start in (None, 0)
            and view.source_offset(0) == 0
            and directive.marker
            and directive.unsupported
            and not directive.encoded
            and not directive.is_tag
            and directive.start <= marker_quote
            and _QUOTE_OPEN_TO_CLOSE.get(view.text[marker_quote]) == view.text[directive.end - 1]
            and view.text[marker_quote + 1 : directive.end - 1] == directive.marker
        ):
            # A bounded lookbehind can start inside an unrelated literal.
            # Only a balanced, different-quote wrapper scanned from the view's
            # origin can supply context; a marker opened by that wrapper's
            # own closer keeps the conservative forward-only reading.
            if quote_spans is None:
                quote_spans = ([], [])
                for _ in _sentence_boundaries(
                    view.text,
                    0,
                    len(view.text),
                    quote_spans=quote_spans,
                    closes_owned_string=closes_owned_string,
                    check_runtime=check_runtime,
                ):
                    pass
            starts, ends = quote_spans
            index = bisect_right(starts, directive.start) - 1
            if (
                index >= 0
                and starts[index] < directive.start
                and directive.end < ends[index]
                and directive.end - starts[index] <= MAX_MARKER_LOOKAHEAD_CHARS
                and view.text[starts[index]] != view.text[marker_quote]
            ):
                context_start = starts[index]

        classification = _classify_directive(
            view,
            directive,
            end_is_truncated=source_end_is_truncated,
            closes_owned_string=closes_owned_string,
            context_start=context_start,
        )
        limited = limited or classification.limited
        if classification.limited and first_limited_source_offset is None:
            first_limited_source_offset = directive_source_start
        if classification.active and classification.limited:
            projection_blocked = True
            candidates.clear()
        if not classification.active:
            continue

        active_directives += 1
        if active_directives > MAX_ACTIVE_DIRECTIVES:
            limited = True
            break
        if classification.candidate is not None and not projection_blocked:
            candidates.append(classification.candidate)

    views, conflict_limited = _resolve_candidates(view, candidates)
    return DeclaredMarkerViewResult(views, limited or conflict_limited, first_limited_source_offset)
