# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Generic OpenAI-compatible provider — Groq, Together AI, Mistral, etc.

Serves any endpoint that speaks the OpenAI chat completion protocol.
Uses dedicated ``SKILLSPECTOR_COMPAT_*`` env vars so credentials are not
confused with stock OpenAI settings.

Required env vars:
    SKILLSPECTOR_COMPAT_API_KEY   — API key for the target provider
    SKILLSPECTOR_COMPAT_BASE_URL  — Base URL (e.g. https://api.groq.com/openai/v1)

Optional env vars:
    SKILLSPECTOR_COMPAT_HEADERS   — JSON object with string header names and values

Some endpoints ignore both ``response_format`` and a forced ``tool_choice``
and answer in prose.  A registry entry with ``tool_choice: auto`` binds the
schema as a tool with ``tool_choice`` left at ``auto``; the prompt then asks
for the tool call and a prose answer is retried.  Model IDs that name a Claude
model rejecting forced tool calls (``anthropic/claude-opus-5-5``) take the same
path without a registry entry.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from langchain_core.language_models.chat_models import BaseChatModel

from skillspector.providers import registry
from skillspector.providers.chat_models import (
    create_openai_compatible_chat_model,
    prepare_openai_chat_model_imports,
)
from skillspector.providers.structured_output import forced_tool_choice_supported

REGISTRY_PATH = str(Path(__file__).with_name("model_registry.yaml"))


def _resolve_compat_headers() -> dict[str, str] | None:
    raw_headers = os.environ.get("SKILLSPECTOR_COMPAT_HEADERS", "").strip()
    if not raw_headers:
        return None

    error_message = "SKILLSPECTOR_COMPAT_HEADERS must be a JSON object with string keys and values"
    try:
        headers = json.loads(raw_headers)
    except json.JSONDecodeError:
        raise ValueError(error_message) from None

    if not isinstance(headers, dict) or any(
        not isinstance(key, str) or not isinstance(value, str) for key, value in headers.items()
    ):
        raise ValueError(error_message)

    return headers


class OpenAICompatibleProvider:
    """Generic OpenAI-compatible credentials + bundled-YAML metadata provider."""

    DEFAULT_MODEL = "llama-3.1-70b-versatile"
    SLOT_DEFAULTS: dict[str, str] = {}

    def prepare_chat_model_imports(self) -> None:
        """Prepare the OpenAI transport without resolving or creating a client."""
        prepare_openai_chat_model_imports()

    def resolve_credentials(self) -> tuple[str, str | None] | None:
        """Return ``(api_key, base_url)`` from ``SKILLSPECTOR_COMPAT_*`` env vars."""
        api_key = os.environ.get("SKILLSPECTOR_COMPAT_API_KEY", "").strip()
        base_url = os.environ.get("SKILLSPECTOR_COMPAT_BASE_URL", "").strip()
        if not api_key or not base_url:
            return None
        return api_key, base_url

    def create_chat_model(
        self,
        model: str,
        *,
        max_tokens: int,
        timeout: float | None = 120,
    ) -> BaseChatModel | None:
        """Create ``ChatOpenAI`` for the configured compatible endpoint."""
        return create_openai_compatible_chat_model(
            model=model,
            credentials=self.resolve_credentials(),
            max_tokens=max_tokens,
            timeout=timeout,
            default_headers=_resolve_compat_headers(),
            forced_tool_choice=self.forced_tool_choice_supported(model),
        )

    def get_context_length(self, model: str) -> int | None:
        return registry.lookup_context_length(REGISTRY_PATH, model)

    def get_max_output_tokens(self, model: str) -> int | None:
        return registry.lookup_max_output_tokens(REGISTRY_PATH, model)

    def resolve_model(self, slot: str = "default") -> str:
        """Resolve model: ``SKILLSPECTOR_MODEL`` env > slot default > ``DEFAULT_MODEL``."""
        user_input = os.environ.get("SKILLSPECTOR_MODEL", "").strip()
        return user_input or self.SLOT_DEFAULTS.get(slot, "") or self.DEFAULT_MODEL

    def forced_tool_choice_supported(self, model: str) -> bool:
        """``False`` when the registry declares ``tool_choice: auto`` for *model*.

        Without a registry entry, ``False`` when *model* names a Claude model
        that rejects a forced tool call.
        """
        return forced_tool_choice_supported(model, REGISTRY_PATH)

    def structured_output_method(self, model: str) -> str | None:
        """``with_structured_output`` method: registry entry, else tool calling for ``tool_choice: auto``."""
        declared = registry.lookup_structured_output_method(REGISTRY_PATH, model)
        if declared:
            return declared
        return None if self.forced_tool_choice_supported(model) else "function_calling"
