# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared constructors for provider-backed LangChain chat models."""

from __future__ import annotations

import logging
import os
from importlib import import_module
from urllib.parse import urlparse

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.outputs import ChatResult
from langchain_openai import AzureChatOpenAI as _AzureChatOpenAI
from langchain_openai import ChatOpenAI as _ChatOpenAI
from pydantic import BaseModel, SecretStr

from skillspector.inference_usage import (
    register_chat_model_controls,
    retained_chat_model_controls,
)
from skillspector.providers.structured_output import is_gpt_6_1_sol, rejects_sampling_controls

logger = logging.getLogger(__name__)
MIN_SAMPLING_SEED = -(1 << 63)
MAX_SAMPLING_SEED = (1 << 63) - 1

# Reasoning efforts GPT-6.1 Sol accepts; it rejects ``none`` and ``minimal``.
GPT_6_1_SOL_REASONING_EFFORTS = ("low", "medium", "high", "xhigh", "max")


class _RawToolArguments:
    """Retain wire arguments before SDK parsing loses duplicate keys or empty text."""

    def _create_chat_result(
        self, response: dict | BaseModel, generation_info: dict | None = None
    ) -> ChatResult:
        result = super()._create_chat_result(response, generation_info)
        payload = (
            response
            if isinstance(response, dict)
            else response.model_dump(exclude={"choices": {"__all__": {"message": {"parsed"}}}})
        )
        for generation, choice in zip(result.generations, payload["choices"], strict=True):
            calls = choice["message"].get("tool_calls")
            if calls is not None:
                generation.message.additional_kwargs["tool_calls"] = calls
        return result


class ChatOpenAI(_RawToolArguments, _ChatOpenAI):
    """OpenAI-compatible invoke/ainvoke preserving original tool response evidence."""


class AzureChatOpenAI(_RawToolArguments, _AzureChatOpenAI):
    """Native Azure invoke/ainvoke with the same tool response evidence."""


def prepare_openai_chat_model_imports() -> None:
    """Load lazy transport/resource modules before concurrent CPU-heavy analysis."""
    import_module("httpcore")
    import_module("openai.resources.chat.completions.completions")


class UnsupportedControlError(ValueError):
    """A requested sampling or reasoning control the model rejects, raised before any request."""


def resolve_reasoning_effort() -> str | None:
    """Resolve the optional provider- and model-dependent reasoning effort."""
    reasoning_effort = os.environ.get("SKILLSPECTOR_REASONING_EFFORT", "").strip()
    return reasoning_effort or None


def resolve_temperature() -> float | None:
    """Resolve the optional temperature using the provider validation contract."""
    raw_temperature = os.environ.get("SKILLSPECTOR_TEMPERATURE", "").strip()
    if not raw_temperature:
        return None
    try:
        temperature = float(raw_temperature)
    except ValueError as exc:
        raise ValueError("SKILLSPECTOR_TEMPERATURE must be a number between 0 and 1") from exc
    if not 0 <= temperature <= 1:
        raise ValueError("SKILLSPECTOR_TEMPERATURE must be between 0 and 1")
    return temperature


def resolve_seed() -> int | None:
    """Resolve the optional seed within the portable signed 64-bit contract."""
    raw_seed = os.environ.get("SKILLSPECTOR_SEED", "").strip()
    if not raw_seed:
        return None
    try:
        seed = int(raw_seed)
    except ValueError as exc:
        raise ValueError("SKILLSPECTOR_SEED must be an integer") from exc
    if not MIN_SAMPLING_SEED <= seed <= MAX_SAMPLING_SEED:
        raise ValueError("SKILLSPECTOR_SEED must be a signed 64-bit integer")
    return seed


def resolve_sampling_parameters(
    model: str,
    *,
    include_seed: bool = False,
    reasoning_effort: str | None = None,
    registry_path: str | None = None,
    native_anthropic: bool = False,
) -> dict[str, float | int]:
    """Resolve optional, validated sampling controls for a request to *model*.

    Raises :class:`UnsupportedControlError` when *model* rejects the requested
    temperature or *reasoning_effort* (see :func:`reject_unsupported_controls`),
    so every hosted provider applies the same guard before any request.
    Only the official Anthropic endpoint sets *native_anthropic* to allow
    Claude's backwards-compatible ``temperature=1.0``.
    """
    parameters: dict[str, float | int] = {}
    temperature = resolve_temperature()
    if temperature is not None:
        parameters["temperature"] = temperature

    seed = resolve_seed() if include_seed else None
    if seed is not None:
        parameters["seed"] = seed
    reject_unsupported_controls(
        model,
        parameters,
        reasoning_effort,
        registry_path=registry_path,
        native_anthropic=native_anthropic,
    )
    return parameters


def reject_unsupported_controls(
    model: str,
    sampling_parameters: dict[str, float | int],
    reasoning_effort: str | None = None,
    *,
    registry_path: str | None = None,
    native_anthropic: bool = False,
) -> None:
    """Raise :class:`UnsupportedControlError` when *model* rejects a requested control.

    Any explicit ``temperature``, ``1.0`` included, fails for GPT-6.1 Sol, the
    Claude models in ``SAMPLING_REJECTED_MODELS``, and registry entries at
    *registry_path* declaring ``sampling: rejected``. The official Anthropic
    endpoint accepts ``1.0`` for the known Claude models when
    *native_anthropic* is set; other routes keep the strict guard.
    GPT-6.1 Sol also accepts only ``GPT_6_1_SOL_REASONING_EFFORTS``.
    """
    sol = is_gpt_6_1_sol(model)
    native_default_temperature = (
        native_anthropic
        and sampling_parameters.get("temperature") == 1.0
        and rejects_sampling_controls(model)
    )
    if "temperature" in sampling_parameters and (
        sol or (rejects_sampling_controls(model, registry_path) and not native_default_temperature)
    ):
        raise UnsupportedControlError(
            f"SKILLSPECTOR_TEMPERATURE is not supported by {model}; unset it to use this model"
        )
    if (
        sol
        and reasoning_effort is not None
        and reasoning_effort not in GPT_6_1_SOL_REASONING_EFFORTS
    ):
        raise UnsupportedControlError(
            f"SKILLSPECTOR_REASONING_EFFORT={reasoning_effort!r} is not supported by {model}; "
            f"use one of {', '.join(GPT_6_1_SOL_REASONING_EFFORTS)} or unset it"
        )


def validate_base_url(url: str | None) -> None:
    """Warn if *url* is not a well-formed http(s) URL.

    Raises nothing — misconfigured URLs will still fail at the HTTP
    layer, but an early warning helps operators catch typos.
    """
    if url is None:
        return
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        logger.warning(
            "Provider base_url %r has scheme %r — expected http or https. "
            "Requests will likely fail.",
            url,
            parsed.scheme or "(empty)",
        )
    if not parsed.netloc:
        logger.warning(
            "Provider base_url %r has no host component. Requests will likely fail.",
            url,
        )


def create_openai_compatible_chat_model(
    *,
    model: str,
    credentials: tuple[str, str | None] | None,
    max_tokens: int,
    timeout: float | None = 120,
    default_headers: dict[str, str] | None = None,
    forced_tool_choice: bool = True,
    default_reasoning_effort: str | None = None,
    chat_model_class: type[ChatOpenAI] | None = None,
) -> BaseChatModel | None:
    """Create ``ChatOpenAI`` for providers serving OpenAI-compatible endpoints.

    ``forced_tool_choice=False`` sets ``disabled_params={"tool_choice": None}``
    so ``with_structured_output`` never forces a tool call; this is the shape
    ``llm_utils._binds_unforced_tool_call`` looks for.
    """
    if credentials is None:
        return None

    api_key, base_url = credentials
    validate_base_url(base_url)
    kwargs = {
        "model": model,
        "base_url": base_url,
        "api_key": SecretStr(api_key),
        "max_completion_tokens": max_tokens,
        "timeout": timeout,
        "default_headers": default_headers,
    }
    if not forced_tool_choice:
        kwargs["disabled_params"] = {"tool_choice": None}
    reasoning_effort = resolve_reasoning_effort()
    if reasoning_effort or default_reasoning_effort:
        kwargs["reasoning_effort"] = reasoning_effort or default_reasoning_effort
    sampling_parameters = resolve_sampling_parameters(
        model, include_seed=True, reasoning_effort=reasoning_effort
    )
    kwargs.update(sampling_parameters)
    chat_model = (chat_model_class or ChatOpenAI)(**kwargs)
    register_chat_model_controls(
        chat_model,
        retained_chat_model_controls(
            chat_model,
            ("temperature", "seed", "reasoning_effort"),
        ),
        requested_controls={
            "temperature": sampling_parameters.get("temperature"),
            "seed": sampling_parameters.get("seed"),
            "reasoning_effort": reasoning_effort,
        },
    )
    return chat_model
