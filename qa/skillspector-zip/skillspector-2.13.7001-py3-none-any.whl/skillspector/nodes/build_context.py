# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Build-context node for Skillspector workflow.

Builds flat ScanContext fields (components, file_cache, manifest, etc.)
from a local skill directory.
"""

from __future__ import annotations

import base64
import binascii
import json
import os
import re
import shlex
import tarfile
from collections.abc import Callable, Mapping
from fnmatch import fnmatchcase
from pathlib import Path, PurePosixPath
from stat import S_ISREG
from time import monotonic
from typing import cast

import yaml

from skillspector.allowed_tools import iter_allowed_tools_entries
from skillspector.artifacts import (
    ArtifactDisposition,
    ArtifactRecord,
    ContentKind,
    binary_instruction_view,
    classify_artifact,
    decode_text,
    promote_artifact_to_decoded_text,
)
from skillspector.constants import (
    MAX_ANALYZABLE_FILE_BYTES,
    MAX_FILE_BYTES,
    MAX_LLM_TRUNCATED_FILE_CHARS,
    MODEL_CONFIG,
    build_model_config,
)
from skillspector.input_handler import (
    _FileOpenError,
    _open_regular_file_no_follow,
    _UnsafeFileError,
    validate_local_input_path,
)
from skillspector.inspection_ledger import (
    InspectionLedgerEvent,
    LedgerOutcome,
    LedgerReason,
    LedgerRecordType,
    inspection_work_id,
    ledger_event,
)
from skillspector.llm_provenance import capture_llm_provenance, capture_static_llm_provenance
from skillspector.logging_config import get_logger
from skillspector.nested_artifacts import (
    ARCHIVE_MAX_UNCOMPRESSED_BYTES,
    expected_container_type,
    has_binary_executable_magic,
    inspect_nested_artifacts,
    is_archive_content,
    is_executable_content,
    is_zip_content,
)
from skillspector.oms import project_oms_content
from skillspector.providers import prepare_chat_model_imports
from skillspector.python_ast import (
    PythonSourceClassification,
    classify_python_source,
    decode_python_source,
    is_python_source,
    prewarm_python_ast_cache,
)
from skillspector.references import (
    MAX_ACCEPTED_REFERENCES,
    MAX_RAW_REFERENCE_CANDIDATES,
    MAX_REFERENCE_RECORDS,
    MAX_REFERENCE_SOURCE_BYTES,
    ReferenceResolutionResult,
    resolve_bundle_references_with_metadata,
)
from skillspector.state import (
    ManifestVersionSource,
    SkillspectorState,
    ensure_workflow_resource_budget,
    transitive_note_truncation,
    transitive_record_artifacts,
    transitive_remaining_artifacts,
    transitive_remaining_bytes,
    transitive_remaining_seconds,
    transitive_traversal_state,
)
from skillspector.structured_skill import extract_structured_skill_context_from_cache

logger = get_logger(__name__)

# Directories to skip when walking
_SKIP_DIRS = frozenset({"__pycache__", "node_modules", ".venv", "venv", ".tox", ".pytest_cache"})

# Bundle-wide bounds complement the per-artifact read and analyzer limits.  A
# limit hit is always recorded as partial coverage; it is never treated as a
# clean scan of the subset accumulated before the bound.
MAX_DISCOVERED_ARTIFACTS = 10_000
MAX_DIRECTORY_ENTRIES = 10_000
MAX_BUNDLE_TRAVERSAL_DEPTH = 64
MAX_TOTAL_CACHED_BYTES = 64 * 1024 * 1024
MAX_BUNDLE_DISCOVERY_SECONDS = 30.0
MAX_BUNDLE_CACHE_SECONDS = 60.0
MAX_BUNDLE_LEDGER_EVENTS = 10_000
MAX_MANIFEST_FRONTMATTER_BYTES = 256 * 1024
MAX_MANIFEST_YAML_NODES = 10_000
MAX_MANIFEST_YAML_DEPTH = 64
MAX_MANIFEST_PARSE_SECONDS = 1.0
MAX_MANIFEST_OUTPUT_RECORDS = 1_024
MAX_MANIFEST_OUTPUT_CHARACTERS = 256 * 1024
_EXECUTABLE_PROBE_BYTES = 1024


def _is_allowed_inactive_git_hook_template(path: str, probe: bytes) -> bool:
    """Return whether *path* is a direct inactive Git hook template.

    Git does not invoke ``*.sample`` files.  The direct-child requirement keeps
    the established PR #412 exception from spreading to arbitrary excluded VCS
    subtrees; active hooks and every other VCS executable remain fail-closed.
    """
    parts = PurePosixPath(path).parts
    return (
        len(parts) == 3
        and parts[:2] == (".git", "hooks")
        and parts[-1].endswith(".sample")
        and not has_binary_executable_magic(probe)
    )


# File type by extension
_FILE_TYPES: dict[str, str] = {
    ".md": "markdown",
    ".mdc": "markdown",
    ".markdown": "markdown",
    ".py": "python",
    ".pyw": "python",
    ".sh": "shell",
    ".bash": "shell",
    ".zsh": "shell",
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".txt": "text",
    ".js": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".rb": "ruby",
    ".go": "go",
    ".rs": "rust",
}
_OMS_SIGNATURE_PATH = "skill.oms.sig"
_SIGSTORE_BUNDLE_MEDIA_TYPE = "application/vnd.dev.sigstore.bundle.v0.3+json"
_IN_TOTO_PAYLOAD_TYPE = "application/vnd.in-toto+json"
_IN_TOTO_STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
_OMS_PREDICATE_TYPE_PREFIX = "https://model_signing/signature/"


def _resolve_skill_dir(state: SkillspectorState) -> Path:
    """Resolve state skill_path to an existing directory Path."""
    skill_path = state.get("skill_path")
    if not skill_path or not isinstance(skill_path, str) or not skill_path.strip():
        raise ValueError("skill_path is required; provide input_path or skill_path to scan")
    try:
        resolved = validate_local_input_path(Path(skill_path))
    except (OSError, RuntimeError) as e:
        raise ValueError(f"Invalid skill_path: {skill_path}") from e
    if not resolved.is_dir():
        raise ValueError(f"Invalid skill_path: {skill_path} is not an existing directory")
    return cast(Path, resolved)


def _selected_baseline_component(
    state: SkillspectorState,
    skill_dir: Path,
    inventoried_components: list[str],
) -> str | None:
    """Return the selected baseline's component path when it is inside the skill.

    The CLI records the exact path selected by ``scan --baseline`` or targeted
    by ``baseline -o``. Excluding only that file prevents a rule's own sensitive
    message glob from producing a fresh finding (or entering regenerated
    fingerprints) while leaving every sibling YAML/JSON file in normal scope.
    """
    raw_path = state.get("baseline_path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        return None

    baseline_path = Path(raw_path)
    candidates: list[Path] = [baseline_path]
    try:
        resolved = baseline_path.resolve()
    except (OSError, RuntimeError):
        resolved = None
    if resolved is not None and resolved != baseline_path:
        candidates.append(resolved)

    inventory = frozenset(inventoried_components)
    for candidate in candidates:
        try:
            relative = candidate.relative_to(skill_dir).as_posix()
        except ValueError:
            continue
        if relative in inventory:
            return relative
    return None


def _is_symlink(path: Path) -> bool:
    """Return whether *path* is a link or junction without masking later stat errors."""
    try:
        return path.is_symlink() or path.is_junction()
    except OSError:
        return False


def _resolves_outside(path: Path, root: Path) -> bool:
    """Return whether *path* resolves outside an already-resolved *root*."""
    try:
        return not path.resolve(strict=False).is_relative_to(root)
    except OSError:
        return False


def _append_bounded_ledger_event(
    events: list[InspectionLedgerEvent], event: InspectionLedgerEvent
) -> bool:
    """Append one event without allowing bundle-level ledger output to grow unbounded."""
    limit = max(1, MAX_BUNDLE_LEDGER_EVENTS)
    if len(events) < limit:
        events.append(event)
        return True
    if events[-1].get("reason_code") != LedgerReason.OUTPUT_LIMIT:
        events[-1] = ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase=str(event["phase"]),
            path=str(event["path"]),
            reason=LedgerReason.OUTPUT_LIMIT,
            observed_records=limit + 1,
            limit_records=limit,
        )
    return False


def _bounded_ledger_output(
    events: list[InspectionLedgerEvent],
) -> list[InspectionLedgerEvent]:
    """Return a deterministic capped ledger projection with explicit truncation evidence."""
    limit = max(1, MAX_BUNDLE_LEDGER_EVENTS)
    if len(events) <= limit:
        return events
    overflow = events[limit]
    return [
        *events[: limit - 1],
        ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase=str(overflow["phase"]),
            path=str(overflow["path"]),
            reason=LedgerReason.OUTPUT_LIMIT,
            observed_records=len(events),
            limit_records=limit,
        ),
    ]


def _discovery_scope_path(relative_root: Path, dirnames: list[str], filenames: list[str]) -> str:
    """Choose a deterministic report-safe path for a bundle discovery limit."""
    if filenames:
        return (relative_root / filenames[0]).as_posix()
    if dirnames:
        return f"{(relative_root / dirnames[0]).as_posix()}/"
    if relative_root.parts:
        return f"{relative_root.as_posix()}/"
    return "SKILL.md"


def _read_text_no_follow(path: Path, *, max_bytes: int | None = None) -> str:
    """Read a regular file without following symlinks at open time."""
    with _open_regular_file_no_follow(path) as source:
        data = source.read() if max_bytes is None else source.read(max_bytes + 1)
        return cast(bytes, data).decode("utf-8", errors="replace")


def _read_bytes_no_follow(path: Path, *, max_bytes: int | None = None) -> bytes:
    """Read a regular file as canonical bytes without following symlinks."""
    with _open_regular_file_no_follow(path) as source:
        return cast(bytes, source.read() if max_bytes is None else source.read(max_bytes))


def _read_zip_candidate(path: Path, prefix_limit: int, expected_size: int) -> bytes:
    """Read a ZIP envelope from one descriptor. Other artifacts keep their static prefix."""
    with _open_regular_file_no_follow(path) as source:
        before = os.fstat(source.fileno())
        prefix = source.read(prefix_limit + 1)
        if len(prefix) <= prefix_limit or not is_zip_content(prefix):
            return prefix
        if before.st_size != expected_size:
            raise OSError("Archive changed before its envelope could be read")
        tail = source.read(expected_size - len(prefix) + 1)
        after = os.fstat(source.fileno())
        if (
            len(prefix) + len(tail) != expected_size
            or after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
        ):
            raise OSError("Archive changed while reading its envelope")
        return prefix + tail


def _walk_skill_files(
    skill_dir: Path,
    state: SkillspectorState | None = None,
) -> tuple[
    list[str],
    list[InspectionLedgerEvent],
    dict[str, LedgerReason],
    dict[str, tuple[LedgerReason | None, LedgerReason]],
]:
    """Walk skill files and record scan-scope exclusions.

    Content analysis skips profile-permitted generated trees and symlinks.
    Generated-tree descendants are still inventoried under bounded discovery;
    hidden artifacts are analyzed normally. Within ``.git`` only configuration
    and active hooks enter normal analysis; all other files enter the bounded
    exclusion audit. Successfully probed direct ``hooks/*.sample`` text templates
    retain PR #412's explicit inactive-template policy.
    """
    paths: list[str] = []
    exclusions: list[InspectionLedgerEvent] = []
    excluded_artifacts: dict[str, LedgerReason] = {}
    excluded_inspection_gaps: dict[str, tuple[LedgerReason | None, LedgerReason]] = {}
    skill_root = skill_dir.resolve(strict=False)
    started = monotonic()
    initial_shared_seconds = transitive_remaining_seconds(state) if state is not None else None
    discovery_runtime_limit = min(
        MAX_BUNDLE_DISCOVERY_SECONDS,
        max(0.0, initial_shared_seconds)
        if initial_shared_seconds is not None
        else MAX_BUNDLE_DISCOVERY_SECONDS,
    )
    # A directory counts as discovery work too. This prevents a directory-only
    # tree from bypassing the artifact-count ceiling.
    discovered_entries = 0
    stack: list[tuple[Path, Path, LedgerReason | None]] = [(skill_dir, Path(), None)]

    def _elapsed() -> float:
        return monotonic() - started

    def _scope(relative_root: Path) -> str:
        return f"{relative_root.as_posix()}/" if relative_root.parts else "SKILL.md"

    def _gap_path(relative_root: Path) -> str:
        # Ledger paths are report-safe relative artifact paths; ``."`` is not
        # valid and would make SC9 evidence disappear in the guarded analyzer.
        return relative_root.as_posix() if relative_root.parts else "SKILL.md"

    def _record_excluded_gap(
        path: str,
        exclusion_reason: LedgerReason | None,
        limitation_reason: LedgerReason,
        *,
        can_contain_exclusions: bool = False,
    ) -> None:
        if exclusion_reason is None and not can_contain_exclusions:
            return
        normalized = path.rstrip("/")
        if normalized:
            excluded_inspection_gaps.setdefault(
                normalized,
                (exclusion_reason, limitation_reason),
            )

    def _entry_exclusion(
        root: Path,
        name: str,
        is_directory: bool,
        is_link: bool,
        inherited: LedgerReason | None,
    ) -> LedgerReason | None:
        if inherited is not None:
            return inherited
        normalized = root.as_posix()
        if (
            normalized == ".git"
            and (is_directory and name != "hooks" or not is_directory and name != "config")
        ) or (normalized == ".git/hooks" and (is_directory or name.endswith(".sample"))):
            return LedgerReason.VCS_METADATA
        if name in _SKIP_DIRS and (is_directory or is_link):
            return LedgerReason.EXCLUDED_DIRECTORY
        return None

    def _record_pending_excluded_gaps(
        limitation_reason: LedgerReason,
        *,
        queued_directories: list[tuple[Path, Path, LedgerReason | None]] | None = None,
        remaining_entries: list[tuple[str, bool, bool]] | None = None,
        relative_root: Path | None = None,
        inherited_exclusion: LedgerReason | None = None,
    ) -> None:
        pending = [*stack, *(queued_directories or [])]
        for _full, pending_root, pending_exclusion in pending:
            _record_excluded_gap(
                _gap_path(pending_root),
                pending_exclusion,
                limitation_reason,
                can_contain_exclusions=True,
            )
        if remaining_entries is None or relative_root is None:
            return
        for pending_name, pending_is_directory, pending_is_link in remaining_entries:
            pending_exclusion = _entry_exclusion(
                relative_root,
                pending_name,
                pending_is_directory,
                pending_is_link,
                inherited_exclusion,
            )
            pending_path = (relative_root / pending_name).as_posix()
            _record_excluded_gap(
                pending_path,
                pending_exclusion,
                limitation_reason,
                can_contain_exclusions=pending_is_directory,
            )

    def _record_runtime_limit(
        relative_root: Path,
        *,
        elapsed: float,
        shared_seconds: float | None,
        affected_path: str | None = None,
    ) -> None:
        """Record one canonical discovery deadline boundary."""
        scope = affected_path or _scope(relative_root)
        if state is not None and shared_seconds is not None and shared_seconds <= 0:
            transitive_note_truncation(state, f"time budget exhausted during discovery at {scope}")
        _append_bounded_ledger_event(
            exclusions,
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="discovery",
                path=scope,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=max(0.0, elapsed),
                limit_seconds=discovery_runtime_limit,
            ),
        )

    while stack:
        root_path, relative_root, inherited_exclusion = stack.pop()
        elapsed = _elapsed()
        shared_seconds = transitive_remaining_seconds(state) if state is not None else None
        if elapsed >= MAX_BUNDLE_DISCOVERY_SECONDS or (
            shared_seconds is not None and shared_seconds <= 0
        ):
            _record_excluded_gap(
                _gap_path(relative_root),
                inherited_exclusion,
                LedgerReason.RUNTIME_LIMIT,
                can_contain_exclusions=True,
            )
            _record_runtime_limit(
                relative_root,
                elapsed=elapsed,
                shared_seconds=shared_seconds,
            )
            _record_pending_excluded_gaps(LedgerReason.RUNTIME_LIMIT)
            break

        # scandir is lazy. Keep only a bounded directory-local list, and do not
        # sort any attacker-controlled collection until that ceiling is known
        # to hold. If the directory itself exceeds the ceiling, none of its
        # nondeterministic enumeration prefix is retained.
        entries: list[tuple[str, bool, bool]] = []
        directory_overflow = False
        shared_artifacts = transitive_remaining_artifacts(state) if state is not None else None
        directory_entry_limit = (
            MAX_DIRECTORY_ENTRIES
            if shared_artifacts is None
            else min(MAX_DIRECTORY_ENTRIES, max(0, shared_artifacts))
        )
        try:
            with os.scandir(root_path) as iterator:
                for entry in iterator:
                    elapsed = _elapsed()
                    shared_seconds = (
                        transitive_remaining_seconds(state) if state is not None else None
                    )
                    if elapsed >= MAX_BUNDLE_DISCOVERY_SECONDS or (
                        shared_seconds is not None and shared_seconds <= 0
                    ):
                        _record_excluded_gap(
                            _gap_path(relative_root),
                            inherited_exclusion,
                            LedgerReason.RUNTIME_LIMIT,
                            can_contain_exclusions=True,
                        )
                        _record_runtime_limit(
                            relative_root,
                            elapsed=elapsed,
                            shared_seconds=shared_seconds,
                        )
                        _record_pending_excluded_gaps(
                            LedgerReason.RUNTIME_LIMIT,
                            remaining_entries=[*entries, (entry.name, False, True)],
                            relative_root=relative_root,
                            inherited_exclusion=inherited_exclusion,
                        )
                        directory_overflow = True
                        break
                    if len(entries) >= directory_entry_limit:
                        _record_excluded_gap(
                            _gap_path(relative_root),
                            inherited_exclusion,
                            LedgerReason.ARTIFACT_COUNT_LIMIT,
                            can_contain_exclusions=True,
                        )
                        if state is not None and shared_artifacts is not None:
                            transitive_note_truncation(
                                state,
                                f"artifact budget exhausted during discovery at {_scope(relative_root)}",
                            )
                        _append_bounded_ledger_event(
                            exclusions,
                            ledger_event(
                                outcome=LedgerOutcome.PARTIAL,
                                record_type=LedgerRecordType.SYSTEM,
                                phase="discovery",
                                path=_scope(relative_root),
                                reason=LedgerReason.ARTIFACT_COUNT_LIMIT,
                                observed_artifacts=len(entries) + 1,
                                limit_artifacts=directory_entry_limit,
                            ),
                        )
                        _record_pending_excluded_gaps(
                            LedgerReason.ARTIFACT_COUNT_LIMIT,
                            remaining_entries=[*entries, (entry.name, False, True)],
                            relative_root=relative_root,
                            inherited_exclusion=inherited_exclusion,
                        )
                        directory_overflow = True
                        break
                    try:
                        is_link = entry.is_symlink()
                        is_directory = entry.is_dir(follow_symlinks=False)
                    except OSError:
                        is_link = False
                        is_directory = False
                    entries.append((entry.name, is_directory, is_link))
        except OSError as exc:
            _record_excluded_gap(
                _gap_path(relative_root),
                inherited_exclusion,
                LedgerReason.READ_ERROR,
                can_contain_exclusions=True,
            )
            _append_bounded_ledger_event(
                exclusions,
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="discovery",
                    path=_scope(relative_root),
                    reason=LedgerReason.READ_ERROR,
                    error_class=type(exc).__name__,
                ),
            )
            continue
        if directory_overflow:
            break

        child_directories: list[tuple[Path, Path, LedgerReason | None]] = []
        sorted_entries = sorted(entries, key=lambda item: item[0])
        elapsed = _elapsed()
        shared_seconds = transitive_remaining_seconds(state) if state is not None else None
        if elapsed >= MAX_BUNDLE_DISCOVERY_SECONDS or (
            shared_seconds is not None and shared_seconds <= 0
        ):
            _record_excluded_gap(
                _gap_path(relative_root),
                inherited_exclusion,
                LedgerReason.RUNTIME_LIMIT,
                can_contain_exclusions=True,
            )
            _record_runtime_limit(
                relative_root,
                elapsed=elapsed,
                shared_seconds=shared_seconds,
            )
            _record_pending_excluded_gaps(
                LedgerReason.RUNTIME_LIMIT,
                remaining_entries=sorted_entries,
                relative_root=relative_root,
                inherited_exclusion=inherited_exclusion,
            )
            break

        for entry_index, (name, is_directory, is_link) in enumerate(sorted_entries):
            relative_path_obj = relative_root / name
            relative_path = relative_path_obj.as_posix()
            affected_path = f"{relative_path}/" if is_directory else relative_path
            entry_exclusion = _entry_exclusion(
                relative_root,
                name,
                is_directory,
                is_link,
                inherited_exclusion,
            )
            vcs_excluded = entry_exclusion is LedgerReason.VCS_METADATA

            elapsed = _elapsed()
            shared_seconds = transitive_remaining_seconds(state) if state is not None else None
            if elapsed >= MAX_BUNDLE_DISCOVERY_SECONDS or (
                shared_seconds is not None and shared_seconds <= 0
            ):
                _record_excluded_gap(
                    affected_path,
                    entry_exclusion,
                    LedgerReason.RUNTIME_LIMIT,
                    can_contain_exclusions=is_directory,
                )
                _record_runtime_limit(
                    relative_root,
                    elapsed=elapsed,
                    shared_seconds=shared_seconds,
                    affected_path=affected_path,
                )
                _record_pending_excluded_gaps(
                    LedgerReason.RUNTIME_LIMIT,
                    queued_directories=child_directories,
                    remaining_entries=sorted_entries[entry_index:],
                    relative_root=relative_root,
                    inherited_exclusion=inherited_exclusion,
                )
                return (
                    sorted(paths),
                    exclusions,
                    dict(sorted(excluded_artifacts.items())),
                    dict(sorted(excluded_inspection_gaps.items())),
                )

            shared_artifacts = transitive_remaining_artifacts(state) if state is not None else None
            if discovered_entries >= MAX_DISCOVERED_ARTIFACTS or (
                shared_artifacts is not None and shared_artifacts <= 0
            ):
                _record_excluded_gap(
                    affected_path,
                    entry_exclusion,
                    LedgerReason.ARTIFACT_COUNT_LIMIT,
                    can_contain_exclusions=is_directory,
                )
                if state is not None and shared_artifacts is not None and shared_artifacts <= 0:
                    transitive_note_truncation(
                        state, f"artifact budget exhausted before discovering {relative_path}"
                    )
                _append_bounded_ledger_event(
                    exclusions,
                    ledger_event(
                        outcome=LedgerOutcome.PARTIAL,
                        record_type=LedgerRecordType.SYSTEM,
                        phase="discovery",
                        path=f"{relative_path}/" if is_directory else relative_path,
                        reason=LedgerReason.ARTIFACT_COUNT_LIMIT,
                        observed_artifacts=discovered_entries + 1,
                        limit_artifacts=min(
                            MAX_DISCOVERED_ARTIFACTS,
                            discovered_entries + max(0, shared_artifacts)
                            if shared_artifacts is not None
                            else MAX_DISCOVERED_ARTIFACTS,
                        ),
                    ),
                )
                _record_pending_excluded_gaps(
                    LedgerReason.ARTIFACT_COUNT_LIMIT,
                    queued_directories=child_directories,
                    remaining_entries=sorted_entries[entry_index:],
                    relative_root=relative_root,
                    inherited_exclusion=inherited_exclusion,
                )
                return (
                    sorted(paths),
                    exclusions,
                    dict(sorted(excluded_artifacts.items())),
                    dict(sorted(excluded_inspection_gaps.items())),
                )
            discovered_entries += 1
            if state is not None:
                transitive_record_artifacts(state, 1)

            full = root_path / name
            unsafe_path = is_link or _is_symlink(full) or _resolves_outside(full, skill_root)
            elapsed = _elapsed()
            shared_seconds = transitive_remaining_seconds(state) if state is not None else None
            if elapsed >= MAX_BUNDLE_DISCOVERY_SECONDS or (
                shared_seconds is not None and shared_seconds <= 0
            ):
                _record_excluded_gap(
                    affected_path,
                    entry_exclusion,
                    LedgerReason.RUNTIME_LIMIT,
                    can_contain_exclusions=is_directory,
                )
                _record_runtime_limit(
                    relative_root,
                    elapsed=elapsed,
                    shared_seconds=shared_seconds,
                    affected_path=affected_path,
                )
                _record_pending_excluded_gaps(
                    LedgerReason.RUNTIME_LIMIT,
                    queued_directories=child_directories,
                    remaining_entries=sorted_entries[entry_index:],
                    relative_root=relative_root,
                    inherited_exclusion=inherited_exclusion,
                )
                return (
                    sorted(paths),
                    exclusions,
                    dict(sorted(excluded_artifacts.items())),
                    dict(sorted(excluded_inspection_gaps.items())),
                )
            if unsafe_path:
                _append_bounded_ledger_event(
                    exclusions,
                    ledger_event(
                        outcome=LedgerOutcome.OUT_OF_SCOPE,
                        record_type=LedgerRecordType.SCOPE_BOUNDARY,
                        phase="discovery",
                        path=f"{relative_path}/" if is_directory else relative_path,
                        reason=LedgerReason.NOT_REGULAR_FILE,
                    ),
                )
                if entry_exclusion is not None or is_executable_content(relative_path, b""):
                    excluded_artifacts[relative_path] = (
                        entry_exclusion or LedgerReason.NOT_REGULAR_FILE
                    )
                continue

            if inherited_exclusion is None and vcs_excluded:
                _append_bounded_ledger_event(
                    exclusions,
                    ledger_event(
                        outcome=LedgerOutcome.OUT_OF_SCOPE,
                        record_type=LedgerRecordType.SCOPE_BOUNDARY,
                        phase="discovery",
                        path=f"{relative_path}/" if is_directory else relative_path,
                        reason=LedgerReason.VCS_METADATA,
                    ),
                )

            if is_directory:
                child_exclusion = entry_exclusion
                if inherited_exclusion is None and name in _SKIP_DIRS:
                    _append_bounded_ledger_event(
                        exclusions,
                        ledger_event(
                            outcome=LedgerOutcome.OUT_OF_SCOPE,
                            record_type=LedgerRecordType.SCOPE_BOUNDARY,
                            phase="discovery",
                            path=f"{relative_path}/",
                            reason=LedgerReason.EXCLUDED_DIRECTORY,
                        ),
                    )
                depth = len(relative_path_obj.parts)
                if depth > MAX_BUNDLE_TRAVERSAL_DEPTH:
                    _record_excluded_gap(
                        affected_path,
                        child_exclusion,
                        LedgerReason.TRAVERSAL_DEPTH_LIMIT,
                        can_contain_exclusions=True,
                    )
                    _append_bounded_ledger_event(
                        exclusions,
                        ledger_event(
                            outcome=LedgerOutcome.PARTIAL,
                            record_type=LedgerRecordType.SYSTEM,
                            phase="discovery",
                            path=f"{relative_path}/",
                            reason=LedgerReason.TRAVERSAL_DEPTH_LIMIT,
                            observed_depth=depth,
                            limit_depth=MAX_BUNDLE_TRAVERSAL_DEPTH,
                        ),
                    )
                    continue
                child_directories.append((full, relative_path_obj, child_exclusion))
                continue

            # Other non-regular entries remain inventoried so the cache phase
            # records their exact failure disposition.
            if entry_exclusion is None:
                paths.append(relative_path)
            else:
                excluded_artifacts[relative_path] = entry_exclusion

        # Reverse push gives a stable lexical depth-first traversal.
        stack.extend(reversed(child_directories))

    return (
        sorted(paths),
        exclusions,
        dict(sorted(excluded_artifacts.items())),
        dict(sorted(excluded_inspection_gaps.items())),
    )


def _infer_file_type(
    path: str,
    content: str | bytes | None = None,
    *,
    source_classification: PythonSourceClassification | None = None,
) -> str:
    """Infer file type from path and bounded execution metadata."""
    if (
        source_classification is PythonSourceClassification.PYTHON
        if source_classification is not None
        else is_python_source(path, content)
    ):
        return "python"
    idx = path.rfind(".")
    suffix = path[idx:].lower() if idx >= 0 else ""
    return _FILE_TYPES.get(suffix, "other")


def _is_hidden_component(path: str) -> bool:
    """Return whether any segment of a relative component path is hidden."""
    return any(part.startswith(".") for part in path.replace("\\", "/").split("/") if part)


def _is_conventional_skill_script(skill_dir: Path, path: str, data: bytes) -> bool:
    """Return whether a visible source script belongs to a standard agent skill directory."""
    parts = path.replace("\\", "/").split("/")
    if len(parts) < 4 or parts[0:2] not in ([".agents", "skills"], [".claude", "skills"]):
        return False
    skill_name = parts[2]
    if (
        not skill_name
        or skill_name.startswith(".")
        or any(part.startswith(".") for part in parts[3:])
    ):
        return False
    suffix = Path(parts[-1]).suffix.lower()
    if suffix not in {
        ".bash",
        ".cjs",
        ".js",
        ".jsx",
        ".mjs",
        ".php",
        ".pl",
        ".ps1",
        ".py",
        ".rb",
        ".sh",
        ".ts",
        ".tsx",
        ".zsh",
    } or has_binary_executable_magic(data):
        return False

    first_line = data.splitlines()[0] if data.splitlines() else b""
    if first_line.startswith(b"#!"):
        try:
            tokens = shlex.split(first_line[2:].decode("utf-8", errors="strict"))
        except (UnicodeDecodeError, ValueError):
            return False
        if not tokens:
            return False
        interpreter = Path(tokens[0]).name
        if interpreter == "env":
            interpreter = next(
                (token for token in tokens[1:] if not token.startswith("-") and "=" not in token),
                "",
            )
        interpreter = Path(interpreter).name.removesuffix(".exe").lower()
        compatible = {
            ".bash": {"bash"},
            ".cjs": {"node", "nodejs", "bun"},
            ".js": {"node", "nodejs", "bun", "deno"},
            ".jsx": {"node", "nodejs", "bun", "deno"},
            ".mjs": {"node", "nodejs", "bun", "deno"},
            ".php": {"php"},
            ".pl": {"perl"},
            ".ps1": {"pwsh", "powershell"},
            ".py": {"python", "python2", "python3", "pypy", "pypy3"},
            ".rb": {"ruby"},
            ".sh": {"sh", "bash", "dash", "ksh", "zsh"},
            ".ts": {"node", "nodejs", "bun", "deno", "tsx"},
            ".tsx": {"node", "nodejs", "bun", "deno", "tsx"},
            ".zsh": {"zsh"},
        }
        if not interpreter or interpreter not in compatible[suffix]:
            return False

    skill_root = skill_dir.joinpath(*parts[:3])
    return any(
        (manifest := skill_root / name).is_file() and not _is_symlink(manifest)
        for name in ("SKILL.md", "skill.md")
    )


def _decode_base64_json(value: object) -> dict[str, object] | None:
    """Decode a strict base64 JSON object, returning ``None`` on malformed input."""
    if not isinstance(value, str) or not value:
        return None
    try:
        decoded = base64.b64decode(value, validate=True)
        parsed = json.loads(decoded.decode("utf-8"))
    except (binascii.Error, UnicodeDecodeError, json.JSONDecodeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _is_valid_oms_signature_bytes(data: bytes) -> bool:
    """Recognize OMS structure only; this does not verify or trust its contents."""
    try:
        if len(data) > MAX_FILE_BYTES:
            return False
        bundle = json.loads(decode_text(data))
    except json.JSONDecodeError:
        return False

    if not isinstance(bundle, dict):
        return False
    if bundle.get("mediaType") != _SIGSTORE_BUNDLE_MEDIA_TYPE:
        return False
    if not isinstance(bundle.get("verificationMaterial"), dict):
        return False

    envelope = bundle.get("dsseEnvelope")
    if not isinstance(envelope, dict):
        return False
    if envelope.get("payloadType") != _IN_TOTO_PAYLOAD_TYPE:
        return False

    signatures = envelope.get("signatures")
    if not isinstance(signatures, list) or len(signatures) != 1:
        return False
    signature = signatures[0]
    if not isinstance(signature, dict):
        return False
    signature_bytes = signature.get("sig")
    if not isinstance(signature_bytes, str) or not signature_bytes:
        return False
    try:
        base64.b64decode(signature_bytes, validate=True)
    except (binascii.Error, ValueError):
        return False

    statement = _decode_base64_json(envelope.get("payload"))
    predicate_type = statement.get("predicateType") if statement else None
    return bool(
        statement
        and statement.get("_type") == _IN_TOTO_STATEMENT_TYPE
        and isinstance(predicate_type, str)
        and predicate_type.startswith(_OMS_PREDICATE_TYPE_PREFIX)
    )


def _is_valid_oms_signature(file_path: Path) -> bool:
    """Compatibility wrapper using one bounded, no-follow read."""
    try:
        if file_path.stat().st_size > MAX_FILE_BYTES:
            return False
        data = _read_bytes_no_follow(file_path, max_bytes=MAX_FILE_BYTES + 1)
    except (OSError, _FileOpenError, _UnsafeFileError):
        return False
    return _is_valid_oms_signature_bytes(data)


def _count_lines(file_path: Path) -> int:
    """Count lines in a file, handling binary and errors gracefully."""
    try:
        content = _read_text_no_follow(file_path, max_bytes=MAX_FILE_BYTES)
        return len(content.splitlines())
    except (OSError, _FileOpenError, _UnsafeFileError):
        logger.debug("Could not read file for line count: %s", file_path)
        return 0


def _build_component_metadata(
    skill_dir: Path,
    components: list[str],
    file_cache: Mapping[str, str],
    raw_file_cache: Mapping[str, bytes],
    recognized_oms_signatures: frozenset[str] = frozenset(),
    *,
    source_classifications: Mapping[str, PythonSourceClassification] | None = None,
    clock: Callable[[], float] = monotonic,
    started_at: float | None = None,
    deadline: float | None = None,
    runtime_limitations: list[tuple[str, float]] | None = None,
    source_local_only: bool = False,
) -> tuple[list[dict[str, object]], bool]:
    """Build component_metadata list and has_executable_scripts from paths."""
    metadata: list[dict[str, object]] = []
    has_executable = False
    effective_started_at = clock() if started_at is None else started_at

    def _expired(path: str) -> bool:
        if deadline is None:
            return False
        now = clock()
        if now < deadline:
            return False
        if runtime_limitations is not None and not runtime_limitations:
            runtime_limitations.append((path, max(0.0, now - effective_started_at)))
        return True

    for path in components:
        if _expired(path):
            break
        full = skill_dir / path
        content = file_cache.get(path)
        raw_content = raw_file_cache.get(path) if raw_file_cache is not None else None
        source_content = raw_content if raw_content is not None else content
        source_classification = (
            source_classifications.get(path) if source_classifications is not None else None
        )
        file_type = (
            "oms_signature"
            if path in recognized_oms_signatures
            else _infer_file_type(
                path,
                source_content,
                source_classification=source_classification,
            )
        )
        lines = (
            len(content.splitlines())
            if content is not None
            else _count_lines(full)
            if path in recognized_oms_signatures
            else 0
        )
        try:
            file_stat = full.stat()
            size_bytes = file_stat.st_size
            mode = file_stat.st_mode
        except OSError:
            logger.debug("Could not stat file: %s", path)
            size_bytes = 0
            mode = 0
        data = raw_file_cache.get(path, b"")
        executable = is_executable_content(
            path, data, mode, complete_content=len(data) == size_bytes
        )
        if executable:
            has_executable = True
        component: dict[str, object] = {
            "path": path,
            "type": file_type,
            "lines": lines,
            "executable": executable,
            "size_bytes": size_bytes,
        }
        hidden_component = _is_hidden_component(path)
        conventional_skill_script = (
            executable
            and hidden_component
            and not source_local_only
            and _is_conventional_skill_script(skill_dir, path, data)
        )
        if hidden_component or source_local_only:
            component["local_only"] = True
            if hidden_component:
                component["hidden"] = True
            if source_local_only:
                component["hidden_ancestor"] = True
                component["source_local_only"] = True
            if executable and (source_local_only or not conventional_skill_script):
                component.update(
                    {
                        "outer_path": path,
                        "nested_path": path,
                        "container_type": "filesystem",
                        "container_ancestry": ["filesystem"],
                        "container_depth": 0,
                        "outer_hidden": True,
                        "concealed_executable": True,
                        "concealment_reasons": ["hidden_artifact"],
                    }
                )
            elif executable:
                component["concealed_executable"] = False
                component["hidden_skill_script_llm_review_withheld"] = True
        metadata.append(component)
        if _expired(path):
            break
    return metadata, has_executable


def _mark_unanalyzed_executables(
    component_metadata: list[dict[str, object]],
    artifact_inventory: Mapping[str, ArtifactRecord],
    raw_file_cache: Mapping[str, bytes],
) -> list[InspectionLedgerEvent]:
    """Apply one fail-closed policy to executable artifacts outside byte coverage."""
    events: list[InspectionLedgerEvent] = []
    for component in component_metadata:
        if component.get("executable") is not True:
            continue
        if component.get("excluded_from_analysis") is True:
            continue
        path = str(component.get("path", ""))
        artifact = artifact_inventory.get(path)
        if not path or artifact is None:
            continue

        raw = raw_file_cache.get(path)
        disposition = artifact["disposition"]
        content_kind = artifact["content_kind"]
        incomplete_bytes = raw is None or (
            disposition is ArtifactDisposition.PARTIAL
            and len(raw) < max(0, int(artifact.get("size_bytes", 0)))
        )
        readable_executable = bool(artifact.get("readable_binary"))
        if content_kind is ContentKind.BINARY:
            reason = (
                LedgerReason.BINARY_EXECUTABLE_TEXT
                if readable_executable
                else LedgerReason.BINARY_CONTENT
            )
        elif disposition is ArtifactDisposition.OUT_OF_SCOPE:
            reason = LedgerReason.OPAQUE_CONTENT
        elif disposition is ArtifactDisposition.FAILED or incomplete_bytes:
            raw_reason = artifact.get("reason")
            try:
                reason = LedgerReason(str(raw_reason))
            except ValueError:
                reason = LedgerReason.MISSING_FILE_CACHE
        else:
            continue

        hidden = bool(component.get("hidden", _is_hidden_component(path)))
        concealment_reasons = component.get("concealment_reasons", [])
        reason_list = (
            [str(item) for item in concealment_reasons]
            if isinstance(concealment_reasons, list)
            else []
        )
        component.update(
            {
                "local_only": True,
                "outer_path": component.get("outer_path", path),
                "nested_path": component.get("nested_path", path),
                "container_type": component.get("container_type", "filesystem"),
                "container_ancestry": component.get("container_ancestry", ["filesystem"]),
                "container_depth": component.get("container_depth", path.count("!/")),
                "outer_hidden": component.get("outer_hidden", hidden),
                "concealed_executable": True,
                "excluded_from_analysis": not readable_executable,
                "partially_analyzed_executable": readable_executable,
                "inherited_exclusion_reason": reason.value,
                "concealment_reasons": list(dict.fromkeys([*reason_list, reason.value])),
            }
        )
        artifact.setdefault("reason", reason.value)
        if readable_executable and artifact["disposition"] in {
            ArtifactDisposition.ANALYZED,
            ArtifactDisposition.OUT_OF_SCOPE,
        }:
            artifact["disposition"] = ArtifactDisposition.PARTIAL
        events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="coverage_policy",
                path=path,
                reason=(
                    LedgerReason.BINARY_EXECUTABLE_TEXT
                    if readable_executable
                    else LedgerReason.EXCLUDED_EXECUTABLE_CONTENT
                ),
            )
        )
    return events


def _note_hidden_skill_scripts_not_sent_to_llm(
    component_metadata: list[dict[str, object]],
) -> list[InspectionLedgerEvent]:
    """Expose the local-only boundary without turning helpers into SC9 findings."""
    return [
        ledger_event(
            outcome=LedgerOutcome.SKIPPED,
            record_type=LedgerRecordType.SYSTEM,
            phase="llm_eligibility",
            path=str(component["path"]),
            reason=LedgerReason.HIDDEN_SKILL_EXECUTABLE_LOCAL_ONLY,
        )
        for component in component_metadata
        if component.get("hidden_skill_script_llm_review_withheld") is True
        and isinstance(component.get("path"), str)
    ]


def _redact_for_external_model(path: str, content: str) -> str:
    """Redact values from local environment files before external-model use."""
    name = Path(path).name.lower()
    if name != ".env" and not name.startswith(".env."):
        return content
    lines: list[str] = []
    for line in content.splitlines(keepends=True):
        match = re.match(r"^(\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=)(.*?)(\r?\n)?$", line)
        if match:
            lines.append(f"{match.group(1)}<redacted>{match.group(3) or ''}")
        else:
            lines.append(line)
    return "".join(lines)


def _is_hidden_path(path: str) -> bool:
    """Return whether any bundle path segment is hidden."""
    return any(part.startswith(".") for part in Path(path).parts)


def _llm_view_of_truncated_file(content: str, *, total_size: int, read_bytes: int) -> str:
    """Bound a truncated file's LLM view and mark the unreviewed region.

    A truncated file must not vanish from the LLM stage: with exclusion, a
    payload placed past the read cap is invisible to every analyzer while the
    report still shows zero findings.  The view is capped so token cost stays
    bounded, and the marker makes the audit gap explicit to the model.
    """
    marker = (
        f"\n\n[SKILLSPECTOR: this file is {total_size} bytes; only the first "
        f"{read_bytes} bytes were readable and the excerpt above is capped at "
        f"{MAX_LLM_TRUNCATED_FILE_CHARS} characters. The remaining bytes were "
        "not reviewed by any analyzer - treat the unseen region as an audit "
        "gap.]\n"
    )
    budget = max(MAX_LLM_TRUNCATED_FILE_CHARS - len(marker), 0)
    return content[:budget] + marker


def _opaque_artifact_record(
    path: str,
    *,
    disposition: ArtifactDisposition,
    reason: LedgerReason,
    referenced: bool,
    size_bytes: int = 0,
) -> ArtifactRecord:
    """Return an explicit inventory row for content that was not cached."""
    return {
        "path": path,
        "content_kind": ContentKind.OPAQUE,
        "disposition": disposition,
        "size_bytes": max(0, size_bytes),
        "decodable": False,
        "contains_nul": False,
        "misleading_extension": False,
        "referenced": referenced,
        "reason": reason.value,
    }


def _inspect_excluded_artifacts(
    skill_dir: Path,
    excluded_artifacts: Mapping[str, LedgerReason],
    *,
    state: SkillspectorState,
    started_at: float,
    deadline: float,
    max_input_bytes: int = MAX_TOTAL_CACHED_BYTES,
    incomplete_exclusions: Mapping[str, tuple[LedgerReason | None, LedgerReason]] | None = None,
) -> tuple[
    list[ArtifactRecord],
    list[dict[str, object]],
    list[InspectionLedgerEvent],
    dict[str, bytes],
    int,
]:
    """Inventory excluded files and fail closed on statically executable content.

    Ordinary excluded files require only the longest executable/archive magic prefix.
    Supported archives are read once into a private bounded cache for local nested
    inspection. Excluded bytes are never added to provider-visible caches, and every
    byte is charged to both the bundle-local and graph-wide input budgets.
    """
    inventory: list[ArtifactRecord] = []
    metadata: list[dict[str, object]] = []
    events: list[InspectionLedgerEvent] = []
    archive_cache: dict[str, bytes] = {}
    input_bytes_read = 0
    items = sorted(excluded_artifacts.items())
    runtime_limit = max(0.0, deadline - started_at)
    traversal = transitive_traversal_state(state)
    record_bytes = getattr(traversal, "record_bytes", None)

    def remaining_input_bytes() -> int:
        local_remaining = max(0, max_input_bytes - input_bytes_read)
        shared_remaining = transitive_remaining_bytes(state)
        return (
            local_remaining
            if shared_remaining is None
            else min(local_remaining, max(0, shared_remaining))
        )

    def charge_input_bytes(count: int) -> None:
        nonlocal input_bytes_read
        charged = max(0, count)
        input_bytes_read += charged
        if callable(record_bytes):
            record_bytes(charged)

    def record_policy_metadata(
        path: str,
        exclusion_reason: LedgerReason | None,
        *,
        size_bytes: int,
        executable: bool,
        incomplete: bool,
        limitation_reason: LedgerReason | None = None,
        allowed_exclusion: bool = False,
    ) -> None:
        hidden = _is_hidden_component(path)
        policy_reason = exclusion_reason or limitation_reason or LedgerReason.UNACCOUNTED_WORK
        row: dict[str, object] = {
            "path": path,
            "type": _infer_file_type(path),
            "lines": 0,
            "executable": executable,
            "size_bytes": max(0, size_bytes),
            "hidden": hidden,
            "local_only": True,
            "outer_path": path,
            "nested_path": path,
            "container_type": "filesystem",
            "container_ancestry": ["filesystem"],
            "container_depth": 0,
            "outer_hidden": hidden,
            "concealed_executable": executable,
            "excluded_from_analysis": True,
            "concealment_reasons": [policy_reason.value],
        }
        if exclusion_reason is not None:
            row["inherited_exclusion_reason"] = exclusion_reason.value
        if allowed_exclusion:
            row["allowed_exclusion"] = True
            row["concealed_executable"] = False
        if incomplete:
            row["excluded_inspection_incomplete"] = True
        if limitation_reason is not None:
            row["inspection_limitation_reason"] = limitation_reason.value
        metadata.append(row)

    def record_executable_events(
        path: str,
        exclusion_reason: LedgerReason,
        *,
        allowed_exclusion: bool = False,
    ) -> None:
        if exclusion_reason is LedgerReason.EXCLUDED_DIRECTORY:
            events.append(
                ledger_event(
                    outcome=LedgerOutcome.OUT_OF_SCOPE,
                    record_type=LedgerRecordType.SCOPE_BOUNDARY,
                    phase="exclusion_audit",
                    path=path,
                    reason=exclusion_reason,
                )
            )
        if not allowed_exclusion:
            events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="exclusion_audit",
                    path=path,
                    reason=LedgerReason.EXCLUDED_EXECUTABLE_CONTENT,
                )
            )

    def record_partial(
        path: str,
        reason: LedgerReason,
        *,
        exclusion_reason: LedgerReason,
        size_bytes: int = 0,
        executable: bool = False,
        error_class: str | None = None,
        observed_bytes: int | None = None,
        limit_bytes: int | None = None,
    ) -> None:
        inventory.append(
            _opaque_artifact_record(
                path,
                disposition=ArtifactDisposition.PARTIAL,
                reason=reason,
                referenced=False,
                size_bytes=size_bytes,
            )
        )
        events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="exclusion_audit",
                path=path,
                reason=reason,
                error_class=error_class,
                observed_bytes=observed_bytes,
                limit_bytes=limit_bytes,
            )
        )
        record_policy_metadata(
            path,
            exclusion_reason,
            size_bytes=size_bytes,
            executable=executable,
            incomplete=True,
            limitation_reason=reason,
        )
        if executable:
            record_executable_events(path, exclusion_reason)

    def runtime_exhausted(
        index: int,
        path: str,
        *,
        current_size_bytes: int = 0,
    ) -> bool:
        now = monotonic()
        remaining_seconds = transitive_remaining_seconds(state)
        if now < deadline and (remaining_seconds is None or remaining_seconds > 0):
            return False
        elapsed = max(0.0, now - started_at)
        for tail_index, (omitted, exclusion_reason) in enumerate(items[index:], start=index):
            inventory.append(
                _opaque_artifact_record(
                    omitted,
                    disposition=ArtifactDisposition.PARTIAL,
                    reason=LedgerReason.RUNTIME_LIMIT,
                    referenced=False,
                    size_bytes=current_size_bytes if tail_index == index else 0,
                )
            )
            record_policy_metadata(
                omitted,
                exclusion_reason,
                size_bytes=current_size_bytes if tail_index == index else 0,
                executable=False,
                incomplete=True,
                limitation_reason=LedgerReason.RUNTIME_LIMIT,
            )
        events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="exclusion_audit",
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=elapsed,
                limit_seconds=runtime_limit,
            )
        )
        transitive_note_truncation(state, f"time budget exhausted auditing exclusion at {path}")
        return True

    for path, (exclusion_reason, limitation_reason) in sorted(
        (incomplete_exclusions or {}).items()
    ):
        record_policy_metadata(
            path,
            exclusion_reason,
            size_bytes=0,
            executable=False,
            incomplete=True,
            limitation_reason=limitation_reason,
        )

    for index, (path, exclusion_reason) in enumerate(items):
        if runtime_exhausted(index, path):
            break

        full = skill_dir / path
        executable = is_executable_content(path, b"")
        try:
            with _open_regular_file_no_follow(full) as source:
                file_stat = os.fstat(source.fileno())
                size_bytes = max(0, file_stat.st_size)
                executable = is_executable_content(path, b"", file_stat.st_mode)
                probe_size = min(_EXECUTABLE_PROBE_BYTES, size_bytes)
                probe = b""
                if probe_size:
                    remaining_bytes = remaining_input_bytes()
                    if remaining_bytes < probe_size:
                        transitive_note_truncation(
                            state, f"byte budget exhausted auditing exclusion at {path}"
                        )
                        record_partial(
                            path,
                            LedgerReason.TOTAL_BYTES_LIMIT,
                            exclusion_reason=exclusion_reason,
                            size_bytes=size_bytes,
                            executable=executable,
                            observed_bytes=probe_size,
                            limit_bytes=remaining_bytes,
                        )
                        continue
                    probe = source.read(probe_size)
                    charge_input_bytes(len(probe))
                    if len(probe) != probe_size:
                        record_partial(
                            path,
                            LedgerReason.READ_ERROR,
                            exclusion_reason=exclusion_reason,
                            size_bytes=size_bytes,
                            executable=executable,
                        )
                        continue
                    executable = is_executable_content(
                        path,
                        probe,
                        file_stat.st_mode,
                        complete_content=len(probe) == size_bytes,
                    )
                archive_candidate = is_archive_content(probe)
                expected_archive = expected_container_type(path) is not None
                if expected_archive and not archive_candidate:
                    record_partial(
                        path,
                        LedgerReason.ARCHIVE_FORMAT_MISMATCH,
                        exclusion_reason=exclusion_reason,
                        size_bytes=size_bytes,
                        executable=executable,
                    )
                    continue
                if archive_candidate:
                    if size_bytes > MAX_ANALYZABLE_FILE_BYTES:
                        record_partial(
                            path,
                            LedgerReason.SIZE_LIMIT,
                            exclusion_reason=exclusion_reason,
                            size_bytes=size_bytes,
                            executable=executable,
                            observed_bytes=size_bytes,
                            limit_bytes=MAX_ANALYZABLE_FILE_BYTES,
                        )
                        continue
                    remaining_size = size_bytes - len(probe)
                    remaining_bytes = remaining_input_bytes()
                    if remaining_size > remaining_bytes:
                        transitive_note_truncation(
                            state, f"byte budget exhausted auditing archive exclusion at {path}"
                        )
                        record_partial(
                            path,
                            LedgerReason.TOTAL_BYTES_LIMIT,
                            exclusion_reason=exclusion_reason,
                            size_bytes=size_bytes,
                            executable=executable,
                            observed_bytes=input_bytes_read + remaining_size,
                            limit_bytes=input_bytes_read + remaining_bytes,
                        )
                        continue
                    remainder = source.read(remaining_size)
                    charge_input_bytes(len(remainder))
                    final_stat = os.fstat(source.fileno())
                    if len(remainder) != remaining_size or final_stat.st_size != file_stat.st_size:
                        record_partial(
                            path,
                            LedgerReason.READ_ERROR,
                            exclusion_reason=exclusion_reason,
                            size_bytes=max(size_bytes, final_stat.st_size),
                            executable=executable,
                        )
                        continue
                    archive_cache[path] = probe + remainder
        except FileNotFoundError as exc:
            record_partial(
                path,
                LedgerReason.FILE_DISAPPEARED,
                exclusion_reason=exclusion_reason,
                executable=executable,
                error_class=type(exc).__name__,
            )
            continue
        except _UnsafeFileError as exc:
            record_partial(
                path,
                LedgerReason.NOT_REGULAR_FILE,
                exclusion_reason=exclusion_reason,
                executable=executable,
                error_class=type(exc).__name__,
            )
            continue
        except _FileOpenError as exc:
            record_partial(
                path,
                LedgerReason.READ_ERROR,
                exclusion_reason=exclusion_reason,
                executable=executable,
                error_class=exc.error_class,
            )
            continue
        except OSError as exc:
            record_partial(
                path,
                LedgerReason.READ_ERROR,
                exclusion_reason=exclusion_reason,
                executable=executable,
                error_class=type(exc).__name__,
            )
            continue

        if runtime_exhausted(index, path, current_size_bytes=size_bytes):
            archive_cache.pop(path, None)
            break

        inventory.append(
            _opaque_artifact_record(
                path,
                disposition=ArtifactDisposition.OUT_OF_SCOPE,
                reason=exclusion_reason,
                referenced=False,
                size_bytes=size_bytes,
            )
        )
        if not executable:
            continue

        allowed_exclusion = (
            exclusion_reason is LedgerReason.VCS_METADATA
            and _is_allowed_inactive_git_hook_template(path, probe)
        )
        record_policy_metadata(
            path,
            exclusion_reason,
            size_bytes=size_bytes,
            executable=True,
            incomplete=False,
            allowed_exclusion=allowed_exclusion,
        )
        record_executable_events(
            path,
            exclusion_reason,
            allowed_exclusion=allowed_exclusion,
        )

    for artifact in inventory:
        exclusion_reason = excluded_artifacts.get(artifact["path"])
        if exclusion_reason is not None:
            artifact["inherited_exclusion_reason"] = exclusion_reason.value

    return inventory, metadata, events, archive_cache, input_bytes_read


def _mark_referenced_excluded_artifacts(
    referenced_paths: frozenset[str],
    excluded_artifacts: Mapping[str, LedgerReason],
    artifact_inventory: Mapping[str, ArtifactRecord],
    component_metadata: list[dict[str, object]],
) -> list[InspectionLedgerEvent]:
    """Fail closed when a resolved reference targets content outside analysis.

    Exclusion discovery intentionally reads only a bounded executable/archive
    prefix from ordinary excluded files.  That is sufficient for unreferenced
    dependency metadata, but not for a file that SKILL.md explicitly names: an
    extensionless loader can contain executable source without a shebang, mode
    bit, or magic prefix.  Keep the bytes out of provider-visible caches while
    making the missing deterministic coverage blocking and reportable.
    """
    events: list[InspectionLedgerEvent] = []
    metadata_by_path = {
        str(item.get("path", "")): item for item in component_metadata if item.get("path")
    }

    for path in sorted(referenced_paths):
        exclusion_reason = excluded_artifacts.get(path)
        artifact = artifact_inventory.get(path)
        # A selected suppression baseline has its own bounded parser and is an
        # explicit scanner input, rather than an install-time artifact invoked
        # by SKILL.md.  Preserve that existing policy boundary.
        if (
            exclusion_reason is None
            or exclusion_reason is LedgerReason.BASELINE_FILE
            or artifact is None
            or artifact.get("disposition") is ArtifactDisposition.ANALYZED
        ):
            continue

        metadata = metadata_by_path.get(path)
        if metadata is not None:
            metadata["referenced"] = True
            already_blocks = metadata.get("allowed_exclusion") is not True and (
                metadata.get("concealed_executable") is True
                or metadata.get("excluded_inspection_incomplete") is True
            )
            if already_blocks:
                continue
        if metadata is None:
            hidden = _is_hidden_component(path)
            metadata = {
                "path": path,
                "type": _infer_file_type(path),
                "lines": 0,
                "executable": False,
                "size_bytes": max(0, int(artifact.get("size_bytes", 0))),
                "hidden": hidden,
                "local_only": True,
                "outer_path": path,
                "nested_path": path,
                "container_type": "filesystem",
                "container_ancestry": ["filesystem"],
                "container_depth": 0,
                "outer_hidden": hidden,
                "concealed_executable": False,
                "excluded_from_analysis": True,
                "concealment_reasons": [exclusion_reason.value],
            }
            component_metadata.append(metadata)
            metadata_by_path[path] = metadata

        raw_reasons = metadata.get("concealment_reasons", [])
        reasons = [str(reason) for reason in raw_reasons] if isinstance(raw_reasons, list) else []
        metadata.update(
            {
                "referenced": True,
                "excluded_from_analysis": True,
                "excluded_inspection_incomplete": True,
                "inherited_exclusion_reason": exclusion_reason.value,
                "inspection_limitation_reason": LedgerReason.REFERENCED_UNINSPECTED.value,
                "concealment_reasons": list(
                    dict.fromkeys(
                        [
                            *reasons,
                            exclusion_reason.value,
                            LedgerReason.REFERENCED_UNINSPECTED.value,
                        ]
                    )
                ),
            }
        )
        # Inactive hook templates are allowed only while they remain inert
        # examples.  An explicit reference makes the template runtime-relevant.
        metadata.pop("allowed_exclusion", None)
        if metadata.get("executable") is True:
            metadata["concealed_executable"] = True

        events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="reference_resolution",
                path=path,
                reason=LedgerReason.REFERENCED_UNINSPECTED,
            )
        )

    return events


def _read_file_cache(
    skill_dir: Path,
    components: list[str],
    referenced_paths: frozenset[str] = frozenset(),
    *,
    started_at: float | None = None,
    state: SkillspectorState | None = None,
    provider_submission_allowed: bool = True,
    zip_tails: dict[str, bytes] | None = None,
) -> tuple[
    dict[str, str],
    dict[str, bytes],
    dict[str, str],
    list[ArtifactRecord],
    list[InspectionLedgerEvent],
]:
    """Build canonical byte/text caches, inventory rows, and cache-failure events."""
    file_cache: dict[str, str] = {}
    raw_file_cache: dict[str, bytes] = {}
    llm_file_cache: dict[str, str] = {}
    inventory: list[ArtifactRecord] = []
    ledger_events: list[InspectionLedgerEvent] = []
    skill_root = skill_dir.resolve(strict=False)
    traversal = transitive_traversal_state(state) if state is not None else None
    started = monotonic() if started_at is None else started_at
    initial_shared_seconds = transitive_remaining_seconds(state) if state is not None else None
    cache_runtime_limit = min(
        MAX_BUNDLE_CACHE_SECONDS,
        max(0.0, initial_shared_seconds)
        if initial_shared_seconds is not None
        else MAX_BUNDLE_CACHE_SECONDS,
    )
    total_cached_bytes = 0

    def _record_cache_runtime_limit(
        path: str,
        component_index: int,
        *,
        action: str,
        current_size: int = 0,
    ) -> bool:
        """Record an expired cache deadline and its deterministic affected suffix."""
        elapsed = monotonic() - started
        remaining_seconds = transitive_remaining_seconds(state) if state is not None else None
        if elapsed < MAX_BUNDLE_CACHE_SECONDS and not (
            remaining_seconds is not None and remaining_seconds <= 0
        ):
            return False
        if state is not None and remaining_seconds is not None and remaining_seconds <= 0:
            transitive_note_truncation(state, f"time budget exhausted {action} {path}")
        ledger_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="cache",
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=max(0.0, elapsed),
                limit_seconds=cache_runtime_limit,
            )
        )
        inventory.append(
            _opaque_artifact_record(
                path,
                disposition=ArtifactDisposition.PARTIAL,
                reason=LedgerReason.RUNTIME_LIMIT,
                referenced=path in referenced_paths,
                size_bytes=current_size,
            )
        )
        inventory.extend(
            _opaque_artifact_record(
                omitted,
                disposition=ArtifactDisposition.PARTIAL,
                reason=LedgerReason.RUNTIME_LIMIT,
                referenced=omitted in referenced_paths,
            )
            for omitted in components[component_index + 1 :]
        )
        return True

    for component_index, path in enumerate(components):
        if _record_cache_runtime_limit(
            path,
            component_index,
            action="before reading",
        ):
            break
        local_remaining_bytes = MAX_TOTAL_CACHED_BYTES - total_cached_bytes
        shared_remaining_bytes = transitive_remaining_bytes(state) if state is not None else None
        remaining_bundle_bytes = (
            local_remaining_bytes
            if shared_remaining_bytes is None
            else min(local_remaining_bytes, shared_remaining_bytes)
        )
        effective_total_limit = total_cached_bytes + max(0, remaining_bundle_bytes)
        if remaining_bundle_bytes <= 0:
            if (
                state is not None
                and shared_remaining_bytes is not None
                and shared_remaining_bytes <= 0
            ):
                transitive_note_truncation(state, f"byte budget exhausted before reading {path}")
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.TOTAL_BYTES_LIMIT,
                    observed_bytes=total_cached_bytes + 1,
                    limit_bytes=min(MAX_TOTAL_CACHED_BYTES, total_cached_bytes),
                )
            )
            inventory.extend(
                _opaque_artifact_record(
                    omitted,
                    disposition=ArtifactDisposition.PARTIAL,
                    reason=LedgerReason.TOTAL_BYTES_LIMIT,
                    referenced=omitted in referenced_paths,
                )
                for omitted in components[component_index:]
            )
            break
        full = skill_dir / path
        unsafe_path = _is_symlink(full) or _resolves_outside(full, skill_root)
        if _record_cache_runtime_limit(
            path,
            component_index,
            action="while validating",
        ):
            break
        if unsafe_path:
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.OUT_OF_SCOPE,
                    record_type=LedgerRecordType.SCOPE_BOUNDARY,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.OUT_OF_SCOPE,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                    referenced=path in referenced_paths,
                )
            )
            continue
        try:
            file_stat = full.stat()
        except FileNotFoundError as exc:
            if _record_cache_runtime_limit(
                path,
                component_index,
                action="while stating",
            ):
                break
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.FILE_DISAPPEARED,
                    error_class=type(exc).__name__,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.FILE_DISAPPEARED,
                    referenced=path in referenced_paths,
                )
            )
            continue
        except OSError as exc:
            if _record_cache_runtime_limit(
                path,
                component_index,
                action="while stating",
            ):
                break
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.STAT_ERROR,
                    error_class=type(exc).__name__,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.STAT_ERROR,
                    referenced=path in referenced_paths,
                )
            )
            continue
        if _record_cache_runtime_limit(
            path,
            component_index,
            action="while stating",
            current_size=file_stat.st_size,
        ):
            break
        if not S_ISREG(file_stat.st_mode):
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                    referenced=path in referenced_paths,
                    size_bytes=file_stat.st_size,
                )
            )
            continue
        try:
            # Always bound the post-stat read as well.  A file can grow between
            # stat and open, and a stale size must not turn this into an
            # unbounded allocation.
            per_file_limit = min(MAX_ANALYZABLE_FILE_BYTES, remaining_bundle_bytes)
            # The archive reader already accepts disk containers up to its 25 MiB
            # input bound. Keep any additional bytes local to nested inspection,
            # charging them to this bundle and its transitive workflow.
            tail = b""
            if zip_tails is not None and per_file_limit < file_stat.st_size <= min(
                ARCHIVE_MAX_UNCOMPRESSED_BYTES, remaining_bundle_bytes
            ):
                observed = _read_zip_candidate(full, per_file_limit, file_stat.st_size)
                if is_zip_content(observed) and len(observed) == file_stat.st_size:
                    tail = observed[per_file_limit:]
            else:
                observed = _read_bytes_no_follow(full, max_bytes=per_file_limit + 1)
            per_file_truncated = (
                file_stat.st_size > MAX_ANALYZABLE_FILE_BYTES
                or len(observed) > MAX_ANALYZABLE_FILE_BYTES
            )
            aggregate_truncated = (
                file_stat.st_size > remaining_bundle_bytes or len(observed) > remaining_bundle_bytes
            )
            truncated = per_file_truncated or aggregate_truncated
            raw = observed[:per_file_limit]
            observed_total_bytes = total_cached_bytes + max(file_stat.st_size, len(observed))
            record_bytes = getattr(traversal, "record_bytes", None)
            if callable(record_bytes):
                record_bytes(len(raw) + len(tail))
            if _record_cache_runtime_limit(
                path,
                component_index,
                action="while reading",
                current_size=max(file_stat.st_size, len(observed)),
            ):
                break
            content = decode_text(raw)
            if _record_cache_runtime_limit(
                path,
                component_index,
                action="while decoding",
                current_size=max(file_stat.st_size, len(observed)),
            ):
                break
            artifact = classify_artifact(path, raw, referenced=path in referenced_paths)
            if _record_cache_runtime_limit(
                path,
                component_index,
                action="while classifying",
                current_size=max(file_stat.st_size, len(observed)),
            ):
                break
            total_cached_bytes += len(raw) + len(tail)
            raw_file_cache[path] = raw
            if tail and zip_tails is not None:
                zip_tails[path] = tail
            file_cache[path] = content
            if truncated:
                observed_size = max(file_stat.st_size, len(observed))
                artifact["size_bytes"] = observed_size
                artifact["disposition"] = ArtifactDisposition.PARTIAL
                artifact["reason"] = "total_bytes_limit" if aggregate_truncated else "size_limit"
                if per_file_truncated:
                    ledger_events.append(
                        ledger_event(
                            outcome=LedgerOutcome.PARTIAL,
                            record_type=LedgerRecordType.SYSTEM,
                            phase="cache",
                            path=path,
                            reason=LedgerReason.SIZE_LIMIT,
                            observed_bytes=observed_size,
                            limit_bytes=MAX_ANALYZABLE_FILE_BYTES,
                        )
                    )
                if aggregate_truncated:
                    if (
                        state is not None
                        and shared_remaining_bytes is not None
                        and shared_remaining_bytes <= local_remaining_bytes
                    ):
                        transitive_note_truncation(
                            state, f"byte budget exhausted while reading {path}"
                        )
                    ledger_events.append(
                        ledger_event(
                            outcome=LedgerOutcome.PARTIAL,
                            record_type=LedgerRecordType.SYSTEM,
                            phase="cache",
                            path=path,
                            reason=LedgerReason.TOTAL_BYTES_LIMIT,
                            observed_bytes=observed_total_bytes,
                            limit_bytes=effective_total_limit,
                        )
                    )
            inventory.append(artifact)
            if (
                provider_submission_allowed
                and not _is_hidden_path(path)
                and (artifact["content_kind"] == "text" or artifact.get("readable_binary"))
            ):
                if artifact.get("readable_binary"):
                    content = binary_instruction_view(content)[0].text
                if truncated:
                    content = _llm_view_of_truncated_file(
                        content,
                        total_size=max(file_stat.st_size, len(observed)),
                        read_bytes=len(raw),
                    )
                llm_file_cache[path] = _redact_for_external_model(path, content)
            if aggregate_truncated:
                inventory.extend(
                    _opaque_artifact_record(
                        omitted,
                        disposition=ArtifactDisposition.PARTIAL,
                        reason=LedgerReason.TOTAL_BYTES_LIMIT,
                        referenced=omitted in referenced_paths,
                    )
                    for omitted in components[component_index + 1 :]
                )
                break
        except FileNotFoundError as exc:
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.FILE_DISAPPEARED,
                    error_class=type(exc).__name__,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.FILE_DISAPPEARED,
                    referenced=path in referenced_paths,
                )
            )
        except _UnsafeFileError:
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.OUT_OF_SCOPE,
                    record_type=LedgerRecordType.SCOPE_BOUNDARY,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.OUT_OF_SCOPE,
                    reason=LedgerReason.NOT_REGULAR_FILE,
                    referenced=path in referenced_paths,
                )
            )
        except _FileOpenError as exc:
            logger.debug("Could not read file: %s", path)
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.READ_ERROR,
                    error_class=exc.error_class,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.READ_ERROR,
                    referenced=path in referenced_paths,
                    size_bytes=file_stat.st_size,
                )
            )
        except OSError as exc:
            logger.debug("Could not read file: %s", path)
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=LedgerReason.READ_ERROR,
                    error_class=type(exc).__name__,
                )
            )
            inventory.append(
                _opaque_artifact_record(
                    path,
                    disposition=ArtifactDisposition.FAILED,
                    reason=LedgerReason.READ_ERROR,
                    referenced=path in referenced_paths,
                    size_bytes=file_stat.st_size,
                )
            )
    return file_cache, raw_file_cache, llm_file_cache, inventory, ledger_events


class _ManifestLimitError(yaml.YAMLError):
    """Internal signal that bounded YAML composition exhausted a resource."""

    def __init__(self, kind: str, observed: int | float) -> None:
        super().__init__(kind)
        self.kind = kind
        self.observed = observed


class _ManifestSchemaError(yaml.YAMLError):
    """Internal signal for unsupported manifest value shapes."""


class _BoundedManifestLoader(yaml.SafeLoader):
    """SafeLoader with explicit node, nesting, and elapsed-time ceilings."""

    def __init__(
        self,
        stream: str,
        *,
        clock: Callable[[], float] = monotonic,
        started_at: float | None = None,
        deadline: float | None = None,
    ) -> None:
        super().__init__(stream)
        self._manifest_clock = clock
        self._manifest_started = clock() if started_at is None else started_at
        self._manifest_deadline = (
            self._manifest_started + MAX_MANIFEST_PARSE_SECONDS if deadline is None else deadline
        )
        self._manifest_nodes = 0
        self._manifest_depth = 0
        self._version_key_event: yaml.NodeEvent | None = None
        self.version_marks: tuple[yaml.NodeEvent, yaml.Mark, yaml.Mark] | None = None

    def flatten_mapping(self, node: yaml.MappingNode) -> None:
        """Reject YAML merge keys before SafeConstructor can amplify aliases."""
        if any(key_node.tag == "tag:yaml.org,2002:merge" for key_node, _ in node.value):
            raise _ManifestSchemaError("merge_key")
        super().flatten_mapping(node)

    def compose_node(self, parent: object, index: object) -> yaml.Node:
        now = self._manifest_clock()
        elapsed = max(0.0, now - self._manifest_started)
        if now >= self._manifest_deadline:
            raise _ManifestLimitError("runtime", elapsed)
        self._manifest_nodes += 1
        if self._manifest_nodes > MAX_MANIFEST_YAML_NODES:
            raise _ManifestLimitError("nodes", self._manifest_nodes)
        self._manifest_depth += 1
        if self._manifest_depth > MAX_MANIFEST_YAML_DEPTH:
            self._manifest_depth -= 1
            raise _ManifestLimitError("depth", self._manifest_depth + 1)
        try:
            # Inspect the top-level mapping's events so aliases retain the
            # use site's coordinates, even when they reuse an anchored node.
            event = (
                self.peek_event()
                if self._manifest_depth == 2 and isinstance(parent, yaml.MappingNode)
                else None
            )
            node = super().compose_node(parent, index)
            key = node if index is None else index
            if (
                isinstance(event, yaml.NodeEvent)
                and isinstance(key, yaml.ScalarNode)
                and key.tag in ("tag:yaml.org,2002:str", "tag:yaml.org,2002:value")
                and key.value == "version"
            ):
                if index is None:
                    self._version_key_event = event
                elif self._version_key_event is not None:
                    self.version_marks = (self._version_key_event, event.start_mark, event.end_mark)
            return node
        finally:
            self._manifest_depth -= 1


def _validate_manifest_graph(
    value: object,
    *,
    started_at: float,
    deadline: float,
    clock: Callable[[], float] = monotonic,
) -> None:
    """Reject cyclic or unexpectedly complex constructed YAML object graphs."""
    active: set[int] = set()
    visited: set[int] = set()
    nodes = 0

    def _visit(item: object, depth: int) -> None:
        nonlocal nodes
        now = clock()
        elapsed = max(0.0, now - started_at)
        if now >= deadline:
            raise _ManifestLimitError("runtime", elapsed)
        nodes += 1
        if nodes > MAX_MANIFEST_YAML_NODES:
            raise _ManifestLimitError("nodes", nodes)
        if depth > MAX_MANIFEST_YAML_DEPTH:
            raise _ManifestLimitError("depth", depth)
        if not isinstance(item, (Mapping, list, tuple)):
            return
        identity = id(item)
        if identity in active:
            raise _ManifestLimitError("depth", MAX_MANIFEST_YAML_DEPTH + 1)
        if identity in visited:
            return
        active.add(identity)
        visited.add(identity)
        try:
            children = (
                (child for pair in item.items() for child in pair)
                if isinstance(item, Mapping)
                else iter(item)
            )
            for child in children:
                _visit(child, depth + 1)
        finally:
            active.remove(identity)

    _visit(value, 0)


def _record_manifest_limit(
    ledger_events: list[InspectionLedgerEvent] | None,
    *,
    path: str,
    kind: str,
    observed: int | float,
    runtime_limit: float = MAX_MANIFEST_PARSE_SECONDS,
) -> None:
    """Record one parser limitation without exposing manifest contents."""
    if ledger_events is None:
        return
    observed_characters: int | None = None
    limit_characters: int | None = None
    observed_bytes: int | None = None
    limit_bytes: int | None = None
    observed_records: int | None = None
    limit_records: int | None = None
    observed_depth: int | None = None
    limit_depth: int | None = None
    observed_seconds: float | None = None
    limit_seconds: float | None = None
    if kind == "bytes":
        observed_bytes = int(observed)
        limit_bytes = MAX_MANIFEST_FRONTMATTER_BYTES
    elif kind in {"nodes", "output_records"}:
        observed_records = int(observed)
        limit_records = MAX_MANIFEST_YAML_NODES if kind == "nodes" else MAX_MANIFEST_OUTPUT_RECORDS
    elif kind == "characters":
        observed_characters = int(observed)
        limit_characters = MAX_MANIFEST_OUTPUT_CHARACTERS
    elif kind == "depth":
        observed_depth = int(observed)
        limit_depth = MAX_MANIFEST_YAML_DEPTH
    else:
        observed_seconds = float(observed)
        limit_seconds = runtime_limit
    ledger_events.append(
        ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase="manifest",
            path=path,
            reason=LedgerReason.MANIFEST_PARSE_LIMIT,
            observed_characters=observed_characters,
            limit_characters=limit_characters,
            observed_bytes=observed_bytes,
            limit_bytes=limit_bytes,
            observed_records=observed_records,
            limit_records=limit_records,
            observed_depth=observed_depth,
            limit_depth=limit_depth,
            observed_seconds=observed_seconds,
            limit_seconds=limit_seconds,
        )
    )


def _record_manifest_parse_error(
    ledger_events: list[InspectionLedgerEvent] | None,
    *,
    path: str,
    error_class: str | None = None,
) -> None:
    """Record malformed claimed frontmatter as incomplete analysis."""
    if ledger_events is None:
        return
    ledger_events.append(
        ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase="manifest",
            path=path,
            reason=LedgerReason.MANIFEST_PARSE_ERROR,
            error_class=error_class,
        )
    )


def _project_manifest(
    data: Mapping[str, object],
    *,
    started_at: float,
    deadline: float,
    clock: Callable[[], float] = monotonic,
) -> dict[str, object]:
    """Project only the supported manifest schema under output/runtime ceilings."""
    records = 0
    characters = 0

    def _check() -> None:
        now = clock()
        elapsed = max(0.0, now - started_at)
        if now >= deadline:
            raise _ManifestLimitError("runtime", elapsed)

    def _consume(text: str = "") -> None:
        nonlocal records, characters
        _check()
        records += 1
        if records > MAX_MANIFEST_OUTPUT_RECORDS:
            raise _ManifestLimitError("output_records", records)
        characters += len(text)
        if characters > MAX_MANIFEST_OUTPUT_CHARACTERS:
            raise _ManifestLimitError("characters", characters)

    def _scalar_text(value: object) -> str:
        if not isinstance(value, (str, int, float, bool)):
            raise _ManifestSchemaError(type(value).__name__)
        text = str(value)
        _consume(text)
        return text

    def _clone_bounded(value: object, *, depth: int, active: set[int]) -> object:
        """Clone parameter metadata while charging every projected occurrence.

        YAML aliases share constructed Python objects.  Charging the output
        projection rather than unique object identities prevents a small
        alias graph from expanding into an unbounded returned manifest.
        """
        _check()
        if depth > MAX_MANIFEST_YAML_DEPTH:
            raise _ManifestLimitError("depth", depth)
        if value is None:
            _consume()
            return None
        if isinstance(value, (str, int, float, bool)):
            _consume(str(value))
            return value
        if not isinstance(value, (Mapping, list, tuple)):
            raise _ManifestSchemaError(type(value).__name__)
        identity = id(value)
        if identity in active:
            raise _ManifestLimitError("depth", MAX_MANIFEST_YAML_DEPTH + 1)
        active.add(identity)
        _consume()
        try:
            if isinstance(value, Mapping):
                cloned: dict[str, object] = {}
                for key, item in value.items():
                    if not isinstance(key, str):
                        raise _ManifestSchemaError(type(key).__name__)
                    _consume(key)
                    cloned[key] = _clone_bounded(item, depth=depth + 1, active=active)
                return cloned
            return [_clone_bounded(item, depth=depth + 1, active=active) for item in value]
        finally:
            active.remove(identity)

    def _string_list(value: object) -> list[str]:
        if value is None:
            return []
        if not isinstance(value, list):
            raise _ManifestSchemaError(type(value).__name__)
        return [_scalar_text(item) for item in value]

    manifest: dict[str, object] = {}
    name = data.get("name")
    if name is not None:
        if not isinstance(name, str):
            raise _ManifestSchemaError(type(name).__name__)
        _consume(name)
        manifest["name"] = name
    description = data.get("description")
    if description is not None:
        if not isinstance(description, str):
            raise _ManifestSchemaError(type(description).__name__)
        _consume(description)
        manifest["description"] = description
    version = data.get("version")
    if version is not None:
        manifest["version"] = _scalar_text(version)

    manifest["triggers"] = _string_list(data.get("triggers", []))
    manifest["permissions"] = _string_list(data.get("permissions", []))
    # `allowed-tools` (Agent Skills standard) — accept list, comma string, or space-separated string.
    # Separators inside a `Tool(specifier)` scope belong to the scope, so
    # `Bash(git status:*) Read` stays two grants.
    allowed_tools = data.get("allowed-tools", [])
    if isinstance(allowed_tools, str):
        tools: list[str] = []
        for item in iter_allowed_tools_entries(allowed_tools):
            _check()
            if item:
                tools.append(_scalar_text(item))
        manifest["allowed-tools"] = tools
    elif isinstance(allowed_tools, list):
        manifest["allowed-tools"] = [
            item.strip() for item in _string_list(allowed_tools) if item.strip()
        ]
    else:
        # Preserve the established compatibility behavior for malformed
        # scalar declarations without converting arbitrary containers.
        manifest["allowed-tools"] = []

    raw_parameters = data.get("parameters", [])
    if not isinstance(raw_parameters, list):
        raw_parameters = []
    parameters: list[dict[str, object]] = []
    for raw_parameter in raw_parameters:
        if not isinstance(raw_parameter, Mapping):
            continue
        parameter = _clone_bounded(raw_parameter, depth=0, active=set())
        if not isinstance(parameter, dict):  # defensive narrowing
            raise _ManifestSchemaError(type(parameter).__name__)
        parameters.append(parameter)
    manifest["parameters"] = parameters
    _check()
    return manifest


def _parse_manifest(
    skill_dir: Path,
    *,
    raw_file_cache: Mapping[str, bytes] | None = None,
    ledger_events: list[InspectionLedgerEvent] | None = None,
    clock: Callable[[], float] = monotonic,
    deadline: float | None = None,
) -> tuple[dict[str, object], ManifestVersionSource | None]:
    """Parse bounded SKILL.md or skill.md frontmatter and retain the version source.

    Returns dict with name, description, version, triggers (list), permissions
    (list), allowed-tools (list), parameters (list), along with the optional
    version source. Returns an empty manifest if no file or parse fails.
    Parsing is restricted to a bounded byte prefix, including for direct helper
    callers that do not provide the bundle's already-bounded raw cache.
    """
    started_at = clock()
    local_deadline = started_at + MAX_MANIFEST_PARSE_SECONDS
    effective_deadline = local_deadline if deadline is None else min(local_deadline, deadline)
    runtime_limit = max(0.0, effective_deadline - started_at)

    def _check_runtime() -> None:
        now = clock()
        if now >= effective_deadline:
            raise _ManifestLimitError("runtime", max(0.0, now - started_at))

    skill_root = skill_dir.resolve(strict=False)
    for name in ("SKILL.md", "skill.md"):
        path = skill_dir / name
        try:
            _check_runtime()
            if raw_file_cache is not None:
                # The cache is the canonical, no-follow snapshot selected by
                # bounded discovery.  Do not consult the mutable filesystem
                # again: doing so would let a post-cache removal or symlink
                # swap suppress otherwise valid cached frontmatter.
                cached = raw_file_cache.get(name)
                if cached is None:
                    continue
                observed = cached[: MAX_MANIFEST_FRONTMATTER_BYTES + 1]
            else:
                if _is_symlink(path) or _resolves_outside(path, skill_root) or not path.is_file():
                    continue
                observed = _read_bytes_no_follow(path, max_bytes=MAX_MANIFEST_FRONTMATTER_BYTES + 1)
            _check_runtime()
        except _ManifestLimitError as exc:
            _record_manifest_limit(
                ledger_events,
                path=name,
                kind=exc.kind,
                observed=exc.observed,
                runtime_limit=runtime_limit,
            )
            return {}, None
        except (OSError, _FileOpenError, _UnsafeFileError):
            logger.debug("Could not read manifest file: %s", name)
            return {}, None
        truncated = len(observed) > MAX_MANIFEST_FRONTMATTER_BYTES
        try:
            _check_runtime()
            content = decode_text(observed[:MAX_MANIFEST_FRONTMATTER_BYTES])
            _check_runtime()
        except _ManifestLimitError as exc:
            _record_manifest_limit(
                ledger_events,
                path=name,
                kind=exc.kind,
                observed=exc.observed,
                runtime_limit=runtime_limit,
            )
            return {}, None
        while content.startswith("\ufeff"):
            # decode_text() decodes with plain "utf-8", which never strips a
            # leading byte-order mark (only "utf-8-sig" does), so a BOM-prefixed
            # SKILL.md leaves content[0] == "\ufeff" and the delimiter check below
            # silently sees {} instead of the frontmatter. Strip leading BOMs here,
            # scoped to delimiter detection — decode_text() itself stays untouched
            # because P2/TP1/P9 treat U+FEFF as a hidden-character injection signal
            # in file bodies.
            content = content[1:]
        if not content.startswith("---"):
            return {}, None
        end_match = re.search(r"\n---\s*\n", content[3:])
        try:
            _check_runtime()
        except _ManifestLimitError as exc:
            _record_manifest_limit(
                ledger_events,
                path=name,
                kind=exc.kind,
                observed=exc.observed,
                runtime_limit=runtime_limit,
            )
            return {}, None
        if not end_match:
            if truncated:
                _record_manifest_limit(
                    ledger_events,
                    path=name,
                    kind="bytes",
                    observed=len(observed),
                )
            else:
                _record_manifest_parse_error(ledger_events, path=name)
            return {}, None
        frontmatter = content[3 : end_match.start() + 3]
        loader: _BoundedManifestLoader | None = None
        version_marks: tuple[yaml.NodeEvent, yaml.Mark, yaml.Mark] | None = None
        try:
            _check_runtime()
            loader = _BoundedManifestLoader(
                frontmatter,
                clock=clock,
                started_at=started_at,
                deadline=effective_deadline,
            )
            try:
                data = loader.get_single_data()
                version_marks = loader.version_marks
            except (ValueError, OverflowError, KeyError, AttributeError, IndexError) as exc:
                # SafeLoader's bounded scalar constructors may still reject a
                # syntactically valid scalar during conversion (for example,
                # Python's integer digit ceiling).  Treat only these expected
                # conversion failures as malformed manifest input; unrelated
                # exceptions remain visible to callers.
                logger.debug("Manifest scalar conversion failed for %s", name)
                _record_manifest_parse_error(
                    ledger_events,
                    path=name,
                    error_class=type(exc).__name__,
                )
                return {}, None
            _validate_manifest_graph(
                data,
                started_at=started_at,
                deadline=effective_deadline,
                clock=clock,
            )
        except _ManifestLimitError as exc:
            _record_manifest_limit(
                ledger_events,
                path=name,
                kind=exc.kind,
                observed=exc.observed,
                runtime_limit=runtime_limit,
            )
            return {}, None
        except (yaml.YAMLError, RecursionError) as exc:
            logger.debug("Manifest parse failed for %s", name)
            _record_manifest_parse_error(
                ledger_events,
                path=name,
                error_class=type(exc).__name__,
            )
            return {}, None
        finally:
            if loader is not None:
                loader.dispose()
        if not isinstance(data, dict):
            _record_manifest_parse_error(ledger_events, path=name)
            return {}, None
        try:
            manifest = _project_manifest(
                data,
                started_at=started_at,
                deadline=effective_deadline,
                clock=clock,
            )
        except _ManifestLimitError as exc:
            _record_manifest_limit(
                ledger_events,
                path=name,
                kind=exc.kind,
                observed=exc.observed,
                runtime_limit=runtime_limit,
            )
            return {}, None
        except _ManifestSchemaError as exc:
            _record_manifest_parse_error(
                ledger_events,
                path=name,
                error_class=type(exc).__name__,
            )
            return {}, None
        version = manifest.get("version")
        if version_marks is None or not isinstance(version, str):
            return manifest, None
        key_event, value_start, value_end = version_marks
        key_mark = key_event.start_mark
        snippet = None
        if (
            isinstance(key_event, yaml.ScalarEvent)
            and key_event.anchor is None
            and (
                key_event.tag is None
                or frontmatter.startswith(f"!<{key_event.tag}>", key_mark.index)
            )
            and key_mark.line == value_end.line
            and value_end.index - key_mark.index <= 200
        ):
            # Keep a literal source spelling when it exposes the same text as
            # the parsed version. Use the parsed preview for encoded scalars
            # and user-defined names in YAML anchors, aliases or tag handles.
            raw_value = frontmatter[value_start.index : value_end.index]
            if raw_value in (version, f"'{version}'", f'"{version}"'):
                snippet = frontmatter[key_mark.index : value_end.index]
        # The YAML input starts after the opening hyphens and retains the
        # opening line break. Its line numbers need only a 1-based offset.
        return manifest, {"path": name, "line": key_mark.line + 1, "snippet": snippet}
    return {}, None


def _decodes_as_declared_python(
    path: str,
    data: bytes,
    classification: PythonSourceClassification | None,
) -> bool:
    """Return whether Python bytes decode under their declared PEP 263 encoding."""
    if classification is None:
        classification = classify_python_source(path, data)
    if classification is PythonSourceClassification.NON_PYTHON:
        return False
    try:
        decode_python_source(data)
    except Exception:
        return False
    return True


def _unsupported_primary_bytes(
    artifact: ArtifactRecord,
    data: bytes,
    *,
    python_classification: PythonSourceClassification | None,
    deadline: float,
) -> bool:
    """Recognize opaque primary content without opening or expanding containers.

    Supported archives are handled separately by bounded nested inspection. Other archive
    headers and UTF-16/32 instructions must not count as decoded source text,
    even when their bytes happen to be valid UTF-8 (for example an ASCII TAR).
    Python source is decoded by its PEP 263 declaration rather than as UTF-8,
    so only a failed declared decode leaves non-UTF-8 Python unsupported.
    """
    split_utf8 = False
    if not artifact["decodable"] and artifact["size_bytes"] > len(data):
        # Only an unfinished trailing code point is explained by truncation.
        # An invalid sequence earlier in the cached prefix is still unsupported.
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            split_utf8 = exc.reason == "unexpected end of data"
    sample = data[:512]
    try:
        # Validates one fixed-size header (including its checksum), never
        # enumerates members or expands compressed/archive contents.
        tarfile.TarInfo.frombuf(sample, "utf-8", "surrogateescape")
    except tarfile.HeaderError:
        is_tar = False
    else:
        is_tar = True
    is_bzip2 = (
        sample.startswith(b"BZh")
        and sample[3:4] in b"123456789"
        and sample[4:10] in (b"1AY&SY", b"\x17rE8P\x90")
    )
    utf8_unsupported = (
        (artifact["content_kind"] != ContentKind.TEXT and not split_utf8)
        # A bounded prefix can split a valid UTF-8 code point. Existing size
        # accounting already marks that scan partial; it is not proof that the
        # complete source uses an unsupported encoding.
        or (not artifact["decodable"] and not split_utf8)
    )
    if (
        utf8_unsupported
        # Post-cache Python decoding must not begin after the shared deadline.
        and monotonic() < deadline
        and _decodes_as_declared_python(artifact["path"], data, python_classification)
    ):
        utf8_unsupported = False
    return (
        utf8_unsupported
        or sample.startswith((b"\xff\xfe", b"\xfe\xff", b"\x00\x00\xfe\xff"))
        or sample.startswith((b"\x1f\x8b", b"\xfd7zXZ\x00", b"7z\xbc\xaf\x27\x1c", b"Rar!\x1a\x07"))
        or is_tar
        or is_bzip2
        or (bool(sample) and sample.count(b"\x00") > len(sample) // 4)
    )


def build_context(state: SkillspectorState) -> dict[str, object]:
    """Build flat ScanContext fields from state skill_path (local directory).

    Resolves skill_path to a directory, walks files, builds file_cache
    and manifest. Returns only context keys; leaves findings untouched.
    Raises ValueError if skill_path is missing or not an existing directory.
    """
    # Start one graph-wide deadline before any discovery or preprocessing. A
    # transitive traversal supplied by the CLI is reused, preserving its
    # stricter cross-child byte/time allowances.
    workflow_budget = ensure_workflow_resource_budget(state)
    budgeted_state = dict(state)
    budgeted_state["workflow_resource_budget"] = workflow_budget
    state = cast(SkillspectorState, budgeted_state)
    source_local_only = state.get("source_local_only") is True

    skill_dir = _resolve_skill_dir(state)

    (
        inventoried_components,
        discovery_events,
        excluded_artifacts,
        excluded_inspection_gaps,
    ) = _walk_skill_files(skill_dir, state)
    patterns = state.get("exclude_patterns", [])
    if len(patterns) > 128 or any(
        not isinstance(pattern, str)
        or not pattern
        or len(pattern) > 1024
        or pattern.startswith("/")
        or "\\" in pattern
        or ".." in pattern.split("/")
        or any(ord(char) < 32 for char in pattern)
        for pattern in patterns
    ):
        raise ValueError("Exclusions require at most 128 relative POSIX globs (1-1024 characters)")
    if any(
        fnmatchcase(manifest, pattern)
        for manifest in ("SKILL.md", "skill.md")
        for pattern in patterns
    ):
        raise ValueError("--exclude must not match the required SKILL.md manifest")
    user_excluded = sorted(
        path
        for path in inventoried_components
        if any(fnmatchcase(path, pattern) for pattern in patterns)
    )
    user_excluded_set = set(user_excluded)
    inventoried_components = [
        path for path in inventoried_components if path not in user_excluded_set
    ]
    user_exclusion_events = [
        ledger_event(
            outcome=LedgerOutcome.SKIPPED,
            record_type=LedgerRecordType.SYSTEM,
            phase="explicit_exclusion",
            path=path,
            reason=LedgerReason.USER_EXCLUSION,
        )
        for path in user_excluded
    ]
    selected_baseline = _selected_baseline_component(state, skill_dir, inventoried_components)
    selected_baselines = frozenset({selected_baseline} if selected_baseline else set())
    for path in selected_baselines:
        excluded_artifacts[path] = LedgerReason.BASELINE_FILE
    cache_candidates = [path for path in inventoried_components if path not in selected_baselines]
    zip_tails: dict[str, bytes] = {}
    processing_started = monotonic()
    processing_deadline = processing_started + MAX_BUNDLE_CACHE_SECONDS
    shared_remaining_seconds = transitive_remaining_seconds(state)
    if shared_remaining_seconds is not None:
        processing_deadline = min(
            processing_deadline,
            processing_started + max(0.0, shared_remaining_seconds),
        )
    (
        ordinary_file_cache,
        raw_file_cache,
        llm_file_cache,
        artifact_inventory,
        cache_events,
    ) = _read_file_cache(
        skill_dir,
        cache_candidates,
        started_at=processing_started,
        state=state,
        provider_submission_allowed=not source_local_only,
        zip_tails=zip_tails,
    )
    cached_input_bytes = sum(map(len, raw_file_cache.values())) + sum(map(len, zip_tails.values()))
    (
        excluded_inventory,
        excluded_component_metadata,
        exclusion_audit_events,
        excluded_archive_cache,
        excluded_input_bytes,
    ) = _inspect_excluded_artifacts(
        skill_dir,
        excluded_artifacts,
        state=state,
        started_at=processing_started,
        deadline=processing_deadline,
        max_input_bytes=max(
            0,
            MAX_TOTAL_CACHED_BYTES - cached_input_bytes,
        ),
        incomplete_exclusions=excluded_inspection_gaps,
    )
    artifact_inventory.extend(
        {
            "path": path,
            "content_kind": ContentKind.OPAQUE,
            "disposition": ArtifactDisposition.PARTIAL,
            "size_bytes": 0,
            "decodable": False,
            "contains_nul": False,
            "misleading_extension": False,
            "referenced": False,
            "reason": LedgerReason.USER_EXCLUSION.value,
        }
        for path in user_excluded
    )
    artifact_inventory = sorted(
        [*artifact_inventory, *excluded_inventory], key=lambda item: item["path"]
    )

    inventory_by_path: dict[str, ArtifactRecord] = {
        item["path"]: item for item in artifact_inventory
    }
    prework_events: list[InspectionLedgerEvent] = []
    processing_runtime_limit = max(0.0, processing_deadline - processing_started)

    def _record_processing_runtime(*, phase: str, path: str, now: float) -> None:
        artifact = inventory_by_path.get(path)
        if artifact is not None and artifact.get("disposition") != ArtifactDisposition.FAILED:
            if artifact.get("disposition") != ArtifactDisposition.PARTIAL:
                artifact["reason"] = LedgerReason.RUNTIME_LIMIT.value
            artifact["disposition"] = ArtifactDisposition.PARTIAL
        prework_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase=phase,
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=max(0.0, now - processing_started),
                limit_seconds=processing_runtime_limit,
            )
        )

    recognized_oms_signature_paths: set[str] = set()
    if _OMS_SIGNATURE_PATH in raw_file_cache:
        signature_started = monotonic()
        if signature_started >= processing_deadline:
            _record_processing_runtime(
                phase="signature_recognition",
                path=_OMS_SIGNATURE_PATH,
                now=signature_started,
            )
        else:
            signature_valid = _is_valid_oms_signature_bytes(raw_file_cache[_OMS_SIGNATURE_PATH])
            signature_finished = monotonic()
            if signature_finished >= processing_deadline:
                _record_processing_runtime(
                    phase="signature_recognition",
                    path=_OMS_SIGNATURE_PATH,
                    now=signature_finished,
                )
            elif signature_valid:
                recognized_oms_signature_paths.add(_OMS_SIGNATURE_PATH)
    recognized_oms_signatures = frozenset(recognized_oms_signature_paths)
    signature_events: list[InspectionLedgerEvent] = []
    baseline_events = [
        ledger_event(
            outcome=LedgerOutcome.OUT_OF_SCOPE,
            record_type=LedgerRecordType.SCOPE_BOUNDARY,
            phase="discovery",
            path=path,
            reason=LedgerReason.BASELINE_FILE,
        )
        for path in sorted(selected_baselines)
    ]
    primary_path = next(
        (path for path in ("SKILL.md", "skill.md") if path in inventoried_components), None
    )
    references = []
    reference_events: list[InspectionLedgerEvent] = []
    reference_resolution: dict[str, object] = {}
    inventory_by_path = {item["path"]: item for item in artifact_inventory}
    if primary_path is not None and primary_path in raw_file_cache:
        primary_raw = raw_file_cache[primary_path]
        reference_started = monotonic()
        if reference_started >= processing_deadline:
            resolution = ReferenceResolutionResult(
                records=[],
                complete=False,
                limitations=("runtime",),
                input_bytes_examined=0,
                raw_candidates_considered=0,
                accepted_references=0,
                runtime_seconds=0.0,
                runtime_seconds_limit=0.0,
            )
        else:
            primary_text = decode_text(primary_raw[: MAX_REFERENCE_SOURCE_BYTES + 1])
            reference_after_decode = monotonic()
            if reference_after_decode >= processing_deadline:
                resolution = ReferenceResolutionResult(
                    records=[],
                    complete=False,
                    limitations=("runtime",),
                    input_bytes_examined=0,
                    raw_candidates_considered=0,
                    accepted_references=0,
                    runtime_seconds=max(0.0, reference_after_decode - reference_started),
                    runtime_seconds_limit=max(0.0, processing_deadline - reference_started),
                )
            else:
                resolution = resolve_bundle_references_with_metadata(
                    skill_dir,
                    source_path=primary_path,
                    source_text=primary_text,
                    metadata_root=(
                        Path(str(state["primary_file_parent_path"]))
                        if state.get("primary_file_parent_path")
                        else None
                    ),
                    known_paths=sorted(
                        dict.fromkeys(
                            [*inventoried_components, *excluded_artifacts, *user_excluded]
                        )
                    ),
                    clock=monotonic,
                    deadline=processing_deadline,
                )
        references = resolution.records
        for reference in references:
            if reference.get("target_path") in user_excluded_set:
                reference["disposition"] = ArtifactDisposition.PARTIAL
        primary_artifact = inventory_by_path.get(primary_path)
        primary_partial = (
            primary_artifact is not None
            and primary_artifact.get("disposition") == ArtifactDisposition.PARTIAL
        )
        limitations = list(resolution.limitations)
        if primary_partial:
            limitations.append("source_partial")
        limitations = list(dict.fromkeys(limitations))
        reference_resolution = {
            "complete": resolution.complete and not primary_partial,
            "limitations": limitations,
            "input_bytes_examined": resolution.input_bytes_examined,
            "input_bytes_limit": MAX_REFERENCE_SOURCE_BYTES,
            "raw_candidates_considered": resolution.raw_candidates_considered,
            "raw_candidates_limit": MAX_RAW_REFERENCE_CANDIDATES,
            "accepted_references": resolution.accepted_references,
            "accepted_references_limit": MAX_ACCEPTED_REFERENCES,
            "output_records": len(resolution.records),
            "output_records_limit": MAX_REFERENCE_RECORDS,
            "runtime_seconds": resolution.runtime_seconds,
            "runtime_seconds_limit": resolution.runtime_seconds_limit,
        }
        if limitations:
            primary_artifact = inventory_by_path.get(primary_path)
            if (
                primary_artifact is not None
                and primary_artifact.get("disposition") != ArtifactDisposition.FAILED
            ):
                if primary_artifact.get("disposition") != ArtifactDisposition.PARTIAL:
                    primary_artifact["reason"] = LedgerReason.REFERENCE_EXTRACTION_LIMIT.value
                primary_artifact["disposition"] = ArtifactDisposition.PARTIAL
        for limitation in limitations:
            observed_bytes: int | None = None
            limit_bytes: int | None = None
            observed_artifacts: int | None = None
            limit_artifacts: int | None = None
            observed_records: int | None = None
            limit_records: int | None = None
            observed_seconds: float | None = None
            limit_seconds: float | None = None
            if limitation == "input_bytes":
                observed_bytes = resolution.input_bytes_examined
                limit_bytes = MAX_REFERENCE_SOURCE_BYTES
            elif limitation == "raw_candidates":
                observed_artifacts = resolution.raw_candidates_considered
                limit_artifacts = MAX_RAW_REFERENCE_CANDIDATES
            elif limitation == "accepted_references":
                observed_artifacts = resolution.accepted_references
                limit_artifacts = MAX_ACCEPTED_REFERENCES
            elif limitation == "output_records":
                observed_records = len(resolution.records)
                limit_records = MAX_REFERENCE_RECORDS
            elif limitation == "runtime":
                observed_seconds = resolution.runtime_seconds
                limit_seconds = resolution.runtime_seconds_limit
            reference_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="reference_resolution",
                    path=primary_path,
                    reason=LedgerReason.REFERENCE_EXTRACTION_LIMIT,
                    stage=limitation,
                    observed_bytes=observed_bytes,
                    limit_bytes=limit_bytes,
                    observed_artifacts=observed_artifacts,
                    limit_artifacts=limit_artifacts,
                    observed_records=observed_records,
                    limit_records=limit_records,
                    observed_seconds=observed_seconds,
                    limit_seconds=limit_seconds,
                )
            )
        reference_events.extend(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="reference_resolution",
                path=primary_path,
                start_line=int(reference["line"]),
                end_line=int(reference["line"]),
                reason=(
                    LedgerReason.REFERENCE_MISSING
                    if reference["status"] == "missing"
                    else LedgerReason.REFERENCED_UNINSPECTED
                    if reference["status"] == "uninspected"
                    else LedgerReason.REFERENCE_UNRESOLVED
                ),
            )
            for reference in references
            if reference["status"] in {"missing", "ambiguous", "uninspected"}
        )

    referenced_paths = frozenset(
        str(reference["target_path"])
        for reference in references
        if reference["status"] == "resolved" and reference["target_path"]
    )
    for artifact in artifact_inventory:
        if artifact["path"] in referenced_paths:
            artifact["referenced"] = True
    reference_events.extend(
        _mark_referenced_excluded_artifacts(
            referenced_paths,
            excluded_artifacts,
            inventory_by_path,
            excluded_component_metadata,
        )
    )

    # Omitted paths remain represented in artifact_inventory, but are not fed
    # to analyzers without content. Genuine read failures remain analyzer work
    # so their fatal accounting is preserved.
    ordinary_components: list[str] = []
    for path in cache_candidates:
        ordinary_artifact = inventory_by_path.get(path)
        if path in raw_file_cache or (
            ordinary_artifact is not None
            and ordinary_artifact.get("disposition")
            in {ArtifactDisposition.FAILED, ArtifactDisposition.OUT_OF_SCOPE}
        ):
            ordinary_components.append(path)

    remaining_artifacts = max(0, MAX_DISCOVERED_ARTIFACTS - len(artifact_inventory))
    shared_remaining_artifacts = transitive_remaining_artifacts(state)
    if shared_remaining_artifacts is not None:
        remaining_artifacts = min(remaining_artifacts, max(0, shared_remaining_artifacts))
    remaining_bytes = max(
        0,
        MAX_TOTAL_CACHED_BYTES
        - cached_input_bytes
        - excluded_input_bytes,
    )
    shared_nested_bytes = transitive_remaining_bytes(state)
    if shared_nested_bytes is not None:
        remaining_bytes = min(remaining_bytes, max(0, shared_nested_bytes))
    shared_nested_seconds = transitive_remaining_seconds(state)
    nested_deadline = processing_deadline
    if shared_nested_seconds is not None:
        nested_deadline = min(
            nested_deadline,
            monotonic() + max(0.0, shared_nested_seconds),
        )
    nested_input_cache = {**raw_file_cache, **excluded_archive_cache}
    for path, tail in zip_tails.items():
        nested_input_cache[path] = raw_file_cache[path] + tail
    zip_tails.clear()
    nested = inspect_nested_artifacts(
        skill_dir,
        sorted(
            [
                *(path for path in ordinary_components if path in raw_file_cache),
                *excluded_archive_cache,
            ],
            # Expand real containers before another archive can claim their children.
            key=lambda path: -path.count("!/"),
        ),
        raw_file_cache=nested_input_cache,
        original_sizes={
            path: item["size_bytes"]
            for path, item in inventory_by_path.items()
            if path in raw_file_cache and item.get("size_bytes", 0) > len(nested_input_cache[path])
        },
        max_members=remaining_artifacts,
        max_uncompressed_bytes=remaining_bytes,
        absolute_deadline=nested_deadline,
        clock=monotonic,
    )
    del nested_input_cache
    unstarted_excluded_archives = [
        path for path in excluded_archive_cache if path not in nested.outer_metadata
    ]
    if unstarted_excluded_archives:
        halting_reasons = {
            LedgerReason.ARCHIVE_MEMBER_LIMIT,
            LedgerReason.ARCHIVE_SIZE_LIMIT,
            LedgerReason.ARCHIVE_TIME_LIMIT,
        }
        inherited_halt_reason = next(
            (
                reason
                for event in reversed(nested.ledger_events)
                if isinstance((reason := event.get("reason_code")), LedgerReason)
                and reason in halting_reasons
            ),
            LedgerReason.ARCHIVE_TIME_LIMIT,
        )
        for path in unstarted_excluded_archives:
            nested.inventory_overrides[path] = (
                ArtifactDisposition.PARTIAL,
                inherited_halt_reason.value,
            )
            nested.ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="nested_artifact_inspection",
                    path=path,
                    reason=inherited_halt_reason,
                )
            )
    traversal = transitive_traversal_state(state)
    record_bytes = getattr(traversal, "record_bytes", None)
    if callable(record_bytes):
        record_bytes(nested.uncompressed_bytes)
    if state is not None:
        transitive_record_artifacts(state, len(nested.artifact_inventory))
    nested_reasons = {event.get("reason_code") for event in nested.ledger_events}
    if shared_nested_bytes is not None and LedgerReason.ARCHIVE_SIZE_LIMIT in nested_reasons:
        transitive_note_truncation(state, "byte budget exhausted during nested inspection")
    if shared_nested_seconds is not None and LedgerReason.ARCHIVE_TIME_LIMIT in nested_reasons:
        transitive_note_truncation(state, "time budget exhausted during nested inspection")
    if (
        shared_remaining_artifacts is not None
        and LedgerReason.ARCHIVE_MEMBER_LIMIT in nested_reasons
    ):
        transitive_note_truncation(state, "artifact budget exhausted during nested inspection")

    excluded_nested_components: set[str] = set()
    excluded_nested_events: list[InspectionLedgerEvent] = []
    nested_inventory_by_path: dict[str, ArtifactRecord] = {
        item["path"]: item for item in nested.artifact_inventory
    }
    nested_metadata_by_path: dict[str, dict[str, object]] = {
        str(item.get("path", "")): item for item in nested.metadata if item.get("path")
    }
    excluded_archive_reasons = {path: excluded_artifacts[path] for path in excluded_archive_cache}
    excluded_inventory_by_path = {item["path"]: item for item in excluded_inventory}
    outer_by_nested_path = {path: path for path in excluded_archive_reasons}
    outer_by_nested_path.update(
        {
            str(row["path"]): str(row["outer_path"])
            for row in nested.metadata
            if str(row.get("outer_path", "")) in excluded_archive_reasons and row.get("path")
        }
    )

    def indexed_excluded_outer(path: str) -> str | None:
        """Resolve a virtual path through exact indexes under the bounded nesting depth."""
        candidate = path
        while candidate:
            outer_path = outer_by_nested_path.get(candidate)
            if outer_path is not None:
                return outer_path
            if "!/" not in candidate:
                return None
            candidate = candidate.rsplit("!/", 1)[0]
        return None

    def mark_excluded_nested_metadata(
        row: dict[str, object],
        *,
        outer_path: str,
        exclusion_reason: LedgerReason,
        incomplete: bool,
        limitation_reason: LedgerReason | None = None,
    ) -> None:
        path = str(row.get("path", outer_path))
        reasons = row.get("concealment_reasons", [])
        reason_list = [str(item) for item in reasons] if isinstance(reasons, list) else []
        row["concealment_reasons"] = list(dict.fromkeys([exclusion_reason.value, *reason_list]))
        row["excluded_from_analysis"] = True
        row["inherited_exclusion_reason"] = exclusion_reason.value
        if bool(row.get("executable")):
            row["concealed_executable"] = True
        if incomplete:
            row["excluded_inspection_incomplete"] = True
        if limitation_reason is not None:
            row["inspection_limitation_reason"] = limitation_reason.value
        excluded_nested_components.add(path)

    for nested_artifact in nested.artifact_inventory:
        outer_path = indexed_excluded_outer(nested_artifact["path"])
        if outer_path is None:
            continue
        nested_exclusion_reason = excluded_archive_reasons[outer_path]
        nested_artifact["inherited_exclusion_reason"] = nested_exclusion_reason.value
        if nested_artifact["disposition"] is ArtifactDisposition.ANALYZED or (
            nested_artifact.get("readable_binary") and not nested_artifact.get("reason")
        ):
            nested_artifact["disposition"] = ArtifactDisposition.OUT_OF_SCOPE
            nested_artifact["reason"] = nested_exclusion_reason.value
        elif nested_artifact["disposition"] is ArtifactDisposition.OUT_OF_SCOPE:
            nested_artifact.setdefault("reason", nested_exclusion_reason.value)

    for row in nested.metadata:
        outer_path = str(row.get("outer_path", ""))
        metadata_exclusion_reason = excluded_archive_reasons.get(outer_path)
        if metadata_exclusion_reason is None:
            continue
        nested_inventory_row = nested_inventory_by_path.get(str(row.get("path", "")))
        incomplete = nested_inventory_row is not None and nested_inventory_row.get(
            "disposition"
        ) in {
            ArtifactDisposition.PARTIAL,
            ArtifactDisposition.FAILED,
        }
        mark_excluded_nested_metadata(
            row,
            outer_path=outer_path,
            exclusion_reason=metadata_exclusion_reason,
            incomplete=incomplete,
        )
        if not bool(row.get("executable")):
            continue
        nested_path = str(row.get("path", ""))
        excluded_nested_events.extend(
            [
                ledger_event(
                    outcome=LedgerOutcome.OUT_OF_SCOPE,
                    record_type=LedgerRecordType.SCOPE_BOUNDARY,
                    phase="exclusion_audit",
                    path=nested_path,
                    reason=metadata_exclusion_reason,
                ),
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="exclusion_audit",
                    path=nested_path,
                    reason=LedgerReason.EXCLUDED_EXECUTABLE_CONTENT,
                ),
            ]
        )

    for event in nested.ledger_events:
        event_path = str(event.get("path", ""))
        outer_path = indexed_excluded_outer(event_path)
        if outer_path is None:
            continue
        event_exclusion_reason = excluded_archive_reasons[outer_path]
        nested_row = nested_metadata_by_path.get(event_path)
        if nested_row is None:
            outer_metadata = nested.outer_metadata.get(outer_path, {})
            container_type = str(outer_metadata.get("container_type", "zip"))
            outer_inventory = excluded_inventory_by_path.get(outer_path)
            nested_row = {
                "path": event_path,
                "type": container_type,
                "lines": 0,
                "executable": False,
                "size_bytes": int(outer_inventory.get("size_bytes", 0))
                if outer_inventory is not None
                else 0,
                "hidden": _is_hidden_component(event_path),
                "local_only": True,
                "outer_path": outer_path,
                "nested_path": (
                    event_path.removeprefix(f"{outer_path}!/")
                    if event_path != outer_path
                    else outer_path
                ),
                "container_type": container_type,
                "container_ancestry": outer_metadata.get("container_ancestry", [container_type]),
                "container_depth": event_path.count("!/") + 1,
                "outer_hidden": _is_hidden_component(outer_path),
                "concealed_executable": False,
                "concealment_reasons": [event_exclusion_reason.value],
            }
            nested.metadata.append(nested_row)
            nested_metadata_by_path[event_path] = nested_row
            outer_by_nested_path[event_path] = outer_path
        raw_limitation_reason = event.get("reason_code")
        limitation_reason = (
            raw_limitation_reason if isinstance(raw_limitation_reason, LedgerReason) else None
        )
        mark_excluded_nested_metadata(
            nested_row,
            outer_path=outer_path,
            exclusion_reason=event_exclusion_reason,
            incomplete=True,
            limitation_reason=limitation_reason,
        )

    # Only an actual collision is fatal: ordinary directories may end in "!".
    nested_paths = (
        {item["path"] for item in nested.artifact_inventory}
        | set(nested.components)
        | set(nested.file_cache)
        | set(nested.raw_file_cache)
    )
    reserved_paths = {item["path"] for item in artifact_inventory} & nested_paths
    member_containers = {
        str(item["path"]): str(item["outer_path"])
        for item in nested.metadata
        if item["path"] in reserved_paths and item.get("outer_path")
    }
    for path in sorted(reserved_paths):
        container = member_containers.get(path, path.rsplit("!/", 1)[0])
        event = ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase="nested_artifact_inspection",
            path=container,
            reason=LedgerReason.ARCHIVE_AMBIGUOUS_MEMBER_PATH,
        )
        event["message"] += (
            f" Archive member file {path!r} was not analyzed because it collides with a disk file."
            " Distinct descendant members may still be analyzed."
        )
        prework_events.append(event)
    disk_container_event_ids = {id(event) for event in nested.disk_container_events}
    for event in nested.ledger_events:
        path = event["path"]
        if path in reserved_paths:
            if id(event) in disk_container_event_ids:
                continue
            event["path"] = member_containers.get(path, path.rsplit("!/", 1)[0])
            event["work_id"] = inspection_work_id(
                f"{event['record_type'].value}:{event['phase']}", event["path"], None, None
            )
            event["message"] += (
                f" This applies to withheld archive member {path!r}, not the disk file."
            )
    for artifact in artifact_inventory:
        if artifact["path"] in reserved_paths:
            artifact["disposition"] = ArtifactDisposition.FAILED
            artifact["reason"] = LedgerReason.ARTIFACT_PATH_COLLISION.value
            prework_events.append(
                ledger_event(
                    outcome=LedgerOutcome.FAILED,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="discovery",
                    path=artifact["path"],
                    reason=LedgerReason.ARTIFACT_PATH_COLLISION,
                )
            )
    blocked_nested_paths = excluded_nested_components | reserved_paths
    nested.metadata = [item for item in nested.metadata if item["path"] not in reserved_paths]
    nested.python_source_classifications = {
        path: classification
        for path, classification in nested.python_source_classifications.items()
        if path not in blocked_nested_paths
    }
    ordinary_nested_components = [
        path for path in nested.components if path not in blocked_nested_paths
    ]
    local_file_cache = dict(ordinary_file_cache)
    local_file_cache.update(
        {path: data for path, data in nested.file_cache.items() if path not in blocked_nested_paths}
    )
    raw_file_cache.update(
        {
            path: data
            for path, data in nested.raw_file_cache.items()
            if path not in blocked_nested_paths
        }
    )
    artifact_inventory.extend(
        item for item in nested.artifact_inventory if item["path"] not in reserved_paths
    )
    for artifact in artifact_inventory:
        override = nested.inventory_overrides.get(artifact["path"])
        if override is not None and artifact["disposition"] != ArtifactDisposition.FAILED:
            artifact["disposition"], artifact["reason"] = override
        if artifact["path"] in nested.inspected_containers:
            artifact["inspected_members"] = nested.inspected_containers[artifact["path"]]
            if artifact["disposition"] is ArtifactDisposition.OUT_OF_SCOPE and not artifact.get(
                "reason"
            ):
                artifact["disposition"] = ArtifactDisposition.ANALYZED
    inventory_by_path = {item["path"]: item for item in artifact_inventory}

    recognized_containers = frozenset(nested.outer_metadata)
    content_interpretation_events: list[InspectionLedgerEvent] = []
    selected_primary = state.get("primary_file_path")
    for artifact in artifact_inventory:
        path = artifact["path"]
        # A skill entry point retains its role below directory and virtual ZIP
        # boundaries (e.g. bundle.dat!/pkg/SKILL.md). Renaming a supported ZIP
        # must not turn its required instructions into a passive binary asset.
        required = path == selected_primary or path.rsplit("/", 1)[-1] in {
            "SKILL.md",
            "skill.md",
        }
        if not required or path in nested.recognized_container_paths:
            continue
        data = raw_file_cache.get(path)
        if data is None or not _unsupported_primary_bytes(
            artifact,
            data,
            python_classification=nested.python_source_classifications.get(path),
            deadline=processing_deadline,
        ):
            continue
        # Explicit input and primary instructions cannot be passive exclusions.
        # Keep canonical bytes for byte-based analysis and source attribution,
        # while making the missing interpretation fatal to a SAFE verdict.
        artifact["content_kind"] = ContentKind.OPAQUE
        artifact["disposition"] = ArtifactDisposition.FAILED
        artifact["reason"] = LedgerReason.UNSUPPORTED_PRIMARY_CONTENT.value
        llm_file_cache.pop(path, None)
        content_interpretation_events.append(
            ledger_event(
                outcome=LedgerOutcome.FAILED,
                record_type=LedgerRecordType.SYSTEM,
                phase="cache",
                path=path,
                reason=LedgerReason.UNSUPPORTED_PRIMARY_CONTENT,
            )
        )
        if path == primary_path:
            reference_resolution["complete"] = False
            reference_resolution["limitations"] = [
                *cast(list[str], reference_resolution.get("limitations", [])),
                LedgerReason.UNSUPPORTED_PRIMARY_CONTENT.value,
            ]
    components = sorted(
        dict.fromkeys(
            [
                *ordinary_components,
                *ordinary_nested_components,
            ]
        )
    )
    for path in recognized_containers:
        llm_file_cache.pop(path, None)

    postprocessing_events: list[InspectionLedgerEvent] = []
    runtime_limit = max(0.0, processing_deadline - processing_started)

    def _mark_runtime_partial(affected_paths: list[str], first_limited_path: str) -> None:
        limited = False
        for affected_path in affected_paths:
            if affected_path == first_limited_path:
                limited = True
            if not limited:
                continue
            affected_artifact = inventory_by_path.get(affected_path)
            if (
                affected_artifact is None
                or affected_artifact.get("disposition") == ArtifactDisposition.FAILED
            ):
                continue
            if affected_artifact.get("disposition") != ArtifactDisposition.PARTIAL:
                affected_artifact["reason"] = LedgerReason.RUNTIME_LIMIT.value
            affected_artifact["disposition"] = ArtifactDisposition.PARTIAL

    classification_events: list[InspectionLedgerEvent] = []
    source_classifications = dict(nested.python_source_classifications)
    completed_source_classifications: set[str] = set()
    source_decode_failures: dict[str, str] = {}
    nested_metadata_by_path = {
        str(metadata.get("path", "")): metadata for metadata in nested.metadata
    }
    classification_runtime_limitation: tuple[str, float] | None = None
    for path in components:
        now = monotonic()
        if now >= processing_deadline:
            classification_runtime_limitation = (
                path,
                max(0.0, now - processing_started),
            )
            break
        content = local_file_cache.get(path)
        raw_content = raw_file_cache.get(path)
        source_classification = source_classifications.get(path)
        if source_classification is None:
            source_classification = classify_python_source(
                path,
                raw_content if raw_content is not None else content,
            )
            source_classifications[path] = source_classification
        if (
            source_classification is not PythonSourceClassification.NON_PYTHON
            and raw_content is not None
        ):
            try:
                decoded_python = decode_python_source(raw_content)
            except Exception as exc:
                source_decode_failures[path] = LedgerReason.PYTHON_SOURCE_DECODE_ERROR.value
                classified_artifact = inventory_by_path.get(path)
                if (
                    classified_artifact is not None
                    and classified_artifact.get("disposition") != ArtifactDisposition.FAILED
                ):
                    if (
                        classified_artifact.get("disposition") != ArtifactDisposition.PARTIAL
                        or "reason" not in classified_artifact
                    ):
                        classified_artifact["reason"] = (
                            LedgerReason.PYTHON_SOURCE_DECODE_ERROR.value
                        )
                    classified_artifact["disposition"] = ArtifactDisposition.PARTIAL
                local_file_cache.pop(path, None)
                llm_file_cache.pop(path, None)
                classification_events.append(
                    ledger_event(
                        outcome=LedgerOutcome.PARTIAL,
                        record_type=LedgerRecordType.SYSTEM,
                        phase="python_source_decoding",
                        path=path,
                        reason=LedgerReason.PYTHON_SOURCE_DECODE_ERROR,
                        error_class=type(exc).__name__,
                    )
                )
            else:
                local_file_cache[path] = decoded_python
                nested_metadata = nested_metadata_by_path.get(path)
                if nested_metadata is not None:
                    nested_metadata["lines"] = len(decoded_python.splitlines())
                classified_artifact = inventory_by_path.get(path)
                if classified_artifact is not None:
                    promote_artifact_to_decoded_text(classified_artifact)
                    disposition = classified_artifact.get("disposition")
                    artifact_reason = classified_artifact.get("reason")
                    bounded_provider_view = (
                        disposition == ArtifactDisposition.PARTIAL
                        and artifact_reason
                        in {
                            LedgerReason.SIZE_LIMIT.value,
                            LedgerReason.TOTAL_BYTES_LIMIT.value,
                        }
                    )
                    if not source_local_only and (
                        path in llm_file_cache
                        or (
                            path not in nested.file_cache
                            and path not in recognized_containers
                            and not _is_hidden_path(path)
                            and (
                                disposition == ArtifactDisposition.ANALYZED or bounded_provider_view
                            )
                        )
                    ):
                        provider_content = decoded_python
                        if bounded_provider_view:
                            provider_content = _llm_view_of_truncated_file(
                                decoded_python,
                                total_size=max(
                                    len(raw_content),
                                    int(classified_artifact.get("size_bytes", 0)),
                                ),
                                read_bytes=len(raw_content),
                            )
                        llm_file_cache[path] = _redact_for_external_model(
                            path,
                            provider_content,
                        )
        completed_source_classifications.add(path)
        now = monotonic()
        if now >= processing_deadline:
            classification_runtime_limitation = (
                path,
                max(0.0, now - processing_started),
            )
            break
        if source_classification is PythonSourceClassification.AMBIGUOUS:
            classified_artifact = inventory_by_path.get(path)
            if classified_artifact is not None and classified_artifact.get("disposition") not in {
                ArtifactDisposition.FAILED,
                ArtifactDisposition.OUT_OF_SCOPE,
            }:
                if classified_artifact.get("disposition") != ArtifactDisposition.PARTIAL:
                    classified_artifact["reason"] = LedgerReason.PYTHON_SOURCE_AMBIGUOUS.value
                classified_artifact["disposition"] = ArtifactDisposition.PARTIAL
            classification_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="python_source_classification",
                    path=path,
                    reason=LedgerReason.PYTHON_SOURCE_AMBIGUOUS,
                )
            )
    source_classification_limitations = {
        path: LedgerReason.RUNTIME_LIMIT.value
        for path in components
        if path not in completed_source_classifications
    }
    for path in source_classification_limitations:
        local_file_cache.pop(path, None)
        llm_file_cache.pop(path, None)
    if classification_runtime_limitation is not None:
        path, elapsed = classification_runtime_limitation
        _mark_runtime_partial(components, path)
        classification_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="python_source_classification",
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=elapsed,
                limit_seconds=runtime_limit,
            )
        )

    # Python's successful source decode takes precedence over a magic prefix.
    for artifact in artifact_inventory:
        path = artifact["path"]
        if (
            not artifact.get("readable_binary")
            or artifact["content_kind"] != ContentKind.BINARY
            or path in excluded_nested_components
        ):
            continue
        _, projection_truncated = binary_instruction_view(local_file_cache.get(path, ""))
        partial = bool(artifact.get("referenced"))
        reason = LedgerReason.SIZE_LIMIT if projection_truncated else LedgerReason.OPAQUE_CONTENT
        if artifact["disposition"] == ArtifactDisposition.ANALYZED:
            artifact["disposition"] = (
                ArtifactDisposition.PARTIAL if partial else ArtifactDisposition.OUT_OF_SCOPE
            )
        content_interpretation_events.append(
            ledger_event(
                outcome=LedgerOutcome.OUT_OF_SCOPE,
                record_type=LedgerRecordType.SCOPE_BOUNDARY,
                phase="cache",
                path=path,
                reason=LedgerReason.BINARY_TEXT_PROJECTION,
            )
        )
        if partial:
            content_interpretation_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="cache",
                    path=path,
                    reason=reason,
                )
            )

    for path, content in local_file_cache.items():
        if not content.lstrip().startswith("{"):
            continue
        projection_started = monotonic()
        if projection_started >= processing_deadline:
            _record_processing_runtime(
                phase="signature_projection", path=path, now=projection_started
            )
            continue
        projection = project_oms_content(content)
        if projection is None:
            continue
        projection_finished = monotonic()
        if projection_finished >= processing_deadline:
            _record_processing_runtime(
                phase="signature_projection", path=path, now=projection_finished
            )
            continue
        artifact = inventory_by_path.get(path)
        bounded_provider_view = artifact is not None and (
            artifact.get("disposition") == ArtifactDisposition.PARTIAL
            and artifact.get("reason")
            in {LedgerReason.SIZE_LIMIT.value, LedgerReason.TOTAL_BYTES_LIMIT.value}
        )
        if path in llm_file_cache and projection.view.name != "raw" and not bounded_provider_view:
            llm_file_cache[path] = projection.view.text
        if not projection.complete:
            signature_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="discovery",
                    path=path,
                    reason=LedgerReason.OMS_SIGNATURE,
                )
            )
            if artifact is not None and artifact["disposition"] == ArtifactDisposition.ANALYZED:
                artifact["disposition"] = ArtifactDisposition.PARTIAL
                artifact["reason"] = LedgerReason.OMS_SIGNATURE.value

    llm_components = sorted(llm_file_cache)
    file_cache = dict(llm_file_cache)
    manifest_events: list[InspectionLedgerEvent] = []
    manifest, manifest_version_source = _parse_manifest(
        skill_dir,
        raw_file_cache=raw_file_cache,
        ledger_events=manifest_events,
        clock=monotonic,
        deadline=processing_deadline,
    )
    if manifest_events and primary_path is not None:
        manifest_reason = manifest_events[-1].get("reason_code", LedgerReason.MANIFEST_PARSE_LIMIT)
        for artifact in artifact_inventory:
            if artifact["path"] == primary_path:
                # Manifest interpretation cannot downgrade a byte/read failure.
                # Inventory must retain fatality even if ledger details are capped.
                if artifact["disposition"] == ArtifactDisposition.FAILED:
                    break
                artifact["disposition"] = ArtifactDisposition.PARTIAL
                artifact["reason"] = (
                    manifest_reason.value
                    if isinstance(manifest_reason, LedgerReason)
                    else str(manifest_reason)
                )
                break

    structured_candidates = sorted(dict.fromkeys([*cache_candidates, *ordinary_nested_components]))
    structured = extract_structured_skill_context_from_cache(
        skill_dir,
        structured_candidates,
        raw_file_cache=raw_file_cache,
        file_cache=local_file_cache,
        clock=monotonic,
        deadline=processing_deadline,
    )
    structured_events: list[InspectionLedgerEvent] = []
    for structured_limitation in structured.limitations:
        reason = LedgerReason(structured_limitation.reason_code)
        affected_paths = {structured_limitation.path}
        if structured_limitation.resource == "structured_candidates":
            affected_paths.update(
                path for path in structured_candidates if path.lower().endswith(".aisop.json")
            )
        elif structured_limitation.resource in {
            "structured_total_input_bytes",
            "structured_nesting",
            "structured_nodes",
            "structured_output_records",
        }:
            affected_paths.update(
                path
                for path in structured_candidates
                if path >= structured_limitation.path and path.lower().endswith(".aisop.json")
            )
        for path in affected_paths:
            structured_artifact = inventory_by_path.get(path)
            if (
                structured_artifact is None
                or structured_artifact.get("disposition") == ArtifactDisposition.FAILED
            ):
                continue
            if structured_artifact.get("disposition") != ArtifactDisposition.PARTIAL:
                structured_artifact["reason"] = reason.value
            structured_artifact["disposition"] = ArtifactDisposition.PARTIAL
        structured_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="structured_skill",
                path=structured_limitation.path,
                reason=reason,
                observed_bytes=structured_limitation.observed_bytes,
                limit_bytes=structured_limitation.limit_bytes,
                observed_artifacts=structured_limitation.observed_artifacts,
                limit_artifacts=structured_limitation.limit_artifacts,
                observed_depth=structured_limitation.observed_depth,
                limit_depth=structured_limitation.limit_depth,
                observed_records=structured_limitation.observed_records,
                limit_records=structured_limitation.limit_records,
                observed_seconds=structured_limitation.observed_seconds,
                limit_seconds=structured_limitation.limit_seconds,
            )
        )

    python_components = [
        component
        for component in components
        if component in local_file_cache
        and source_classifications.get(component, PythonSourceClassification.AMBIGUOUS)
        is not PythonSourceClassification.NON_PYTHON
    ]
    python_component_set = set(python_components)
    ast_runtime_limitations: list[tuple[str, float]] = []
    if classification_runtime_limitation is not None:
        python_ast_cache_key = None
        ast_runtime_limitations.append(classification_runtime_limitation)
    else:
        python_ast_cache_key = prewarm_python_ast_cache(
            python_components,
            local_file_cache,
            raw_file_cache=raw_file_cache,
            source_classifications=source_classifications,
            clock=monotonic,
            started_at=processing_started,
            deadline=processing_deadline,
            runtime_limitations=ast_runtime_limitations,
        )
    if ast_runtime_limitations:
        path, elapsed = ast_runtime_limitations[0]
        limited_index = components.index(path)
        affected_python_components = [
            component
            for component in components[limited_index:]
            if component in python_component_set
        ]
        if affected_python_components:
            _mark_runtime_partial(affected_python_components, affected_python_components[0])
        postprocessing_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="python_ast_prewarm",
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=elapsed,
                limit_seconds=runtime_limit,
            )
        )
    metadata_components = [
        path for path in inventoried_components if path not in selected_baselines
    ]
    metadata_runtime_limitations: list[tuple[str, float]] = []
    component_metadata, has_executable_scripts = _build_component_metadata(
        skill_dir,
        metadata_components,
        local_file_cache,
        raw_file_cache,
        recognized_oms_signatures,
        source_classifications=source_classifications,
        clock=monotonic,
        started_at=processing_started,
        deadline=processing_deadline,
        runtime_limitations=metadata_runtime_limitations,
        source_local_only=source_local_only,
    )
    if metadata_runtime_limitations:
        path, elapsed = metadata_runtime_limitations[0]
        _mark_runtime_partial(metadata_components, path)
        postprocessing_events.append(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="component_metadata",
                path=path,
                reason=LedgerReason.RUNTIME_LIMIT,
                observed_seconds=elapsed,
                limit_seconds=runtime_limit,
            )
        )
    for metadata in component_metadata:
        path = str(metadata.get("path", ""))
        if path in nested.outer_metadata:
            metadata.update(nested.outer_metadata[path])
            metadata["lines"] = 0
    component_metadata.extend(nested.metadata)
    component_metadata.extend(excluded_component_metadata)
    if source_local_only:
        for metadata in component_metadata:
            metadata["local_only"] = True
            metadata["hidden_ancestor"] = True
            metadata["source_local_only"] = True
    coverage_policy_events = _mark_unanalyzed_executables(
        component_metadata,
        {item["path"]: item for item in artifact_inventory},
        raw_file_cache,
    )
    use_llm = state.get("use_llm", True)
    hidden_skill_llm_events = (
        _note_hidden_skill_scripts_not_sent_to_llm(component_metadata)
        if use_llm is not False
        else []
    )
    has_executable_scripts = (
        has_executable_scripts
        or any(bool(metadata.get("executable")) for metadata in nested.metadata)
        or any(bool(metadata.get("executable")) for metadata in excluded_component_metadata)
    )

    # Post-cache classification, AST prewarm, and metadata work can still
    # downgrade inventory rows.  Project those final dispositions only after
    # every mutation so reference coverage cannot remain falsely complete.
    disposition_by_path = {item["path"]: item["disposition"] for item in artifact_inventory}
    for reference in references:
        target = reference["target_path"]
        if target and target in disposition_by_path:
            reference["disposition"] = disposition_by_path[target]

    remaining_seconds = transitive_remaining_seconds(state)
    if use_llm and remaining_seconds is not None and remaining_seconds > 0:
        try:
            prepare_chat_model_imports()
        except Exception as exc:
            # Optional eager imports must preserve normal provider failure handling.
            logger.debug("Could not prepare AI transport imports (%s)", type(exc).__name__)
        remaining_seconds = transitive_remaining_seconds(state)
        if remaining_seconds is not None and remaining_seconds <= 0:
            logger.debug("Workflow deadline reached while preparing AI transport imports")
    model_config = build_model_config() if use_llm else {}
    llm_provenance = (
        capture_llm_provenance(model_config)
        if use_llm
        else capture_static_llm_provenance(MODEL_CONFIG)
    )
    result: dict[str, object] = {
        "components": components,
        "llm_components": llm_components,
        "file_cache": file_cache,
        "local_file_cache": local_file_cache,
        "raw_file_cache": raw_file_cache,
        "python_source_classifications": {
            path: classification.value for path, classification in source_classifications.items()
        },
        "python_source_classification_limitations": source_classification_limitations,
        "python_source_decode_failures": source_decode_failures,
        "llm_file_cache": llm_file_cache,
        "source_local_only": source_local_only,
        "artifact_inventory": artifact_inventory,
        "artifact_references": references,
        "reference_resolution": reference_resolution,
        "inspection_ledger": _bounded_ledger_output(
            [
                *discovery_events,
                *user_exclusion_events,
                *prework_events,
                *signature_events,
                *baseline_events,
                *exclusion_audit_events,
                *reference_events,
                *cache_events,
                *nested.ledger_events,
                *content_interpretation_events,
                *excluded_nested_events,
                *classification_events,
                *manifest_events,
                *structured_events,
                *postprocessing_events,
                *coverage_policy_events,
                *hidden_skill_llm_events,
            ]
        ),
        "ast_cache": {},
        "python_ast_cache_key": python_ast_cache_key,
        "manifest": manifest,
        "manifest_version_source": manifest_version_source,
        "previous_manifest": None,
        "model_config": model_config,
        "llm_provenance": llm_provenance,
        "component_metadata": component_metadata,
        "has_executable_scripts": has_executable_scripts,
        "workflow_resource_budget": workflow_budget,
    }

    if structured.context is not None:
        result["structured_skill_context"] = structured.context

    return result
