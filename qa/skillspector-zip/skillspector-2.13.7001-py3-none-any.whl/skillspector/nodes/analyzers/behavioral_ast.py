# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Behavioral AST analyzer: detect dangerous execution patterns in Python code."""

from __future__ import annotations

import ast
import time
from collections.abc import Callable
from dataclasses import dataclass, field

from skillspector.inspection_ledger import (
    InspectionLedgerEvent,
    LedgerOutcome,
    LedgerReason,
    analyzer_status_event,
    analyzer_status_for_events,
    ledger_event,
)
from skillspector.logging_config import get_logger
from skillspector.models import AnalyzerFinding, Finding, Location, Severity
from skillspector.python_ast import (
    ParsedPythonFile,
    PythonSourceClassification,
    get_python_ast,
    resolve_python_source_classification,
)
from skillspector.state import (
    AnalyzerNodeResponse,
    SkillspectorState,
    transitive_remaining_seconds,
)

from .canonical_sink import (
    canonical_sibling_method,
    canonical_sibling_sink,
    resolve_to_canonical_sink,
)
from .common import (
    build_type_map,
    get_complete_source_segment,
    get_context_from_lines,
    resolve_call_name,
    resolve_dynamic_import_call,
)
from .static_runner import (
    MAX_FILE_CHARS,
    MAX_FINDINGS_PER_ANALYZER,
    MAX_FINDINGS_PER_ARTIFACT,
    analyzer_finding_to_finding,
)

ANALYZER_ID = "behavioral_ast"
logger = get_logger(__name__)

_DANGEROUS_BUILTINS = frozenset({"exec", "eval", "compile", "__import__"})

# Names that turn ``getattr(obj, "<name>")`` into a reflective handle on a code- or
# command-execution sink. ``getattr(os, "system")(cmd)`` and
# ``getattr(builtins, "exec")(src)`` are functionally identical to ``os.system(cmd)``
# / ``exec(src)`` but evade AST1/AST5: the inner ``getattr`` has a *constant* second
# argument (so AST7 is intentionally skipped), and the outer call's ``func`` is an
# ``ast.Call`` whose name does not resolve, so AST1/AST5 never fire. The set is kept
# deliberately small — only names with essentially no legitimate ``getattr`` use — so
# benign reflection such as ``getattr(obj, "name")`` stays unflagged.
_DANGEROUS_GETATTR_NAMES = frozenset({"exec", "eval", "system", "popen", "__import__"})

# dict methods that can retrieve an existing key's value exactly like a subscript
# does. All three take the key as their first positional argument and, for any
# key that already exists (every name in _DANGEROUS_GETATTR_NAMES always does,
# on the module that defines it), return that same object: ``.get(key)`` reads
# without mutating; ``.setdefault(key)`` reads without mutating *because* the
# key is already present (the "set" branch never triggers); ``.pop(key)`` reads
# and additionally removes the entry, which is irrelevant to whether the read
# itself must be caught. Each is a further spelling of the same reflective
# access the subscript form catches, so all three get identical treatment.
_REFLECTIVE_DICT_READ_METHODS = frozenset({"get", "setdefault", "pop"})


# Longest dangerous getattr name. The only consumer of `_constant_string`
# compares the resolved value against `_DANGEROUS_GETATTR_NAMES`, so a resolved
# value longer than this can never match. Capping the prospective join length
# (computed before allocating) keeps an adversarial literal from expanding into
# a memory-exhausting payload on untrusted skill source: the source-size gate
# does not bound the expanded join value. Exceeding the cap returns unresolved
# so the caller falls back to the existing AST7 dynamic-name treatment.
_MAX_RESOLVED_GETATTR_NAME_LEN = max(len(name) for name in _DANGEROUS_GETATTR_NAMES)


def _constant_string(node: ast.expr) -> str | None:
    """Resolve a deliberately small safe subset of constant string expressions."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "join"
        and isinstance(node.func.value, ast.Constant)
        and isinstance(node.func.value.value, str)
        and len(node.args) == 1
        and isinstance(node.args[0], (ast.List, ast.Tuple))
    ):
        parts = [_constant_string(item) for item in node.args[0].elts]
        if all(part is not None for part in parts):
            separator = node.func.value.value
            # Bound the prospective output before allocating it. Nested joins
            # are already bounded because the recursive call above returns None
            # for any over-cap operand, which fails the `all()` check here.
            prospective = sum(len(part) for part in parts) + len(separator) * max(len(parts) - 1, 0)
            if prospective <= _MAX_RESOLVED_GETATTR_NAME_LEN:
                return separator.join(parts)
    return None


_SUBPROCESS_CALLS = frozenset(
    {
        "call",
        "run",
        "Popen",
        "check_output",
        "check_call",
        "getoutput",
        "getstatusoutput",
    }
)

_OS_EXEC_CALLS = frozenset(
    {
        "system",
        "popen",
        "execl",
        "execle",
        "execlp",
        "execlpe",
        "execv",
        "execve",
        "execvp",
        "execvpe",
        "spawnl",
        "spawnle",
        "spawnlp",
        "spawnlpe",
        "spawnv",
        "spawnve",
        "spawnvp",
        "spawnvpe",
        "posix_spawn",
        "posix_spawnp",
    }
)

# Deserializers that reconstruct arbitrary objects (or execute code) from their
# input, regardless of arguments. Feeding attacker-controlled bytes to any of
# these is equivalent to code execution: pickle invokes ``__reduce__`` during
# unpickling, ``yaml.unsafe_load`` constructs arbitrary Python objects, etc.
# ``yaml.load``/``torch.load``/``numpy.load`` are handled separately because
# their safety depends on arguments (see ``_deserialization_message``).
_DESERIALIZATION_SINKS = frozenset(
    {
        "pickle.load",
        "pickle.loads",
        "cPickle.load",
        "cPickle.loads",
        "_pickle.load",
        "_pickle.loads",
        "marshal.load",
        "marshal.loads",
        "dill.load",
        "dill.loads",
        "jsonpickle.decode",
        "pandas.read_pickle",
        "joblib.load",
        "yaml.unsafe_load",
    }
)

# Loader classes that make ``yaml.load`` safe (no arbitrary object construction).
_SAFE_YAML_LOADERS = frozenset({"SafeLoader", "CSafeLoader", "BaseLoader"})

_RULE_MESSAGES: dict[str, str] = {
    "AST1": "exec() call detected",
    "AST2": "eval() call detected",
    "AST3": "Dynamic import via __import__()",
    "AST4": "subprocess module call",
    "AST5": "os.system() or os exec-family call",
    "AST6": "compile() call detected",
    "AST7": "Dynamic attribute access via getattr()",
    "AST8": "Dangerous execution chain",
    "AST9": "Reflective dangerous call via getattr() with a literal sink name",
    "AST10": "Insecure deserialization of untrusted data",
}

_RULE_SEVERITIES: dict[str, Severity] = {
    "AST1": Severity.HIGH,
    "AST2": Severity.HIGH,
    "AST3": Severity.MEDIUM,
    "AST4": Severity.MEDIUM,
    "AST5": Severity.HIGH,
    "AST6": Severity.MEDIUM,
    "AST7": Severity.LOW,
    "AST8": Severity.CRITICAL,
    "AST9": Severity.HIGH,
    "AST10": Severity.MEDIUM,
}

_RULE_CONFIDENCES: dict[str, float] = {
    "AST1": 0.85,
    "AST2": 0.85,
    "AST3": 0.75,
    "AST4": 0.70,
    "AST5": 0.85,
    "AST6": 0.65,
    "AST7": 0.50,
    "AST8": 0.95,
    "AST9": 0.85,
    "AST10": 0.70,
}

_TAG = "Dangerous Code Execution"


class _BehavioralResourceLimitError(RuntimeError):
    """Internal signal that retains findings constructed before a hard limit."""

    def __init__(self, reason: LedgerReason, metrics: dict[str, int | float]) -> None:
        super().__init__(reason.value)
        self.reason = reason
        self.metrics = metrics


@dataclass
class _BehavioralBudget:
    """Bound AST work while findings are being constructed, not after return."""

    state: SkillspectorState
    started_at: float = field(default_factory=time.monotonic)
    initial_allowance: float | None = None
    total_findings: int = 0
    current_findings: list[AnalyzerFinding] = field(default_factory=list)

    def begin_artifact(self) -> None:
        self.current_findings = []
        self.check_runtime()

    def check_runtime(self) -> None:
        remaining = transitive_remaining_seconds(self.state)
        if remaining is None:
            return
        if self.initial_allowance is None:
            self.initial_allowance = max(0.0, remaining)
        if remaining <= 0:
            raise _BehavioralResourceLimitError(
                LedgerReason.RUNTIME_LIMIT,
                {
                    "observed_seconds": max(0.0, time.monotonic() - self.started_at),
                    "limit_seconds": self.initial_allowance,
                },
            )

    def emit(self, finding: AnalyzerFinding) -> None:
        self.check_runtime()
        artifact_observed = len(self.current_findings) + 1
        analyzer_observed = self.total_findings + 1
        if artifact_observed > MAX_FINDINGS_PER_ARTIFACT:
            raise _BehavioralResourceLimitError(
                LedgerReason.OUTPUT_LIMIT,
                {
                    "observed_findings": artifact_observed,
                    "limit_findings": MAX_FINDINGS_PER_ARTIFACT,
                },
            )
        if analyzer_observed > MAX_FINDINGS_PER_ANALYZER:
            raise _BehavioralResourceLimitError(
                LedgerReason.OUTPUT_LIMIT,
                {
                    "observed_findings": analyzer_observed,
                    "limit_findings": MAX_FINDINGS_PER_ANALYZER,
                },
            )
        self.current_findings.append(finding)
        self.total_findings = analyzer_observed

    def analyzer_exhausted(self) -> bool:
        return self.total_findings >= MAX_FINDINGS_PER_ANALYZER


def _is_chain_sink(node: ast.Call, aliases: dict[str, str] | None = None) -> bool:
    """True if this call is exec(), eval(), or compile() — the outer dangerous call."""
    name = resolve_call_name(node, aliases)
    return name in ("exec", "eval", "compile")


def _contains_dangerous_source(
    node: ast.AST,
    aliases: dict[str, str] | None = None,
    check_runtime: Callable[[], None] | None = None,
) -> str | None:
    """Walk children to find a nested dangerous call that forms a chain."""
    for child in ast.walk(node):
        if check_runtime is not None:
            check_runtime()
        if not isinstance(child, ast.Call):
            continue
        name = resolve_call_name(child, aliases)
        if name is None:
            continue
        if name in ("compile", "__import__"):
            return name
        if name.startswith("subprocess.") or name.startswith("os."):
            return name
        if any(
            part in name for part in ("base64", "codecs", "marshal", "urllib", "requests", "httpx")
        ):
            return name
    return None


def _loader_arg_name(node: ast.expr) -> str | None:
    """Return the trailing name of a yaml ``Loader`` argument (``yaml.SafeLoader`` → 'SafeLoader')."""
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    return None


def _is_true_constant(node: ast.expr) -> bool:
    """True if *node* is the literal ``True``."""
    return isinstance(node, ast.Constant) and node.value is True


def _kwarg_is_true(node: ast.Call, name: str) -> bool:
    """True if keyword *name* is passed as a literal ``True``."""
    return any(kw.arg == name and _is_true_constant(kw.value) for kw in node.keywords)


def _deserialization_message(call_name: str, node: ast.Call) -> str | None:
    """Return an AST10 message if *node* is an unsafe deserialization call, else None.

    ``_DESERIALIZATION_SINKS`` are unconditionally unsafe. ``yaml.load``, ``torch.load``,
    and ``numpy.load`` are argument-dependent: an explicit safe ``Loader``,
    ``weights_only=True``, or the default ``allow_pickle=False`` respectively make them
    safe and must not be flagged (avoids false positives on the hardened forms).
    """
    if call_name in _DESERIALIZATION_SINKS:
        return f"Insecure deserialization: {call_name}()"
    if call_name == "yaml.load":
        for kw in node.keywords:
            if kw.arg == "Loader":
                if _loader_arg_name(kw.value) in _SAFE_YAML_LOADERS:
                    return None
                return "Insecure deserialization: yaml.load() with an unsafe Loader"
        if len(node.args) >= 2 and _loader_arg_name(node.args[1]) in _SAFE_YAML_LOADERS:
            return None
        return "Insecure deserialization: yaml.load() without SafeLoader"
    if call_name == "torch.load":
        return (
            None
            if _kwarg_is_true(node, "weights_only")
            else ("Insecure deserialization: torch.load() without weights_only=True")
        )
    if call_name == "numpy.load":
        # ``allow_pickle`` is the third positional parameter (file, mmap_mode,
        # allow_pickle, ...), so ``numpy.load(f, None, True)`` enables pickle
        # loading without ever naming the keyword.
        if _kwarg_is_true(node, "allow_pickle") or (
            len(node.args) >= 3 and _is_true_constant(node.args[2])
        ):
            return "Insecure deserialization: numpy.load(allow_pickle=True)"
        return None
    return None


def _reflective_module_dict_container(container: ast.expr, aliases: dict[str, str]) -> str | None:
    """Return the module name when *container* is an imported module's namespace.

    Matches ``<module>.__dict__`` and ``vars(<module>)`` as a bare expression, so
    callers can apply this to either a subscript target (``container[key]``) or a
    ``.get(key)`` receiver (``container.get(key)``) — both read the module
    namespace by key, so both must get the same treatment as ``getattr(module,
    key)``. The base must resolve through the import-alias map to a plain
    (non-dotted) module (``import os`` / ``import os as o``), which keeps
    idiomatic instance attribute bags (``self.__dict__[...]``) and from-imported
    classes out of scope.
    """
    base: ast.expr
    if isinstance(container, ast.Attribute) and container.attr == "__dict__":
        base = container.value
    elif (
        isinstance(container, ast.Call)
        and isinstance(container.func, ast.Name)
        and container.func.id == "vars"
        and len(container.args) == 1
    ):
        base = container.args[0]
    else:
        return None
    if not isinstance(base, ast.Name):
        return None
    resolved = aliases.get(base.id)
    if resolved is None or "." in resolved:
        return None
    return resolved


def _reflective_module_dict_base(node: ast.Subscript, aliases: dict[str, str]) -> str | None:
    """Return the module name when *node* subscripts an imported module's namespace.

    See :func:`_reflective_module_dict_container` — this is the subscript
    (``<module>.__dict__[key]`` / ``vars(<module>)[key]``) entry point.
    """
    return _reflective_module_dict_container(node.value, aliases)


def _covered_by_ast9(node: ast.Call, aliases: dict[str, str]) -> bool:
    """True when the callee of *node* is a reflective read that AST9 already reports.

    AST9 fires on the reflective *read* of an allowlisted name
    (:data:`_DANGEROUS_GETATTR_NAMES`) in three spellings: ``getattr(obj, "<name>")``
    (including constant-joined names), ``<module>.__dict__["<name>"]`` /
    ``vars(<module>)["<name>"]``, and the ``.get`` / ``.setdefault`` / ``.pop`` reads of
    the same namespaces. When *node* invokes one of those reads, the canonical-sink
    fallback must stay silent so one expression yields one sink finding; it then owns
    only the spellings AST9 does not report (``__builtins__["exec"]``, an un-imported
    ``vars(builtins)``, and getattr targets outside the allowlist such as
    ``getattr(subprocess, "Popen")``).
    """
    callee = node.func
    if isinstance(callee, ast.Subscript):
        if _reflective_module_dict_base(callee, aliases) is None:
            return False
        key = callee.slice
        return isinstance(key, ast.Constant) and key.value in _DANGEROUS_GETATTR_NAMES
    if not (isinstance(callee, ast.Call) and len(callee.args) >= 1):
        return False
    if isinstance(callee.func, ast.Name) and callee.func.id == "getattr":
        return len(callee.args) >= 2 and (
            _constant_string(callee.args[1]) in _DANGEROUS_GETATTR_NAMES
        )
    if (
        isinstance(callee.func, ast.Attribute)
        and callee.func.attr in _REFLECTIVE_DICT_READ_METHODS
        and _reflective_module_dict_container(callee.func.value, aliases) is not None
    ):
        key = callee.args[0]
        return isinstance(key, ast.Constant) and key.value in _DANGEROUS_GETATTR_NAMES
    return False


def _analyze_python(
    python_ast: ParsedPythonFile,
    file_path: str,
    budget: _BehavioralBudget | None = None,
) -> list[AnalyzerFinding]:
    tree = python_ast.tree
    if tree is None:
        return []

    aliases = python_ast.import_aliases
    type_map = build_type_map(tree, aliases)
    lines = python_ast.lines
    findings: list[AnalyzerFinding] = []
    contexts: dict[tuple[int, int], str] = {}

    def context_for(lineno: int, column: int) -> str:
        key = (lineno, column)
        context = contexts.get(key)
        if context is None:
            context = get_context_from_lines(lines, lineno, column=column)
            contexts[key] = context
        return context

    def _emit(
        node_index: int,
        rule_id: str,
        ast_node: ast.Call,
        msg_override: str | None = None,
    ) -> None:
        lineno = getattr(ast_node, "lineno", 1)
        end_lineno = getattr(ast_node, "end_lineno", None)
        complete_match = python_ast.source_segment(ast_node)
        if complete_match is None:
            complete_match = get_complete_source_segment(lines, lineno, end_lineno)
        start_byte_column = getattr(ast_node, "col_offset", None)
        end_byte_column = getattr(ast_node, "end_col_offset", None)
        start_column = python_ast.character_column(lineno, start_byte_column)
        end_column = python_ast.character_column(end_lineno or lineno, end_byte_column)
        finding = AnalyzerFinding(
            rule_id=rule_id,
            message=msg_override or _RULE_MESSAGES[rule_id],
            severity=_RULE_SEVERITIES[rule_id],
            location=Location(
                file=file_path,
                start_line=lineno,
                end_line=end_lineno,
                start_column=start_column,
                end_column=end_column,
            ),
            confidence=_RULE_CONFIDENCES[rule_id],
            tags=[_TAG],
            context=context_for(lineno, start_column if start_column is not None else 0),
            matched_text=complete_match[:200],
            complete_match=complete_match,
            # Evidence participates in report compaction. Keep distinct syntax
            # nodes distinguishable when their source spans are incomplete.
            evidence=(
                {"python_ast_node_index": node_index}
                if start_column is None or end_column is None
                else {}
            ),
        )
        if budget is None:
            findings.append(finding)
        else:
            budget.emit(finding)

    for node_index, ast_node in enumerate(ast.walk(tree)):
        if budget is not None:
            budget.check_runtime()
        if isinstance(ast_node, ast.Subscript):
            module = _reflective_module_dict_base(ast_node, aliases)
            if module is not None:
                key = ast_node.slice
                if isinstance(key, ast.Constant):
                    if isinstance(key.value, str) and key.value in _DANGEROUS_GETATTR_NAMES:
                        _emit(
                            node_index,
                            "AST9",
                            ast_node,
                            f"Reflective dangerous access via {module}.__dict__ subscript "
                            "with a literal sink name",
                        )
                else:
                    _emit(
                        node_index,
                        "AST7",
                        ast_node,
                        f"Dynamic attribute access via {module}.__dict__ subscript",
                    )
            continue
        if not isinstance(ast_node, ast.Call):
            continue

        if (
            isinstance(ast_node.func, ast.Attribute)
            and ast_node.func.attr in _REFLECTIVE_DICT_READ_METHODS
            and ast_node.args
        ):
            # <module>.__dict__.get(key) / .setdefault(key) / .pop(key), and the
            # same three on vars(<module>), all return the object a subscript
            # would — further spellings of the same reflective access that must
            # not evade AST7/AST9 either.
            method = ast_node.func.attr
            module = _reflective_module_dict_container(ast_node.func.value, aliases)
            if module is not None:
                key = ast_node.args[0]
                if isinstance(key, ast.Constant):
                    if isinstance(key.value, str) and key.value in _DANGEROUS_GETATTR_NAMES:
                        _emit(
                            node_index,
                            "AST9",
                            ast_node,
                            f"Reflective dangerous access via {module}.__dict__.{method}() "
                            "with a literal sink name",
                        )
                else:
                    _emit(
                        node_index,
                        "AST7",
                        ast_node,
                        f"Dynamic attribute access via {module}.__dict__.{method}()",
                    )
                continue

        call_name = resolve_call_name(ast_node, aliases)
        if call_name is not None:
            # Dynamic-import / code-exec sibling machinery (importlib.__import__,
            # importlib.util.find_spec, runpy.run_module, code.interact, and the
            # instance-method tails spec.loader.exec_module / runsource) resolves by name
            # but matches no ladder; remap it to the primitive it equals so it re-enters
            # the __import__/exec arms below.
            call_name = (
                canonical_sibling_sink(call_name)
                or canonical_sibling_method(ast_node, type_map, aliases)
                or call_name
            )
        if call_name is None:
            # Dynamic-import chain: importlib.import_module('os').system(...) →
            # 'os.system', so it re-enters the os./subprocess. sink ladders below.
            call_name = resolve_dynamic_import_call(ast_node, aliases)
        reflective = False
        if call_name is None and not _covered_by_ast9(ast_node, aliases):
            # Reflective invocation whose callee does not resolve by name:
            # getattr(subprocess, "Popen")(cmd) (outside AST9's allowlist),
            # __builtins__["exec"](src), vars(builtins)["exec"](src). Canonicalize to
            # the bare/dotted sink id so it re-enters the ladders below with the correct
            # rule + severity. A reflective read AST9 already reports (allowlisted getattr
            # or module-namespace read) is left to AST9 (see _covered_by_ast9) so the
            # two rules stay complementary, not duplicate.
            call_name = resolve_to_canonical_sink(ast_node, aliases)
            reflective = call_name is not None
        if call_name is None:
            continue

        if call_name == "exec":
            if _is_chain_sink(ast_node, aliases) and ast_node.args:
                source = _contains_dangerous_source(
                    ast_node.args[0],
                    aliases,
                    budget.check_runtime if budget is not None else None,
                )
                if source:
                    _emit(
                        node_index, "AST8", ast_node, f"Dangerous chain: exec() wrapping {source}"
                    )
            _emit(node_index, "AST1", ast_node)

        elif call_name == "eval":
            if _is_chain_sink(ast_node, aliases) and ast_node.args:
                source = _contains_dangerous_source(
                    ast_node.args[0],
                    aliases,
                    budget.check_runtime if budget is not None else None,
                )
                if source:
                    _emit(
                        node_index, "AST8", ast_node, f"Dangerous chain: eval() wrapping {source}"
                    )
            _emit(node_index, "AST2", ast_node)

        elif call_name == "__import__":
            _emit(node_index, "AST3", ast_node)

        elif call_name == "compile":
            _emit(node_index, "AST6", ast_node)

        elif call_name.startswith("subprocess."):
            attr = call_name.split(".", 1)[1]
            if attr in _SUBPROCESS_CALLS:
                # A *reflective* subprocess invocation (getattr/subscript) signals the
                # same evasion intent as reflective os.system, so it grades AST9-HIGH to
                # stay consistent with that case; a direct subprocess.* call keeps its
                # baseline AST4-MEDIUM.
                _emit(node_index, "AST9" if reflective else "AST4", ast_node)

        elif call_name.startswith("os."):
            attr = call_name.split(".", 1)[1]
            if attr in _OS_EXEC_CALLS:
                _emit(node_index, "AST5", ast_node)

        elif (deser_msg := _deserialization_message(call_name, ast_node)) is not None:
            _emit(node_index, "AST10", ast_node, deser_msg)

        elif call_name == "getattr" and len(ast_node.args) >= 2:
            second_arg = ast_node.args[1]
            resolved_name = _constant_string(second_arg)
            # A direct non-string literal cannot name an attribute.  Do not
            # conflate it with a dynamic or constructed expression, which
            # remains an AST7 signal unless it resolves to an AST9 sink.
            if isinstance(second_arg, ast.Constant) and not isinstance(second_arg.value, str):
                continue
            if resolved_name in _DANGEROUS_GETATTR_NAMES:
                _emit(node_index, "AST9", ast_node)
            elif resolved_name is None or not isinstance(second_arg, ast.Constant):
                _emit(node_index, "AST7", ast_node)

    return findings if budget is None else list(budget.current_findings)


def _partial_limit_event(
    path: str,
    limit: _BehavioralResourceLimitError,
    *,
    emitted_finding_ids: list[str] | None = None,
) -> InspectionLedgerEvent:
    """Account one current or unstarted Python work item as explicitly partial."""
    return ledger_event(
        outcome=LedgerOutcome.PARTIAL,
        phase="behavioral",
        analyzer_id=ANALYZER_ID,
        path=path,
        reason=limit.reason,
        emitted_finding_ids=emitted_finding_ids or (),
        observed_findings=(
            int(limit.metrics["observed_findings"])
            if limit.reason is LedgerReason.OUTPUT_LIMIT
            else None
        ),
        limit_findings=(
            int(limit.metrics["limit_findings"])
            if limit.reason is LedgerReason.OUTPUT_LIMIT
            else None
        ),
        observed_seconds=(
            float(limit.metrics["observed_seconds"])
            if limit.reason is LedgerReason.RUNTIME_LIMIT
            else None
        ),
        limit_seconds=(
            float(limit.metrics["limit_seconds"])
            if limit.reason is LedgerReason.RUNTIME_LIMIT
            else None
        ),
    )


def node(state: SkillspectorState) -> AnalyzerNodeResponse:
    """Parse Python files via AST and detect dangerous execution patterns."""
    components: list[str] = state.get("components") or []
    file_cache: dict[str, str] = state.get("local_file_cache") or state.get("file_cache") or {}
    raw_file_cache = state.get("raw_file_cache")
    source_classifications = (
        state.get("python_source_classifications")
        if "python_source_classifications" in state
        else None
    )
    source_classification_limitations = state.get("python_source_classification_limitations") or {}
    source_decode_failures = state.get("python_source_decode_failures") or {}
    python_ast_cache_key = state.get("python_ast_cache_key")
    all_findings: list[Finding] = []
    ledger_events: list[InspectionLedgerEvent] = []
    budget = _BehavioralBudget(state)
    terminal_limit: _BehavioralResourceLimitError | None = None

    for path in components:
        content = file_cache.get(path)
        source_classification: PythonSourceClassification | None = None
        if source_classifications is not None and path in source_classifications:
            source_classification = resolve_python_source_classification(
                path,
                content,
                source_classifications=source_classifications,
                raw_file_cache=raw_file_cache,
            )
            if source_classification is PythonSourceClassification.NON_PYTHON:
                continue
        if path in source_classification_limitations:
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    phase="behavioral",
                    analyzer_id=ANALYZER_ID,
                    path=path,
                    reason=LedgerReason.RUNTIME_LIMIT,
                )
            )
            continue
        if terminal_limit is None and budget.analyzer_exhausted():
            terminal_limit = _BehavioralResourceLimitError(
                LedgerReason.OUTPUT_LIMIT,
                {
                    "observed_findings": budget.total_findings + 1,
                    "limit_findings": MAX_FINDINGS_PER_ANALYZER,
                },
            )
        if terminal_limit is None:
            try:
                budget.check_runtime()
            except _BehavioralResourceLimitError as exc:
                terminal_limit = exc
        if terminal_limit is not None:
            event = _partial_limit_event(path, terminal_limit)
            ledger_events.append(event)
            continue
        if path in source_decode_failures:
            ledger_events.append(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    phase="behavioral",
                    analyzer_id=ANALYZER_ID,
                    path=path,
                    reason=LedgerReason.PYTHON_SOURCE_DECODE_ERROR,
                )
            )
            continue
        if source_classification is None:
            source_classification = resolve_python_source_classification(
                path,
                content,
                source_classifications=source_classifications,
                raw_file_cache=raw_file_cache,
            )
            try:
                budget.check_runtime()
            except _BehavioralResourceLimitError as exc:
                terminal_limit = exc
                ledger_events.append(_partial_limit_event(path, exc))
                continue
        if source_classification is PythonSourceClassification.NON_PYTHON:
            continue
        if content is None:
            event = ledger_event(
                outcome=LedgerOutcome.FAILED,
                phase="behavioral",
                analyzer_id=ANALYZER_ID,
                path=path,
                reason=LedgerReason.MISSING_FILE_CACHE,
            )
        elif len(content) > MAX_FILE_CHARS:
            event = ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                phase="behavioral",
                analyzer_id=ANALYZER_ID,
                path=path,
                reason=LedgerReason.SIZE_LIMIT,
                observed_characters=len(content),
                limit_characters=MAX_FILE_CHARS,
                observed_bytes=len(content.encode("utf-8")),
            )
        else:
            budget.current_findings = []
            resource_limit: _BehavioralResourceLimitError | None = None
            python_ast: ParsedPythonFile | None = None
            try:
                budget.begin_artifact()
                python_ast = get_python_ast(python_ast_cache_key, content, path)
                budget.check_runtime()
                if python_ast.is_parseable:
                    _analyze_python(python_ast, path, budget)
            except _BehavioralResourceLimitError as exc:
                resource_limit = exc

            path_findings = [analyzer_finding_to_finding(af) for af in budget.current_findings]
            all_findings.extend(path_findings)
            if resource_limit is not None:
                event = _partial_limit_event(
                    path,
                    resource_limit,
                    emitted_finding_ids=[finding.finding_id for finding in path_findings],
                )
                if (
                    resource_limit.reason is LedgerReason.RUNTIME_LIMIT
                    or budget.analyzer_exhausted()
                ):
                    terminal_limit = resource_limit
            elif python_ast is None or not python_ast.is_parseable:
                event = ledger_event(
                    outcome=LedgerOutcome.SKIPPED,
                    phase="behavioral",
                    analyzer_id=ANALYZER_ID,
                    path=path,
                    reason=LedgerReason.SYNTAX_ERROR,
                )
            else:
                event = ledger_event(
                    outcome=(
                        LedgerOutcome.PARTIAL
                        if source_classification is PythonSourceClassification.AMBIGUOUS
                        else LedgerOutcome.COMPLETED
                    ),
                    phase="behavioral",
                    analyzer_id=ANALYZER_ID,
                    path=path,
                    reason=(
                        LedgerReason.PYTHON_SOURCE_AMBIGUOUS
                        if source_classification is PythonSourceClassification.AMBIGUOUS
                        else None
                    ),
                    emitted_finding_ids=[finding.finding_id for finding in path_findings],
                )
        ledger_events.append(event)

    logger.info("%s: %d findings", ANALYZER_ID, len(all_findings))
    if not ledger_events:
        status = analyzer_status_event(
            analyzer_id=ANALYZER_ID,
            status="not_applicable",
            reason=LedgerReason.NO_APPLICABLE_FILES,
        )
    else:
        status = analyzer_status_for_events(ANALYZER_ID, ledger_events)
    return {
        "findings": all_findings,
        "inspection_ledger": ledger_events,
        "analyzer_status_events": [status],
    }
