# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Report node for Skillspector workflow.

Generates SARIF, computes risk score, and produces report_body in terminal/json/markdown/sarif
based on state["output_format"]. Single place for formatting (CLI and REST API reuse).
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import replace
from datetime import UTC, datetime
from hashlib import sha256
from html import escape as escape_html
from io import StringIO
from typing import Literal, cast
from urllib.parse import quote

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from skillspector import __version__ as skillspector_version
from skillspector.dependency_sources import redact_text
from skillspector.inference_usage import looks_like_credential, sanitize_inference_usage
from skillspector.input_origin import input_origin
from skillspector.inspection_ledger import (
    MAX_FINDING_OUTPUT_RECORDS,
    RESOURCE_MEASUREMENT_UNITS,
    RULE_SET_SCOPE,
    AnalysisCompleteness,
    ParserCause,
    bounded_inspection_notices,
    finalize_ledger,
    format_recovery_policy_accepted,
    only_missing_reference_exceptions,
    resource_measurements,
    sanitize_parser_diagnostic,
)
from skillspector.llm_provenance import sanitize_llm_provenance
from skillspector.llm_utils import is_llm_available
from skillspector.logging_config import get_logger
from skillspector.models import (
    OCCURRENCE_CODE_SNIPPET_KEY,
    OCCURRENCE_FINDING_ID_KEY,
    OCCURRENCE_FINDING_TEXT_KEY,
    Finding,
)
from skillspector.nodes.analyzers import ANALYZER_MODULES
from skillspector.nodes.deduplicate import deduplicate
from skillspector.python_ast import clear_python_ast_cache
from skillspector.sarif_models import (
    SARIF_SCHEMA_URI,
    SarifArtifactLocation,
    SarifDriver,
    SarifInvocation,
    SarifLocation,
    SarifLog,
    SarifMessage,
    SarifNotification,
    SarifPhysicalLocation,
    SarifRegion,
    SarifReportingDescriptor,
    SarifResult,
    SarifRun,
    SarifSuppression,
    SarifTool,
    validate_sarif_report,
)
from skillspector.semantic_runtime import (
    all_llm_calls_failed_with_structured_output_rejection,
    has_semantic_runtime_event,
    llm_runtime_available,
    semantic_runtime_accounting,
    semantic_runtime_intent,
    semantic_runtime_ledger_event,
    successful_llm_record,
)
from skillspector.state import SkillspectorState, transitive_remaining_seconds
from skillspector.suppression import Baseline, SuppressedFinding, partition_findings
from skillspector.terminal_text import visible_terminal_text

logger = get_logger(__name__)

# Risk bands (v1 alignment)
_RISK_SEVERITY_BANDS = [(81, "CRITICAL"), (51, "HIGH"), (21, "MEDIUM"), (0, "LOW")]
_RISK_RECOMMENDATION: dict[str, str] = {
    "LOW": "SAFE",
    "MEDIUM": "CAUTION",
    "HIGH": "DO_NOT_INSTALL",
    "CRITICAL": "DO_NOT_INSTALL",
}


def risk_severity_and_recommendation(score: int) -> tuple[str, str]:
    """Map a computed score to the shared single-skill and recursive verdict."""
    severity = "LOW"
    for threshold, band in _RISK_SEVERITY_BANDS:
        if score >= threshold:
            severity = band
            break
    return severity, _RISK_RECOMMENDATION.get(severity, "CAUTION")


# Scanned skill content (and LLM output that quotes it) can carry ANSI escape
# sequences and control bytes (e.g. NUL, ESC) into finding text. Left in, they
# make a rendered report register as binary — GitLab/editors show "download"
# instead of the Markdown, and terminals emit garbled output. Strip them from
# every finding text field so all report formats stay clean UTF-8.
_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Finding free-text fields that may carry scanned/LLM content.
_SANITIZED_FIELDS = (
    "message",
    "pattern",
    "explanation",
    "remediation",
    "finding",
    "context",
    "matched_text",
    "code_snippet",
)

_REPORT_SAFE_SOURCE_ID_RE = re.compile(r"external/[0-9a-f]{64}\Z")

_PARSER_CAUSE_DESCRIPTIONS = {
    ParserCause.RESOURCE_LIMIT: "SkillSpector reached a configured inspection limit.",
    ParserCause.BOUNDARY_UNRESOLVED: (
        "SkillSpector could not determine this command or code fragment's boundaries."
    ),
    ParserCause.MALFORMED_INPUT: (
        "This code fragment has invalid syntax (its structure is not valid for this language)."
    ),
    ParserCause.UNSUPPORTED_SYNTAX: "SkillSpector cannot fully inspect this code pattern yet.",
    ParserCause.RUNTIME_DEPENDENT: (
        "Full inspection depends on information available only when this code runs."
    ),
}


def _resource_measurement_description(
    row: Mapping[str, object], *, lower_bound: bool = False
) -> str:
    measurements = resource_measurements(row)
    details: list[str] = []
    for unit in RESOURCE_MEASUREMENT_UNITS:
        if f"observed_{unit}" in measurements or f"limit_{unit}" in measurements:
            observed = measurements.get(f"observed_{unit}", "not recorded")
            limit = measurements.get(f"limit_{unit}", "not recorded")
            if lower_bound and f"observed_{unit}" in measurements:
                observed = f"at least {observed}"
            details.append(f"{unit}: observed {observed}, limit {limit}")
    return "; ".join(details)


def _inspection_exception_message(row: Mapping[str, object]) -> str:
    """Describe only vetted parser causes and actual resource measurements."""
    original_message = str(row.get("message", ""))
    message = ""
    diagnostic = sanitize_parser_diagnostic(row.get("parser_diagnostic"))
    details = _resource_measurement_description(row)
    if details:
        message += f" Measurements: {details}."
    elif str(row.get("reason_code", "")).endswith("_limit") and (
        diagnostic is None
        or (
            diagnostic["cause"] is ParserCause.RESOURCE_LIMIT
            and not resource_measurements(diagnostic)
        )
    ):
        message += " Resource measurements not recorded."
    if diagnostic is not None:
        message += f" {_PARSER_CAUSE_DESCRIPTIONS[diagnostic['cause']]}"
        check = diagnostic["check"].replace("_", " ")
        scope = diagnostic["unchecked_scope"].replace("_", " ")
        location = (
            "reported source range"
            if diagnostic["location_precision"] == "source_span"
            else "enclosing expression (exact inner location unavailable)"
        )
        message += f" Check: {check}; location: {location}; unchecked scope: {scope}."
        message += (
            " Relevant parser input fully checked."
            if diagnostic["full_input_checked"]
            else " Relevant parser input not fully checked."
        )
        measurements = _resource_measurement_description(
            diagnostic, lower_bound=diagnostic["observed_is_lower_bound"]
        )
        if measurements:
            message += f" Parser measurements: {measurements}."
    return original_message if original_message.endswith(message) else original_message + message


def _inspection_exception_lines(row: Mapping[str, object]) -> tuple[int | None, int | None]:
    start, end = row.get("start_line"), row.get("end_line")
    if type(start) is int and start > 0:
        return start, end if type(end) is int and end >= start else None
    diagnostic = sanitize_parser_diagnostic(row.get("parser_diagnostic"))
    return (diagnostic["start_line"], diagnostic["end_line"]) if diagnostic else (None, None)


def _clean_text(value: str | None) -> str | None:
    """Strip ANSI escape sequences and disallowed control chars (keep tab/newline)."""
    if not isinstance(value, str):
        return value
    return _CONTROL_RE.sub("", _ANSI_RE.sub("", value))


def redact_llm_error(value: object) -> str | None:
    """Keep actionable provider error text without report-visible credentials."""
    if not isinstance(value, str) or not value.strip():
        return None
    cleaned = redact_text(_clean_text(value) or "")
    return re.sub(
        r"(?i)(?:(?:authorization\s*:\s*)?(?:bearer|basic)\s+)?[A-Za-z0-9_+/.-]+={0,2}",
        lambda match: "***" if looks_like_credential(match.group(0)) else match.group(0),
        cleaned,
    )


def _sanitize_finding(finding: Finding) -> Finding:
    """Clean finding text and recursively redact credentials from evidence."""

    def clean(value: str | None) -> str | None:
        cleaned = _clean_text(value)
        return redact_text(cleaned) if isinstance(cleaned, str) else cleaned

    def clean_evidence(value: object) -> object:
        if isinstance(value, str):
            return clean(value)
        if isinstance(value, dict):
            return {clean(str(key)) or "": clean_evidence(item) for key, item in value.items()}
        if isinstance(value, list):
            return [clean_evidence(item) for item in value]
        if isinstance(value, tuple):
            return tuple(clean_evidence(item) for item in value)
        return value

    evidence = {
        clean(str(key)) or "": clean_evidence(value) for key, value in finding.evidence.items()
    }
    occurrences = []
    for raw in finding.occurrences:
        occurrence = dict(raw)
        report_snippet = occurrence.get(OCCURRENCE_CODE_SNIPPET_KEY)
        if isinstance(report_snippet, str):
            occurrence[OCCURRENCE_CODE_SNIPPET_KEY] = clean(report_snippet)
        report_finding_text = occurrence.get(OCCURRENCE_FINDING_TEXT_KEY)
        if isinstance(report_finding_text, str):
            occurrence[OCCURRENCE_FINDING_TEXT_KEY] = clean(report_finding_text)
        occurrences.append(occurrence)
    return replace(
        finding,
        message=clean(finding.message) or "",
        pattern=clean(finding.pattern),
        explanation=clean(finding.explanation),
        remediation=clean(finding.remediation),
        finding=clean(finding.finding),
        context=clean(finding.context),
        matched_text=clean(finding.matched_text),
        code_snippet=clean(finding.code_snippet),
        evidence=evidence,
        occurrences=occurrences,
    )


def _finding_for_occurrence(finding: Finding, occurrence: Mapping[str, object]) -> Finding:
    """Return report-only metadata bound to one compacted occurrence."""
    finding_id = occurrence.get(OCCURRENCE_FINDING_ID_KEY)
    snippet = occurrence.get(OCCURRENCE_CODE_SNIPPET_KEY)
    if not isinstance(finding_id, str) or not finding_id:
        finding_id = finding.finding_id
    finding_text = finding.finding
    if OCCURRENCE_FINDING_TEXT_KEY in occurrence:
        text = occurrence.get(OCCURRENCE_FINDING_TEXT_KEY)
        finding_text = text if isinstance(text, str) else None
    if OCCURRENCE_CODE_SNIPPET_KEY not in occurrence:
        return replace(finding, finding_id=finding_id, finding=finding_text)
    return replace(
        finding,
        finding_id=finding_id,
        finding=finding_text,
        code_snippet=snippet if isinstance(snippet, str) else None,
        context=None,
    )


def _occurrence_provenance(
    finding: Finding, occurrence: Mapping[str, object] | None = None
) -> dict[str, object]:
    """Return occurrence-level provenance, falling back to the finding scope."""
    occurrence = occurrence or {}
    provenance: dict[str, object] = {}
    for key, fallback in (
        ("source_identity", finding.source_identity),
        ("source_digest", finding.source_digest),
        ("source_url", finding.source_url),
    ):
        value = occurrence.get(key, fallback)
        if isinstance(value, str) and value:
            provenance[key] = value
    depth = occurrence.get("transitive_depth", finding.transitive_depth)
    if isinstance(depth, int) and not isinstance(depth, bool) and depth > 0:
        provenance["transitive_depth"] = depth
    return provenance


def _report_source_identity(provenance: Mapping[str, object]) -> str | None:
    """Return a safe opaque SARIF scope for source provenance."""
    identity = provenance.get("source_identity")
    if isinstance(identity, str) and identity:
        if _REPORT_SAFE_SOURCE_ID_RE.fullmatch(identity):
            return identity
        return f"external/{sha256(identity.encode()).hexdigest()}"
    digest = provenance.get("source_digest")
    source_url = provenance.get("source_url")
    if not digest and not source_url:
        return None
    canonical = json.dumps(
        {"source_digest": digest or "", "source_url": source_url or ""},
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    return f"external/{sha256(canonical.encode()).hexdigest()}"


def _sarif_artifact_location(
    finding: Finding, occurrence: Mapping[str, object] | None = None
) -> SarifArtifactLocation:
    """Build a source-scoped SARIF artifact location for one occurrence."""
    occurrence = occurrence or {}
    file_path = str(occurrence.get("file", finding.file)).replace("\\", "/").lstrip("/")
    provenance = _occurrence_provenance(finding, occurrence)
    source_identity = _report_source_identity(provenance)
    if source_identity:
        uri = f"{source_identity}/{file_path}"
    else:
        uri = str(occurrence.get("file", finding.file))
    properties = {
        {
            "source_identity": "sourceIdentity",
            "source_digest": "sourceDigest",
            "source_url": "sourceUrl",
            "transitive_depth": "transitiveDepth",
        }[key]: value
        for key, value in provenance.items()
    }
    return SarifArtifactLocation(uri=quote(uri, safe="/!"), properties=properties or None)


def _occurrence_columns(
    finding: Finding, occurrence: Mapping[str, object]
) -> tuple[int | None, int | None]:
    """Do not borrow representative columns for an occurrence with unknown columns."""
    start = occurrence.get(
        "start_column", finding.start_column if not finding.occurrences else None
    )
    end = occurrence.get("end_column", finding.end_column if not finding.occurrences else None)
    return (
        start if isinstance(start, int) else None,
        end if isinstance(end, int) else None,
    )


def _expand_occurrences(findings: list[Finding]) -> list[Finding]:
    """Expand compacted findings for human/JSON output without losing locations."""
    expanded: list[Finding] = []
    for finding in findings:
        occurrences = finding.occurrences or [
            {
                "file": finding.file,
                "start_line": finding.start_line,
                "end_line": finding.end_line,
            }
        ]
        for occurrence in occurrences:
            occurrence_finding = _finding_for_occurrence(finding, occurrence)
            start_value = occurrence.get("start_line", finding.start_line)
            start_line = start_value if isinstance(start_value, int) else finding.start_line
            end_value = occurrence.get("end_line")
            end_line = end_value if isinstance(end_value, int) else None
            start_column, end_column = _occurrence_columns(finding, occurrence)
            provenance = _occurrence_provenance(finding, occurrence)
            depth_value = provenance.get("transitive_depth")
            occurrence_file = str(occurrence.get("file", finding.file))
            recorded_surface = occurrence.get("surface")
            occurrence_surface = (
                str(recorded_surface)
                if isinstance(recorded_surface, str) and recorded_surface
                else (finding.surface if occurrence_file == finding.file else None)
            )
            expanded.append(
                replace(
                    occurrence_finding,
                    file=occurrence_file,
                    start_line=start_line,
                    end_line=end_line,
                    start_column=start_column,
                    end_column=end_column,
                    source_identity=(
                        str(provenance["source_identity"])
                        if "source_identity" in provenance
                        else None
                    ),
                    source_digest=(
                        str(provenance["source_digest"]) if "source_digest" in provenance else None
                    ),
                    source_url=(
                        str(provenance["source_url"]) if "source_url" in provenance else None
                    ),
                    transitive_depth=depth_value if isinstance(depth_value, int) else 0,
                    occurrences=[],
                    # Prefer the occurrence's own recorded label. An occurrence
                    # aggregated from another file keeps the surface that file's
                    # finding carried; ``None`` falls back to a path-only label.
                    surface=occurrence_surface,
                )
            )
    return expanded


def _finding_output_record_count(findings: Sequence[Finding]) -> int:
    """Count compact findings using their public occurrence-record footprint."""
    return sum(max(1, len(finding.occurrences)) for finding in findings)


def _bounded_report_findings(
    findings: list[Finding],
    *,
    limit: int | None = None,
) -> list[Finding]:
    """Bound compact findings and their occurrence records in severity order."""
    bounded: list[Finding] = []
    remaining = max(0, MAX_FINDING_OUTPUT_RECORDS if limit is None else limit)
    for finding in findings:
        if remaining <= 0:
            break
        occurrences = finding.occurrences
        record_count = max(1, len(occurrences))
        if record_count > remaining:
            if not occurrences:
                break
            bounded.append(replace(finding, occurrences=occurrences[:remaining]))
            remaining = 0
            break
        bounded.append(finding)
        remaining -= record_count
    return bounded


def _bounded_suppressed_findings(
    findings: list[SuppressedFinding],
    *,
    limit: int,
) -> list[SuppressedFinding]:
    """Bound suppressed findings with the same occurrence-record accounting."""
    bounded: list[SuppressedFinding] = []
    remaining = max(0, limit)
    for suppressed in findings:
        if remaining <= 0:
            break
        finding = suppressed.finding
        occurrences = finding.occurrences
        record_count = max(1, len(occurrences))
        if record_count > remaining:
            if not occurrences:
                break
            bounded.append(
                replace(
                    suppressed,
                    finding=replace(finding, occurrences=occurrences[:remaining]),
                )
            )
            remaining = 0
            break
        bounded.append(suppressed)
        remaining -= record_count
    return bounded


def _build_sarif_properties(
    finding: Finding, occurrence: Mapping[str, object] | None = None
) -> dict[str, object] | None:
    """Project selected finding metadata into a SARIF properties dictionary."""
    occurrence_finding = _finding_for_occurrence(finding, occurrence or {})
    finding_dict = occurrence_finding.to_dict()
    recorded_surface = (occurrence or {}).get("surface")
    surface = (
        str(recorded_surface)
        if isinstance(recorded_surface, str) and recorded_surface
        else finding_dict["surface"]
    )
    metadata: dict[str, object] = {
        "findingId": occurrence_finding.finding_id,
        "severity": finding_dict["severity"],
        # GitHub code scanning banding: emitted alongside level so generic
        # SARIF consumers can distinguish CRITICAL from HIGH.
        "security-severity": _severity_to_security_severity(str(finding.severity)),
        "category": finding_dict["category"],
        "pattern": finding_dict["pattern"],
        "confidence": finding_dict["confidence"],
        "finding": finding_dict["finding"],
        "explanation": finding_dict["explanation"],
        "remediation": finding_dict["remediation"],
        "code_snippet": finding_dict["code_snippet"],
        "intent": finding_dict["intent"],
        "tags": finding_dict["tags"],
        "evidence": finding_dict["evidence"],
        "surface": surface,
    }
    provenance = _occurrence_provenance(finding, occurrence)
    for key, sarif_key in (
        ("source_identity", "sourceIdentity"),
        ("source_digest", "sourceDigest"),
        ("source_url", "sourceUrl"),
        ("transitive_depth", "transitiveDepth"),
    ):
        if key in provenance:
            metadata[sarif_key] = provenance[key]
    cleaned = {key: value for key, value in metadata.items() if value is not None}
    return cleaned or None


def _sanitize_summary_value(value: object) -> object:
    """Return a recursively sanitized copy of structured-summary content."""
    if isinstance(value, str):
        return _clean_text(value)
    if isinstance(value, list):
        return [_sanitize_summary_value(item) for item in value]
    if isinstance(value, tuple):
        return [_sanitize_summary_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _sanitize_summary_value(item) for key, item in value.items()}
    return value


def _sanitize_structured_summary(summary: dict[str, object]) -> dict[str, object]:
    """Return a structured summary with control/ANSI bytes stripped from text fields."""
    return {str(key): _sanitize_summary_value(value) for key, value in summary.items()}


def _severity_to_sarif_level(severity: str) -> Literal["error", "warning", "note"]:
    """Map Finding.severity to SARIF result level."""
    return {
        "CRITICAL": "error",
        "HIGH": "error",
        "MEDIUM": "warning",
        "LOW": "note",
    }.get(severity.upper(), "note")  # type: ignore[return-value]


# SARIF has no critical level, so CRITICAL and HIGH both map to "error" above.
# GitHub code scanning and most SARIF gates band security-severity >= 9.0 as
# critical, 7.0-8.9 as high, 4.0-6.9 as medium, and 0.1-3.9 as low; the values
# below keep each SkillSpector severity inside its band.
_SEVERITY_TO_SECURITY_SEVERITY: dict[str, str] = {
    "CRITICAL": "9.5",
    "HIGH": "8.0",
    "MEDIUM": "5.5",
    "LOW": "3.0",
}


def _severity_to_security_severity(severity: str) -> str | None:
    """Map Finding.severity to a SARIF security-severity score string.

    Returns None for unknown severities so no misleading score is emitted.
    """
    return _SEVERITY_TO_SECURITY_SEVERITY.get(severity.upper())


def _summary_display_value(value: object) -> str | None:
    """Format a summary field for terminal / markdown output."""
    if value is None:
        return None
    if isinstance(value, list):
        values = [str(item) for item in value if str(item)]
        return ", ".join(values) if values else None
    text = str(value)
    return text or None


def _structured_summary_notification(summary: dict[str, object]) -> str:
    """Build a note-level SARIF notification message for a structured summary."""
    summary_id = str(summary.get("id") or "SSR")
    message = str(summary.get("message") or "Structured skill summary")
    bits = [f"{summary_id}: {message}"]

    file = _summary_display_value(summary.get("file"))
    if file:
        bits.append(f"file={file}")
    protocol = _summary_display_value(summary.get("protocol"))
    if protocol:
        bits.append(f"protocol={protocol}")
    layout_kind = _summary_display_value(summary.get("layout_kind"))
    if layout_kind:
        bits.append(f"layout={layout_kind}")

    return " | ".join(bits)


_SEVERITY_POINTS: dict[str, int] = {
    "CRITICAL": 50,
    "HIGH": 25,
    "MEDIUM": 10,
    "LOW": 5,
}

# Ranking used only to report the worst finding alongside the normalized verdict.
# Deliberately separate from _SEVERITY_POINTS: those are scoring weights and may be
# retuned, while this is an ordering and must stay stable for consumers.
_SEVERITY_RANK: dict[str, int] = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


def _max_issue_severity(findings: Sequence[Finding]) -> str:
    """Highest severity present in the reported issues, or NONE when there are none.

    risk_assessment.severity is a normalized, confidence-weighted verdict: it can read
    LOW while issues[] contains a HIGH finding. That smoothing is intentional, but until
    now it was invisible, so every consumer that wanted to gate on the worst finding had
    to walk issues[] and re-implement this ranking. Reporting it here makes the two
    numbers comparable without changing either.
    """
    worst = 0
    label = "NONE"
    for finding in findings:
        rank = _SEVERITY_RANK.get(str(finding.severity).upper(), 0)
        if rank > worst:
            worst = rank
            label = str(finding.severity).upper()
    return label


_MAX_OCCURRENCES_PER_RULE = 3
_DIMINISHING_WEIGHTS = (1.0, 0.5, 0.25)

# Some findings describe artifacts whose unanalyzed contents can execute. Their
# presence must block installation even when ordinary confidence-weighted,
# per-rule scoring would otherwise keep the aggregate below the CLI threshold.
_RISK_SCORE_FLOORS_BY_RULE_ID = {"SC8": 51}


def _risk_score_floor(finding: Finding) -> int:
    """Return a blocking floor only for closed, potentially effective proofs."""
    configured_floor = _RISK_SCORE_FLOORS_BY_RULE_ID.get(finding.rule_id, 0)
    if configured_floor:
        return configured_floor
    if finding.rule_id == "SC9" and (
        finding.evidence.get("excluded_from_analysis") is True
        or finding.evidence.get("partially_analyzed_executable") is True
    ):
        return 51
    if (finding.severity or "").upper() != "CRITICAL":
        return 0
    if finding.evidence.get("activation_state") != "conditional":
        return 0
    if finding.rule_id == "BH2" and finding.evidence.get("proof_status") == "closed":
        return 51
    if finding.rule_id == "BH3":
        return 51
    return 0


def _compute_risk_score(
    findings: list[Finding],
    has_executable_scripts: bool,
    component_metadata: list[dict[str, object]] | None = None,
) -> tuple[int, str, str]:
    """
    Compute risk score (0-100), severity band, and recommendation.

    Scoring uses per-rule diminishing returns: the first occurrence of a rule_id
    contributes full points, the second contributes half, and the third contributes
    a quarter. Occurrences beyond the third are ignored for scoring purposes.
    This prevents repeated pattern matches from inflating the score unboundedly.

    Each finding's contribution is also scaled by its confidence value (clamped
    to [0, 1]). Findings with confidence <= 0 are skipped entirely — they do not
    contribute to the score but remain in the reported findings list.

    Within each rule_id bucket, findings are processed in severity-descending
    order so that the highest-severity occurrence always receives the full weight.

    Base points per severity: CRITICAL=50, HIGH=25, MEDIUM=10, LOW=5.
    1.3x multiplier applied only to findings from executable script files;
    findings from documentation files (markdown, text, json, yaml, toml)
    are scored at base weight to avoid punishing security documentation.
    """
    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    sorted_findings = sorted(
        findings,
        key=lambda f: (f.rule_id or "UNKNOWN", severity_rank.get((f.severity or "LOW").upper(), 4)),
    )

    def component_source_scope(component: Mapping[str, object]) -> str:
        for key in ("source_identity", "source_url", "source_digest"):
            value = component.get(key)
            if isinstance(value, str) and value:
                return f"{key}:{value}"
        return ""

    def finding_source_scope(finding: Finding) -> str:
        for key, value in (
            ("source_identity", finding.source_identity),
            ("source_url", finding.source_url),
            ("source_digest", finding.source_digest),
        ):
            if value:
                return f"{key}:{value}"
        return ""

    file_executable: dict[tuple[str, str], bool] = {}
    if component_metadata:
        for cm in component_metadata:
            file_executable[(component_source_scope(cm), str(cm.get("path", "")))] = bool(
                cm.get("executable", False)
            )

    rule_occurrence_count: dict[str, int] = {}
    score = 0.0

    for f in sorted_findings:
        confidence = max(0.0, min(1.0, f.confidence))
        if confidence <= 0.0:
            continue

        sev = (f.severity or "LOW").upper()
        base_points = _SEVERITY_POINTS.get(sev, 5)

        rule_id = f.rule_id or "UNKNOWN"
        count = rule_occurrence_count.get(rule_id, 0)
        rule_occurrence_count[rule_id] = count + 1

        if count >= _MAX_OCCURRENCES_PER_RULE:
            continue

        weight = _DIMINISHING_WEIGHTS[count]
        contribution = base_points * weight * confidence

        # Apply 1.3x multiplier only to findings from executable files
        if has_executable_scripts and file_executable.get((finding_source_scope(f), f.file), False):
            contribution *= 1.3

        score += contribution

    score_floor = max(
        (_risk_score_floor(f) for f in sorted_findings if max(0.0, min(1.0, f.confidence)) > 0.0),
        default=0,
    )
    if component_metadata and any(
        (
            component.get("excluded_from_analysis") is True
            or component.get("partially_analyzed_executable") is True
        )
        and component.get("allowed_exclusion") is not True
        and (
            component.get("executable") is True
            or component.get("excluded_inspection_incomplete") is True
        )
        for component in component_metadata
    ):
        score_floor = max(score_floor, 51)
    final_score = min(100, max(score_floor, int(score)))

    severity_band, recommendation = risk_severity_and_recommendation(final_score)
    return final_score, severity_band, recommendation


def _build_sarif(
    findings: list[Finding],
    suppressed: list[SuppressedFinding] | None = None,
    degraded_notice: str | None = None,
    analysis_completeness: Mapping[str, object] | None = None,
    execution_successful: bool = True,
    structured_summaries: list[dict[str, object]] | None = None,
    origin: dict[str, str] | None = None,
) -> dict[str, object]:
    """Build one SARIF invocation with canonical inspection notifications."""
    results: list[SarifResult] = []
    seen_rule_ids: dict[str, str] = {}
    seen_rule_severities: dict[str, set[str]] = {}

    for finding in findings:
        if not finding.rule_id or not finding.message:
            continue
        seen_rule_severities.setdefault(finding.rule_id, set()).add(str(finding.severity).upper())
        occurrences = finding.occurrences or [
            {
                "file": finding.file,
                "start_line": finding.start_line,
                "end_line": finding.end_line,
            }
        ]
        for occurrence in occurrences:
            start_value = occurrence.get("start_line", finding.start_line)
            start_line = start_value if isinstance(start_value, int) else finding.start_line
            end_value = occurrence.get("end_line")
            end_line = int(end_value) if isinstance(end_value, int) else None
            start_column, end_column = _occurrence_columns(finding, occurrence)
            results.append(
                SarifResult(
                    ruleId=finding.rule_id,
                    message=SarifMessage(text=finding.message),
                    level=_severity_to_sarif_level(finding.severity),
                    properties=_build_sarif_properties(finding, occurrence),
                    locations=[
                        SarifLocation(
                            physicalLocation=SarifPhysicalLocation(
                                artifactLocation=_sarif_artifact_location(finding, occurrence),
                                region=SarifRegion(
                                    startLine=start_line,
                                    endLine=end_line,
                                    startColumn=start_column + 1
                                    if start_column is not None
                                    else None,
                                    endColumn=end_column + 1 if end_column is not None else None,
                                ),
                            )
                        )
                    ],
                )
            )
        if finding.rule_id not in seen_rule_ids:
            seen_rule_ids[finding.rule_id] = finding.message

    # Baseline-suppressed findings are kept in the SARIF for an audit trail, but
    # marked with the `suppressions` property so consumers exclude them from counts.
    for sf in suppressed or []:
        finding = sf.finding
        if not finding.rule_id or not finding.message:
            continue
        seen_rule_severities.setdefault(finding.rule_id, set()).add(str(finding.severity).upper())
        occurrences = finding.occurrences or [
            {
                "file": finding.file,
                "start_line": finding.start_line,
                "end_line": finding.end_line,
            }
        ]
        for occurrence in occurrences:
            start_value = occurrence.get("start_line", finding.start_line)
            start_line = start_value if isinstance(start_value, int) else finding.start_line
            end_value = occurrence.get("end_line")
            end_line = int(end_value) if isinstance(end_value, int) else None
            start_column, end_column = _occurrence_columns(finding, occurrence)
            results.append(
                SarifResult(
                    ruleId=finding.rule_id,
                    message=SarifMessage(text=finding.message),
                    level=_severity_to_sarif_level(finding.severity),
                    properties=_build_sarif_properties(finding, occurrence),
                    locations=[
                        SarifLocation(
                            physicalLocation=SarifPhysicalLocation(
                                artifactLocation=_sarif_artifact_location(finding, occurrence),
                                region=SarifRegion(
                                    startLine=start_line,
                                    endLine=end_line,
                                    startColumn=start_column + 1
                                    if start_column is not None
                                    else None,
                                    endColumn=end_column + 1 if end_column is not None else None,
                                ),
                            )
                        )
                    ],
                    suppressions=[SarifSuppression(kind="external", justification=sf.reason)],
                )
            )
        if finding.rule_id not in seen_rule_ids:
            seen_rule_ids[finding.rule_id] = finding.message

    rules = []
    for rule_id, description in sorted(seen_rule_ids.items()):
        # A rule carries security-severity only when every reported finding
        # for it shares one severity; mixed-severity rules stay unannotated
        # rather than mislabeling some of their results.
        rule_properties: dict[str, object] | None = None
        severities = seen_rule_severities.get(rule_id, set())
        if len(severities) == 1:
            score = _severity_to_security_severity(next(iter(severities)))
            if score is not None:
                rule_properties = {"security-severity": score}
        rules.append(
            SarifReportingDescriptor(
                id=rule_id,
                shortDescription=SarifMessage(text=description),
                properties=rule_properties,
            )
        )

    completeness = analysis_completeness or {}

    def nonnegative_count(key: str) -> int:
        value = completeness.get(key, 0)
        return max(0, value) if isinstance(value, int) and not isinstance(value, bool) else 0

    raw_ledger_exceptions = completeness.get("ledger_exceptions", [])
    raw_scope_exclusions = completeness.get("scope_exclusions", [])
    raw_limitations = completeness.get("limitations", [])
    ledger_exception_count = (
        sum(1 for item in raw_ledger_exceptions if isinstance(item, Mapping))
        if isinstance(raw_ledger_exceptions, list)
        else 0
    )
    scope_exclusion_count = (
        sum(1 for item in raw_scope_exclusions if isinstance(item, Mapping))
        if isinstance(raw_scope_exclusions, list)
        else 0
    )
    limitation_count = len(raw_limitations) if isinstance(raw_limitations, list) else 0
    fully_inspected = nonnegative_count("fully_inspected_files")
    partially_inspected = nonnegative_count("partially_inspected_files")
    entirely_uninspected = nonnegative_count("entirely_uninspected_files")

    raw_status = completeness.get("status")
    requested_status = (
        raw_status
        if isinstance(raw_status, str)
        and raw_status in {"complete", "complete_with_caveats", "partial", "failed"}
        else None
    )
    reference_caveat_only = only_missing_reference_exceptions(raw_ledger_exceptions)
    is_complete = (
        completeness.get("is_complete", True) is True
        and requested_status in {None, "complete", "complete_with_caveats"}
        and execution_successful
        and partially_inspected == 0
        and entirely_uninspected == 0
        and (ledger_exception_count == 0 or reference_caveat_only)
        and limitation_count == 0
    )
    status = (
        requested_status
        if is_complete and requested_status == "complete_with_caveats"
        else "complete"
        if is_complete
        else "failed"
        if not execution_successful or requested_status == "failed"
        else "partial"
    )
    raw_coverage = completeness.get("coverage_percent", 100.0 if is_complete else 0.0)
    coverage = (
        float(raw_coverage)
        if isinstance(raw_coverage, (int, float))
        and not isinstance(raw_coverage, bool)
        and 0.0 <= float(raw_coverage) <= 100.0
        else 0.0
    )
    completeness_projection: dict[str, object] = {
        "isComplete": is_complete,
        "status": status,
        "coveragePercent": coverage,
        "totalComponents": nonnegative_count("total_components"),
        "fullyInspectedFiles": fully_inspected,
        "partiallyInspectedFiles": partially_inspected,
        "entirelyUninspectedFiles": entirely_uninspected,
        # Counts are a deliberately payload-free projection. Detailed, sanitized
        # exceptions remain represented as bounded SARIF notifications below.
        "ledgerExceptionCount": ledger_exception_count,
        "scopeExclusionCount": scope_exclusion_count,
        "limitationCount": limitation_count,
        "notificationRecordLimit": MAX_FINDING_OUTPUT_RECORDS,
        "notificationsTruncated": False,
    }
    if completeness.get("warnings"):
        completeness_projection["acceptedByPolicy"] = format_recovery_policy_accepted(completeness)
        completeness_projection["assessmentComplete"] = False

    if completeness.get("exclude_patterns"):
        completeness_projection["excludePatterns"] = completeness["exclude_patterns"]
        completeness_projection["excludedFileCount"] = nonnegative_count("excluded_file_count")

    notifications: list[SarifNotification] = []
    observed_notifications = 0
    notifications_truncated = False

    def append_notification(notification: SarifNotification) -> None:
        nonlocal observed_notifications, notifications_truncated
        observed_notifications += 1
        if len(notifications) < MAX_FINDING_OUTPUT_RECORDS:
            notifications.append(notification)
        else:
            notifications_truncated = True

    for summary in structured_summaries or []:
        append_notification(
            SarifNotification(
                message=SarifMessage(text=_structured_summary_notification(summary)),
                level="note",
                properties={"kind": "structured_summary"},
            )
        )

    def notification_from_exception(
        exception: Mapping[str, object], level: Literal["error", "warning", "note"]
    ) -> SarifNotification:
        path = str(exception.get("path", ""))
        start_line, end_line = _inspection_exception_lines(exception)
        scope = exception.get("scope")
        locations = None
        # A rule-set row's path is a label, not an artifact; giving it a
        # physical location would attribute it to any real file of that name.
        if path and not scope:
            region = (
                SarifRegion(
                    startLine=int(start_line),
                    endLine=int(end_line) if isinstance(end_line, int) else None,
                )
                if isinstance(start_line, int)
                else None
            )
            locations = [
                SarifLocation(
                    physicalLocation=SarifPhysicalLocation(
                        artifactLocation=SarifArtifactLocation(uri=quote(path, safe="/!")),
                        region=region,
                    )
                )
            ]
        properties: dict[str, object] = {
            "outcome": str(exception.get("outcome", "")),
            "phase": str(exception.get("phase", "")),
            "reasonCode": str(exception.get("reason_code", "")),
        }
        if exception.get("fatal") is not None:
            properties["fatal"] = bool(exception["fatal"])
        if scope:
            properties["scope"] = str(scope)
        analyzers = exception.get("analyzers")
        if isinstance(analyzers, list):
            properties["analyzers"] = list(analyzers)
        if exception.get("phase") == "documentation":
            properties["kind"] = "documentation_pattern_notice"
        for key, value in resource_measurements(exception).items():
            prefix, _, unit = key.partition("_")
            properties[prefix + unit.capitalize()] = value
        diagnostic = sanitize_parser_diagnostic(exception.get("parser_diagnostic"))
        if diagnostic is not None:
            properties["parserDiagnostic"] = dict(diagnostic)
        return SarifNotification(
            message=SarifMessage(text=_inspection_exception_message(exception)),
            level=level,
            locations=locations,
            properties=properties,
        )

    raw_ledger_exceptions = completeness.get("ledger_exceptions", [])
    ledger_exceptions = (
        [item for item in raw_ledger_exceptions if isinstance(item, Mapping)]
        if isinstance(raw_ledger_exceptions, list)
        else []
    )
    # Fatal execution facts retain highest priority. The degradation notice
    # then precedes its non-fatal canonical runtime detail, preserving the
    # established first-notification contract without hiding fatal failures.
    for exception in ledger_exceptions:
        if exception.get("fatal"):
            append_notification(notification_from_exception(exception, "error"))
    if degraded_notice:
        append_notification(
            SarifNotification(
                message=SarifMessage(text=degraded_notice),
                level="warning",
                properties={"kind": "llm_degradation"},
            )
        )
    scope_exclusions = completeness.get("scope_exclusions", [])
    if isinstance(scope_exclusions, list):
        for exception in scope_exclusions:
            if isinstance(exception, Mapping):
                append_notification(notification_from_exception(exception, "note"))
    for exception in ledger_exceptions:
        if not exception.get("fatal"):
            append_notification(notification_from_exception(exception, "warning"))
    limitations = completeness.get("limitations", [])
    if isinstance(limitations, list):
        for limitation in limitations:
            append_notification(
                SarifNotification(
                    message=SarifMessage(text=str(limitation)),
                    level="warning",
                    properties={"kind": "inspection_limitation"},
                )
            )
    notices = completeness.get("notices", [])
    if isinstance(notices, list):
        for notice in notices:
            if isinstance(notice, Mapping):
                append_notification(notification_from_exception(notice, "note"))
    if notifications_truncated:
        completeness_projection["notificationsTruncated"] = True
        sentinel = SarifNotification(
            message=SarifMessage(text="Inspection notifications reached the output limit."),
            level="warning",
            properties={
                "kind": "inspection_notification_limit",
                "reasonCode": "output_limit",
                "observedRecords": observed_notifications,
                "limitRecords": MAX_FINDING_OUTPUT_RECORDS,
            },
        )
        # Replace one detailed record so the bounded output always carries the
        # explicit truncation fact.
        if notifications:
            notifications[-1] = sentinel
    invocations = [
        SarifInvocation(
            executionSuccessful=execution_successful,
            toolExecutionNotifications=notifications or None,
            properties={"analysisCompleteness": completeness_projection},
        )
    ]

    sarif_log = SarifLog.model_validate(
        {
            "$schema": SARIF_SCHEMA_URI,
            "runs": [
                SarifRun(
                    tool=SarifTool(
                        driver=SarifDriver(
                            name="skillspector",
                            version=skillspector_version,
                            rules=rules if rules else None,
                        )
                    ),
                    results=results,
                    columnKind="unicodeCodePoints",
                    invocations=invocations,
                    properties={"inputOrigin": origin} if origin is not None else None,
                )
            ],
        }
    )
    rendered = cast(
        dict[str, object], sarif_log.model_dump(mode="json", by_alias=True, exclude_none=True)
    )
    validate_sarif_report(rendered)
    return rendered


def _terminal_text(value: object, style: str = "") -> Text:
    """Keep dynamic text literal and render its non-printable characters visibly."""
    return Text(visible_terminal_text(str(value)), style=style)


def _render_terminal_completeness(
    console: Console,
    completeness: Mapping[str, object],
    execution_successful: bool,
) -> None:
    """Render every public completeness record without leaking internal work IDs."""
    console.print()
    table = Table(title="Inspection Completeness", show_header=False, box=None)
    table.add_column("Metric", style="bold")
    table.add_column("Value")
    table.add_row("Execution", "successful" if execution_successful else "failed")
    table.add_row("Status", _terminal_text(completeness.get("status", "complete")))
    if format_recovery_policy_accepted(completeness):
        table.add_row(
            "Formatting policy", "Accepted with warning; AI assessment remains incomplete"
        )
    dependency_inspection = completeness.get("dependency_inspection")
    if isinstance(dependency_inspection, dict):
        table.add_row("Dependency contents", _terminal_text(dependency_inspection.get("status")))
    table.add_row("Coverage", _terminal_text(f"{completeness.get('coverage_percent', 100.0)}%"))
    table.add_row("Fully inspected", _terminal_text(completeness.get("fully_inspected_files", 0)))
    table.add_row(
        "Partially inspected", _terminal_text(completeness.get("partially_inspected_files", 0))
    )
    table.add_row(
        "Entirely uninspected", _terminal_text(completeness.get("entirely_uninspected_files", 0))
    )
    if completeness.get("exclude_patterns"):
        table.add_row(
            "Explicit exclusion patterns",
            _terminal_text(", ".join(completeness["exclude_patterns"])),
        )
        table.add_row(
            "Excluded files (not inspected)",
            _terminal_text(completeness.get("excluded_file_count", 0)),
        )
    console.print(table)

    def render_rows(title: str, rows: object) -> None:
        if not isinstance(rows, list) or not rows:
            return
        console.print(_terminal_text(title, "bold"))
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            # Analyzer status rows name an analyzer rather than a file.
            location = str(row.get("path") or row.get("analyzer_id") or "")
            start_line, end_line = _inspection_exception_lines(row)
            if isinstance(start_line, int):
                location += f":{start_line}" + (f"-{end_line}" if end_line else "")
            if row.get("scope") == RULE_SET_SCOPE:
                # The path of a rule-set row is a label, not an artifact.
                location = f"rule set {location}"
            reason = str(row.get("reason_code", row.get("status", "status")))
            message = _inspection_exception_message(row)
            console.print(_terminal_text(f"  - {reason} {location}: {message}"))

    render_rows("Scope exclusions", completeness.get("scope_exclusions"))
    render_rows("Ledger exceptions", completeness.get("ledger_exceptions"))
    render_rows("Formatting recovery warnings", completeness.get("warnings"))
    render_rows("Inspection notices", completeness.get("notices"))
    render_rows("Analyzer statuses", completeness.get("analyzer_statuses"))
    limitations = completeness.get("limitations")
    if isinstance(limitations, list) and limitations:
        console.print("[bold]Limitations[/bold]")
        for limitation in limitations:
            console.print(_terminal_text(f"  - {limitation}"))


def _format_terminal(
    findings: list[Finding],
    component_metadata: list[dict[str, object]],
    manifest: dict[str, object],
    skill_path: str | None,
    risk_score: int,
    risk_severity: str,
    risk_recommendation: str,
    has_executable_scripts: bool,
    use_llm: bool = True,
    llm_call_log: Sequence[Mapping[str, object]] | None = None,
    degraded_notice: str | None = None,
    suppressed: list[SuppressedFinding] | None = None,
    structured_summaries: list[dict[str, object]] | None = None,
    show_suppressed: bool = False,
    analysis_completeness: Mapping[str, object] | None = None,
    execution_successful: bool = True,
    origin: dict[str, str] | None = None,
) -> str:
    """Generate styled Rich output with literal, control-safe dynamic text."""
    suppressed = suppressed or []
    console = Console(record=True, force_terminal=True, width=80, file=StringIO(), emoji=False)
    skill_name = (manifest.get("name") or "unknown") if manifest else "unknown"
    source = skill_path or ""

    console.print()
    console.print(
        Panel(
            "[bold]SkillSpector Security Report[/bold]",
            subtitle=f"v{skillspector_version}",
        )
    )
    console.print(Text.assemble("\n", ("Skill: ", "bold"), _terminal_text(skill_name)))
    console.print(Text.assemble(("Source: ", "bold"), _terminal_text(source)))
    if origin is not None:
        console.print(Text.assemble(("Input origin: ", "bold"), _terminal_text(origin["source"])))
        console.print(Text.assemble(("Input type: ", "bold"), _terminal_text(origin["type"])))
    console.print(f"[bold]Scanned:[/bold] {datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S UTC')}")

    severity_colors = {
        "LOW": "green",
        "MEDIUM": "yellow",
        "HIGH": "red",
        "CRITICAL": "bold red",
    }
    color = severity_colors.get(risk_severity, "yellow")
    console.print("\n")
    risk_table = Table(title="Risk Assessment", show_header=False, box=None)
    risk_table.add_column("Metric", style="bold")
    risk_table.add_column("Value")
    risk_table.add_row("Score", f"[{color}]{risk_score}/100[/{color}]")
    risk_table.add_row("Severity", f"[{color}]{risk_severity}[/{color}]")
    risk_table.add_row(
        "Recommendation", f"[{color}]{risk_recommendation.replace('_', ' ')}[/{color}]"
    )
    console.print(risk_table)

    console.print("\n")
    comp_table = Table(title=f"Components ({len(component_metadata)})")
    comp_table.add_column("File", style="cyan")
    comp_table.add_column("Type")
    comp_table.add_column("Lines", justify="right")
    comp_table.add_column("Executable")
    for comp in component_metadata[:15]:
        path = str(comp.get("path", ""))
        typ = str(comp.get("type", ""))
        lines = comp.get("lines", 0)
        exec_flag = comp.get("executable", False)
        exec_marker = "[yellow]Yes[/yellow]" if exec_flag else "No"
        comp_table.add_row(
            _terminal_text(path), _terminal_text(typ), _terminal_text(lines), exec_marker
        )
    if len(component_metadata) > 15:
        comp_table.add_row(f"... and {len(component_metadata) - 15} more", "", "", "")
    console.print(comp_table)

    effective_degraded_notice = degraded_notice or _llm_degradation_notice(
        use_llm, llm_call_log or []
    )
    if effective_degraded_notice:
        console.print()
        console.print(
            Panel(
                Text.assemble(
                    ("Degraded scan\n", "bold"), _terminal_text(effective_degraded_notice)
                ),
                title="[bold red]WARNING[/bold red]",
                border_style="red",
            )
        )

    if findings:
        console.print("\n")
        console.print(f"[bold]Issues ({len(findings)})[/bold]\n")
        severity_icons = {
            "LOW": Text("LOW", style="green"),
            "MEDIUM": Text("MEDIUM", style="yellow"),
            "HIGH": Text("HIGH", style="red"),
            "CRITICAL": Text("CRITICAL", style="bold red"),
        }
        for f in findings:
            icon = severity_icons.get(
                (f.severity or "LOW").upper(), _terminal_text(f.severity or "")
            )
            console.print(
                Text.assemble(
                    "  ",
                    icon,
                    ": ",
                    _terminal_text(f.rule_id),
                    " - ",
                    _terminal_text(f.message[:60]),
                    "...",
                )
            )
            end = f"–{f.end_line}" if f.end_line and f.end_line != f.start_line else ""
            console.print(
                Text.assemble(
                    ("    Location: ", "dim"), _terminal_text(f.file), f":{f.start_line}{end}"
                )
            )
            if f.source_url:
                console.print(
                    Text.assemble(
                        ("    Source: ", "dim"),
                        _terminal_text(f.source_url),
                        f" (depth {f.transitive_depth})",
                    )
                )
            console.print(f"    [dim]Confidence:[/dim] {f.confidence:.0%}")
            if f.remediation:
                console.print(
                    Text.assemble(
                        ("    Remediation: ", "dim"), _terminal_text(f.remediation[:150]), "..."
                    )
                )
            if f.evidence:
                rendered = ", ".join(f"{key}={value}" for key, value in sorted(f.evidence.items()))
                console.print(Text.assemble(("    Evidence: ", "dim"), _terminal_text(rendered)))
            console.print()
    else:
        console.print("\n[green]No security issues detected.[/green]\n")

    if structured_summaries:
        console.print("\n")
        console.print(f"[bold]Structured Skill Summary ({len(structured_summaries)})[/bold]\n")
        for summary in structured_summaries:
            console.print(
                Text.assemble(
                    "  ",
                    _terminal_text(summary.get("id", "SSR-1"), "cyan"),
                    ": ",
                    _terminal_text(summary.get("message", "")),
                )
            )
            file = _summary_display_value(summary.get("file"))
            if file:
                console.print(Text.assemble(("    File: ", "dim"), _terminal_text(file)))
            for key, label in (
                ("protocol", "Protocol"),
                ("layout_kind", "Layout"),
                ("declared_tools", "Declared tools"),
                ("workflow_nodes", "Workflow nodes"),
                ("constraints", "Constraints"),
                ("resources", "Resources"),
                ("tags", "Tags"),
            ):
                value = _summary_display_value(summary.get(key))
                if value:
                    console.print(Text.assemble((f"    {label}: ", "dim"), _terminal_text(value)))
            console.print()

    if suppressed:
        console.print(
            f"[dim]Suppressed by baseline: {len(suppressed)} (not counted toward risk score)[/dim]"
        )
        if show_suppressed:
            for sf in suppressed:
                f = sf.finding
                console.print(
                    Text.assemble(
                        "  - ",
                        _terminal_text(f.rule_id),
                        " ",
                        _terminal_text(f.file),
                        f":{f.start_line} (reason: ",
                        _terminal_text(sf.reason),
                        ")",
                        style="dim",
                    )
                )
        else:
            console.print("[dim]Use --show-suppressed to list them.[/dim]")
        console.print()

    _render_terminal_completeness(
        console,
        analysis_completeness or {},
        execution_successful,
    )
    console.print(f"[dim]Executable scripts: {'Yes' if has_executable_scripts else 'No'}[/dim]")
    return cast(str, console.export_text())


def _llm_runtime_status(
    use_llm: bool, llm_call_log: Sequence[Mapping[str, object]]
) -> tuple[int, int, bool]:
    """Return ``(attempted, succeeded, degraded)`` from the LLM call log.

    ``degraded`` is True when the LLM stage was requested and at least one call
    was attempted, but not every call succeeded: a dropped or throttled batch
    (e.g. a 429) leaves the same coverage gap as a full failure, so a partial
    pass is degraded too, not just a total one.
    """
    attempted = len(llm_call_log)
    succeeded = sum(1 for record in llm_call_log if successful_llm_record(record))
    degraded = bool(use_llm and attempted > 0 and succeeded < attempted)
    return attempted, succeeded, degraded


def _llm_degradation_notice(
    use_llm: bool, llm_call_log: Sequence[Mapping[str, object]]
) -> str | None:
    """Return a human-readable degraded-scan warning, or None if not degraded."""
    attempted, succeeded, degraded = _llm_runtime_status(use_llm, llm_call_log)
    if not degraded:
        return None
    failed = attempted - succeeded
    return (
        f"LLM analysis was requested but {failed} of {attempted} LLM call(s) failed - "
        "affected AI assessments are incomplete; completed results are retained."
    )


def _build_metadata(
    has_executable_scripts: bool,
    use_llm: bool,
    llm_call_log: Sequence[Mapping[str, object]] | None = None,
    inference_usage: Sequence[Mapping[str, object]] | None = None,
    llm_provenance: object = None,
    transitive_targets_scanned: int | None = None,
    transitive_bytes_scanned: int | None = None,
    transitive_truncation_reasons: Sequence[str] | None = None,
    llm_execution_enabled: bool | None = None,
    semantic_runtime_incomplete: bool = False,
    runtime_available: bool | None = None,
    provider_availability: tuple[bool, str | None] | None = None,
) -> dict[str, object]:
    """Build the metadata section shared by all output formats."""
    llm_call_log = llm_call_log or []
    provider_available, llm_error = (
        provider_availability
        if provider_availability is not None
        else is_llm_available()
        if use_llm
        else (False, None)
    )
    llm_error = redact_llm_error(llm_error)
    attempted, succeeded, call_log_degraded = _llm_runtime_status(use_llm, llm_call_log)
    # meta_analyzer's own record, independent of whether a DIFFERENT
    # LLM-backed node (a semantic_* analyzer) lost coverage to a dropped
    # batch. A missing record means meta_analyzer never ran (e.g. there were
    # no findings to filter), which is not itself a failure, so it reads as
    # vacuously ok for llm_available (provider/runtime truth). When it does
    # run it always emits exactly one record.
    meta_analyzer_records = [r for r in llm_call_log if r.get("node") == "meta_analyzer"]
    meta_analyzer_ok = all(successful_llm_record(record) for record in meta_analyzer_records)
    # meta_analysis_applied is stricter: "did meta-analysis actually run"
    # cannot be satisfied vacuously. all([]) is True on an empty list, so
    # meta_analyzer_ok alone is also True when meta_analyzer made no call at
    # all (the no-findings path) - require at least one record, and that
    # record must have succeeded.
    meta_analyzer_succeeded = bool(meta_analyzer_records) and meta_analyzer_ok
    effective_runtime_available = (
        provider_available and meta_analyzer_ok if runtime_available is None else runtime_available
    )

    # meta_analysis_applied / llm_available answer different questions.
    # llm_available is provider availability: the binary/credentials were
    # available AND meta_analyzer's own call (if it ran) succeeded - it stays
    # vacuously true when meta_analyzer never ran, because the provider being
    # reachable does not depend on there being findings to filter.
    # meta_analysis_applied is "did meta-analysis itself run", which needs an
    # actual successful meta_analyzer record, not just the absence of a
    # failure. A different analyzer's partial batch loss is a coverage gap,
    # reported separately below via llm_degraded / llm_calls_attempted /
    # llm_calls_succeeded, and must not flip these two fields on its own -
    # that would conflate two independent contracts (meta-analysis ran vs.
    # some coverage was lost) into one boolean.
    execution_enabled = use_llm if llm_execution_enabled is None else llm_execution_enabled
    unavailable_before_execution = bool(use_llm and not execution_enabled)
    response_observed = any(
        isinstance(record, Mapping) and record.get("usage_source") == "provider_response"
        for record in inference_usage or []
    )
    # Enablement alone does not prove execution: every analyzer may have
    # returned not_applicable. Failed attempts still count, as do successful
    # provider responses whose transport supplied no token counters.
    llm_executed = bool(use_llm and execution_enabled and (attempted or response_observed))
    meta_analysis_applied = (
        use_llm and execution_enabled and provider_available and meta_analyzer_succeeded
    )

    sanitized_inference_usage = sanitize_inference_usage(inference_usage)
    meta: dict[str, object] = {
        "has_executable_scripts": has_executable_scripts,
        "skillspector_version": skillspector_version,
        "distribution_build": {
            "project": "QingNagi/skill_for_integrator",
            "revision": "zipreview.1",
            "upstream_commit": "c323ad4c43e3c8f2de051572cc25b2711d11e648",
        },
        "llm_requested": use_llm,
        # llm_available reflects runtime truth: the binary/credentials were
        # available AND meta_analyzer's own call (if it ran) succeeded.
        "llm_available": (effective_runtime_available and not unavailable_before_execution),
        "meta_analysis_applied": meta_analysis_applied,
        # A list (including an empty list) makes observability explicit. Empty
        # means the provider/transport supplied no counters; it is never an
        # estimated zero-cost assertion.
        "inference_usage": sanitized_inference_usage,
        "llm_provenance": sanitize_llm_provenance(
            llm_provenance,
            use_llm=llm_executed,
            # Counter-less responses and constructor controls are internal
            # provenance evidence. The public inference_usage projection above
            # intentionally omits both, so provenance must inspect the raw
            # records and apply its own fixed-field sanitizer.
            inference_usage=inference_usage,
        ),
    }
    if not meta_analysis_applied:
        meta["filtering_mode"] = "heuristic"
    if use_llm and attempted:
        meta["llm_calls_attempted"] = attempted
        meta["llm_calls_succeeded"] = succeeded
    if unavailable_before_execution:
        detail = f" Reason: {llm_error}" if llm_error else ""
        meta["llm_error"] = (
            "LLM analysis was requested but unavailable during preflight; "
            f"results reflect static analysis only.{detail}"
        )
    elif call_log_degraded:
        meta["llm_degraded"] = True
        reasons = sorted(
            {
                str(record.get("error"))
                for record in llm_call_log
                if not successful_llm_record(record) and record.get("error")
            }
        )
        detail = f" Reasons: {'; '.join(reasons)}" if reasons else ""
        meta["llm_error"] = f"{_llm_degradation_notice(use_llm, llm_call_log)}{detail}"
    elif semantic_runtime_incomplete:
        meta["llm_degraded"] = True
        meta["llm_error"] = (
            "LLM analysis was requested but semantic runtime telemetry was incomplete; "
            "results may reflect static analysis only."
        )
    elif use_llm and not provider_available:
        meta["llm_error"] = llm_error
    if transitive_targets_scanned is not None:
        meta["transitive_targets_scanned"] = transitive_targets_scanned
    if transitive_bytes_scanned is not None:
        meta["transitive_bytes_scanned"] = transitive_bytes_scanned
    if transitive_truncation_reasons:
        meta["transitive_truncated"] = True
        meta["transitive_truncation_reasons"] = list(transitive_truncation_reasons)
    return meta


def _json_component(component: Mapping[str, object]) -> dict[str, object]:
    """Preserve component identity and expose structured archive provenance."""
    result = {
        key: component.get(key)
        for key in (
            "path",
            "type",
            "lines",
            "executable",
            "size_bytes",
            "source_url",
            "source_identity",
            "source_digest",
        )
    }
    outer_path = component.get("outer_path")
    nested_path = component.get("nested_path")
    if (
        isinstance(outer_path, str)
        and outer_path
        and isinstance(nested_path, str)
        and nested_path
        and component.get("path") == f"{outer_path}!/{nested_path}"
    ):
        result.update(outer_path=outer_path, nested_path=nested_path)
        container_type = component.get("container_type")
        if isinstance(container_type, str) and container_type:
            result["container_type"] = container_type
        depth = component.get("container_depth")
        if isinstance(depth, int) and not isinstance(depth, bool) and depth > 0:
            result["container_depth"] = depth
        ancestry = component.get("container_ancestry")
        if isinstance(ancestry, list) and all(isinstance(item, str) and item for item in ancestry):
            result["container_ancestry"] = list(ancestry)
    return result


def _format_json(
    findings: list[Finding],
    component_metadata: list[dict[str, object]],
    manifest: dict[str, object],
    skill_path: str | None,
    risk_score: int,
    risk_severity: str,
    risk_recommendation: str,
    has_executable_scripts: bool,
    use_llm: bool = True,
    llm_call_log: Sequence[Mapping[str, object]] | None = None,
    inference_usage: Sequence[Mapping[str, object]] | None = None,
    llm_provenance: object = None,
    analysis_completeness: Mapping[str, object] | None = None,
    suppressed: list[SuppressedFinding] | None = None,
    execution_successful: bool = True,
    transitive_targets_scanned: int | None = None,
    transitive_bytes_scanned: int | None = None,
    transitive_truncation_reasons: Sequence[str] | None = None,
    structured_summaries: list[dict[str, object]] | None = None,
    llm_execution_enabled: bool | None = None,
    semantic_runtime_incomplete: bool = False,
    runtime_available: bool | None = None,
    provider_availability: tuple[bool, str | None] | None = None,
    origin: dict[str, str] | None = None,
) -> str:
    """Generate JSON report string."""
    suppressed = suppressed or []
    skill_name = (manifest.get("name") or "unknown") if manifest else "unknown"
    data: dict[str, object] = {
        "skill": {
            "name": skill_name,
            "source": skill_path or "",
            "scanned_at": datetime.now(UTC).isoformat(),
            **({"origin": origin} if origin is not None else {}),
        },
        "risk_assessment": {
            "score": risk_score,
            "severity": risk_severity,
            "recommendation": risk_recommendation,
            "max_issue_severity": _max_issue_severity(findings),
        },
        "components": [_json_component(component) for component in component_metadata],
        "structured_summaries": structured_summaries or [],
        "issues": [f.to_dict() for f in findings],
        "suppressed_count": len(suppressed),
        "suppressed": [sf.to_dict() for sf in suppressed],
        "metadata": _build_metadata(
            has_executable_scripts,
            use_llm,
            llm_call_log,
            inference_usage,
            llm_provenance,
            transitive_targets_scanned,
            transitive_bytes_scanned,
            transitive_truncation_reasons,
            llm_execution_enabled,
            semantic_runtime_incomplete,
            runtime_available,
            provider_availability,
        ),
        "execution_successful": execution_successful,
    }
    data["analysis_completeness"] = dict(analysis_completeness or {})
    completeness = analysis_completeness or {}
    recovery_warnings = completeness.get("warnings")
    if isinstance(recovery_warnings, list) and recovery_warnings:
        metadata = cast(dict[str, object], data["metadata"])
        metadata["llm_assessment_complete"] = False
        metadata["llm_recovery_policy_accepted"] = format_recovery_policy_accepted(completeness)
        if any(
            isinstance(warning, Mapping) and warning.get("phase") == "meta"
            for warning in recovery_warnings
        ):
            metadata["meta_analysis_applied"] = False
    return json.dumps(data, indent=2)


def _markdown_plain_text(value: object) -> str:
    """Remove display controls and keep a Markdown field on one line."""
    text = _clean_text(str(value)) or ""
    return " ".join("".join(c for c in text if c.isprintable() or c.isspace()).splitlines())


def _markdown_cell(value: object) -> str:
    """Render dynamic prose as literal text on one Markdown line."""
    text = escape_html(_markdown_plain_text(value), quote=False)
    return re.sub(r"([\\`*_{}\[\]()#+.!|>~-])", r"\\\1", text)


def _markdown_code(value: object, *, table_cell: bool = False) -> str:
    """Keep literal values inside their code spans and table cells."""
    text = _markdown_plain_text(value)
    if table_cell:
        text = text.replace("|", "\\|")
    delimiter = "`" * (max((len(run) for run in re.findall(r"`+", text)), default=0) + 1)
    padding = " " if text.startswith(("`", " ")) or text.endswith(("`", " ")) else ""
    return f"{delimiter}{padding}{text}{padding}{delimiter}"


def _render_markdown_completeness(
    lines: list[str],
    completeness: Mapping[str, object],
    execution_successful: bool,
) -> None:
    """Append the full public completeness projection to a Markdown report."""
    lines.append("## Inspection Completeness\n")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Execution | {'successful' if execution_successful else 'failed'} |")
    lines.append(f"| Status | {_markdown_cell(completeness.get('status', 'complete'))} |")
    if format_recovery_policy_accepted(completeness):
        lines.append(
            "| Formatting policy | Accepted with warning; AI assessment remains incomplete |"
        )
    dependency_inspection = completeness.get("dependency_inspection")
    if isinstance(dependency_inspection, dict):
        lines.append(
            f"| Dependency contents | {_markdown_cell(dependency_inspection.get('status'))} |"
        )
    lines.append(f"| Coverage | {_markdown_cell(completeness.get('coverage_percent', 100.0))}% |")
    lines.append(
        f"| Fully inspected | {_markdown_cell(completeness.get('fully_inspected_files', 0))} |"
    )
    lines.append(
        f"| Partially inspected | {_markdown_cell(completeness.get('partially_inspected_files', 0))} |"
    )
    lines.append(
        f"| Entirely uninspected | {_markdown_cell(completeness.get('entirely_uninspected_files', 0))} |"
    )
    lines.append("")

    patterns = completeness.get("exclude_patterns", [])
    if patterns:
        spans = [_markdown_code(pattern) for pattern in patterns]
        lines.append(f"Explicit exclusion patterns: {', '.join(spans)}\n")
        lines.append(
            f"Excluded files (not inspected): {completeness.get('excluded_file_count', 0)}\n"
        )

    def render_rows(title: str, rows: object) -> None:
        if not isinstance(rows, list) or not rows:
            return
        lines.append(f"### {title}\n")
        lines.append("| Reason / Status | Location | Details |")
        lines.append("|-----------------|----------|---------|")
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            # Analyzer status rows name an analyzer rather than a file.
            location = str(row.get("path") or row.get("analyzer_id") or "")
            start_line, end_line = _inspection_exception_lines(row)
            if isinstance(start_line, int):
                location += f":{start_line}" + (f"-{end_line}" if end_line else "")
            reason = row.get("reason_code", row.get("status", "status"))
            location_cell = _markdown_code(location, table_cell=True)
            if row.get("scope") == RULE_SET_SCOPE:
                # The path of a rule-set row is a label, not an artifact.
                location_cell = f"rule set {location_cell}"
            lines.append(
                f"| {_markdown_cell(reason)} | {location_cell} | "
                f"{_markdown_cell(_inspection_exception_message(row))} |"
            )
        lines.append("")

    render_rows("Scope Exclusions", completeness.get("scope_exclusions"))
    render_rows("Ledger Exceptions", completeness.get("ledger_exceptions"))
    render_rows("Formatting Recovery Warnings", completeness.get("warnings"))
    render_rows("Inspection Notices", completeness.get("notices"))
    render_rows("Analyzer Statuses", completeness.get("analyzer_statuses"))
    limitations = completeness.get("limitations")
    if isinstance(limitations, list) and limitations:
        lines.append("### Limitations\n")
        for limitation in limitations:
            lines.append(f"- {_markdown_cell(limitation)}")
        lines.append("")


def _format_markdown(
    findings: list[Finding],
    component_metadata: list[dict[str, object]],
    manifest: dict[str, object],
    skill_path: str | None,
    risk_score: int,
    risk_severity: str,
    risk_recommendation: str,
    has_executable_scripts: bool,
    use_llm: bool = True,
    llm_call_log: Sequence[Mapping[str, object]] | None = None,
    degraded_notice: str | None = None,
    suppressed: list[SuppressedFinding] | None = None,
    structured_summaries: list[dict[str, object]] | None = None,
    show_suppressed: bool = False,
    analysis_completeness: Mapping[str, object] | None = None,
    execution_successful: bool = True,
    origin: dict[str, str] | None = None,
) -> str:
    """Generate Markdown report string."""
    suppressed = suppressed or []
    lines: list[str] = []
    skill_name = (manifest.get("name") or "unknown") if manifest else "unknown"
    source = skill_path or ""

    lines.append("# SkillSpector Security Report\n")
    lines.append(f"**Skill:** {_markdown_cell(skill_name)}  ")
    lines.append(f"**Source:** {_markdown_code(source)}  ")
    if origin is not None:
        lines.append(f"**Input origin:** {_markdown_code(origin['source'])}  ")
        lines.append(f"**Input type:** {_markdown_cell(origin['type'])}  ")
    lines.append(f"**Scanned:** {datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S UTC')}  ")
    lines.append("")

    effective_degraded_notice = degraded_notice or _llm_degradation_notice(
        use_llm, llm_call_log or []
    )
    if effective_degraded_notice:
        lines.append(f"> ⚠️ **Degraded scan:** {_markdown_cell(effective_degraded_notice)}")
        lines.append("")

    lines.append("## Risk Assessment\n")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Score | {risk_score}/100 |")
    lines.append(f"| Severity | {_markdown_cell(risk_severity)} |")
    lines.append(f"| Recommendation | {_markdown_cell(risk_recommendation.replace('_', ' '))} |")
    lines.append("")

    lines.append(f"## Components ({len(component_metadata)})\n")
    lines.append("| File | Type | Lines | Executable |")
    lines.append("|------|------|-------|------------|")
    for comp in component_metadata:
        path = comp.get("path", "")
        typ = comp.get("type", "")
        line_count = comp.get("lines", 0)
        exec_flag = comp.get("executable", False)
        exec_marker = "Yes" if exec_flag else "No"
        lines.append(
            f"| {_markdown_code(path, table_cell=True)} | {_markdown_cell(typ)} | {line_count} | {exec_marker} |"
        )
    lines.append("")

    if structured_summaries:
        lines.append(f"## Structured Skill Summary ({len(structured_summaries)})\n")
        for summary in structured_summaries:
            lines.append(f"### {_markdown_cell(summary.get('id', 'SSR-1'))}\n")
            lines.append(f"**Message:** {_markdown_cell(summary.get('message', ''))}  ")
            file = _summary_display_value(summary.get("file"))
            if file:
                lines.append(f"**File:** {_markdown_code(file)}  ")
            for key, label in (
                ("protocol", "Protocol"),
                ("layout_kind", "Layout"),
                ("declared_tools", "Declared tools"),
                ("workflow_nodes", "Workflow nodes"),
                ("constraints", "Constraints"),
                ("resources", "Resources"),
                ("tags", "Tags"),
            ):
                value = _summary_display_value(summary.get(key))
                if value:
                    lines.append(f"**{label}:** {_markdown_cell(value)}  ")
            lines.append("")

    lines.append(f"## Issues ({len(findings)})\n")
    if not findings:
        lines.append("No security issues detected.\n")
    else:
        severity_emoji = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🔴", "CRITICAL": "🔴"}
        for f in findings:
            sev = (f.severity or "LOW").upper()
            emoji = severity_emoji.get(sev, "")
            lines.append(f"### {emoji} {_markdown_cell(sev)}: {_markdown_cell(f.rule_id)}\n")
            end = f"–{f.end_line}" if f.end_line and f.end_line != f.start_line else ""
            lines.append(f"**Location:** {_markdown_code(f'{f.file}:{f.start_line}{end}')}  ")
            if f.source_url:
                lines.append(f"**Source:** {_markdown_code(f.source_url)}  ")
                lines.append(f"**Transitive depth:** {f.transitive_depth}  ")
            lines.append(f"**Confidence:** {f.confidence:.0%}  ")
            lines.append("")
            lines.append(f"**Message:** {_markdown_cell(f.message)}")
            lines.append("")
            if f.remediation:
                lines.append(f"**Remediation:** {_markdown_cell(f.remediation)}")
                lines.append("")
            if f.evidence:
                lines.append("**Evidence:**")
                for key, evidence_value in sorted(f.evidence.items()):
                    lines.append(f"- **{_markdown_cell(key)}:** {_markdown_code(evidence_value)}")
                lines.append("")
            lines.append("---\n")

    if suppressed:
        lines.append(f"## Suppressed ({len(suppressed)})\n")
        lines.append(
            "These findings matched the baseline and are **not** counted toward the risk score.\n"
        )
        if show_suppressed:
            lines.append("| Rule | Location | Reason |")
            lines.append("|------|----------|--------|")
            for sf in suppressed:
                f = sf.finding
                reason = _markdown_cell(sf.reason)
                location = _markdown_code(f"{f.file}:{f.start_line}", table_cell=True)
                lines.append(f"| {_markdown_cell(f.rule_id)} | {location} | {reason} |")
            lines.append("")
        else:
            lines.append("_Run with `--show-suppressed` to list them._\n")

    _render_markdown_completeness(lines, analysis_completeness or {}, execution_successful)
    lines.append("## Metadata\n")
    lines.append(f"- **Executable Scripts:** {'Yes' if has_executable_scripts else 'No'}")
    lines.append(f"\n*Generated by SkillSpector v{skillspector_version}*")
    return "\n".join(lines)


def report(state: SkillspectorState) -> dict[str, object]:
    """Render canonical findings and the exceptional ledger projection.

    Finalization owns completeness derivation. The report node only selects the
    validated finding IDs, applies baseline suppression, and renders all surfaces.
    """
    clear_python_ast_cache(state.get("python_ast_cache_key"))
    raw_findings = state.get("findings")
    if raw_findings is None:
        # Preserve the public node contract for direct callers while ensuring
        # graph executions prefer the pre-meta canonical finding collection.
        raw_findings = state.get("filtered_findings", [])
    findings_by_id = {finding.finding_id: finding for finding in raw_findings}
    # Meta/LLM analysis can enrich canonical objects but cannot remove
    # deterministic findings from primary output.
    selected_findings = list(findings_by_id.values())
    selected_findings = [_sanitize_finding(finding) for finding in selected_findings]

    raw_structured_summaries = state.get("structured_summaries") or []
    structured_summaries = [
        _sanitize_structured_summary(summary)
        for summary in raw_structured_summaries
        if isinstance(summary, dict)
    ]

    empty_completeness: AnalysisCompleteness = {
        "total_components": 0,
        "scanned_components": 0,
        "coverage_percent": 100.0,
        "is_complete": True,
        "status": "complete",
        "execution_successful": True,
        "fully_inspected_files": 0,
        "partially_inspected_files": 0,
        "entirely_uninspected_files": 0,
        "ledger_exceptions": [],
        "scope_exclusions": [],
        "analyzer_statuses": [],
        "limitations": [],
    }
    supplied_completeness = state.get("analysis_completeness")
    analysis_completeness: Mapping[str, object] = (
        supplied_completeness if isinstance(supplied_completeness, Mapping) else empty_completeness
    )
    if "notices" in analysis_completeness:
        analysis_completeness = {
            **analysis_completeness,
            "notices": bounded_inspection_notices(analysis_completeness["notices"]),
        }
    execution_successful = bool(
        state.get("execution_successful", analysis_completeness.get("execution_successful", True))
    )
    component_metadata = state.get("component_metadata") or []
    file_cache = state.get("local_file_cache") or state.get("file_cache") or {}
    has_executable_scripts = state.get("has_executable_scripts", False)
    manifest = state.get("manifest") or {}
    skill_path = state.get("skill_path")
    raw_origin = state.get("input_origin")
    origin = None
    if (
        isinstance(raw_origin, dict)
        and isinstance(raw_origin.get("source"), str)
        and isinstance(raw_origin.get("type"), str)
        and raw_origin.get("type") in {"directory", "file", "zip", "git", "url"}
    ):
        origin = input_origin(raw_origin["source"], raw_origin["type"])
    output_format = state.get("output_format") or "sarif"
    llm_requested, use_llm = semantic_runtime_intent(state)
    raw_llm_call_log = state.get("llm_call_log")
    llm_call_log: list[Mapping[str, object]] = (
        [record for record in raw_llm_call_log if isinstance(record, Mapping)]
        if isinstance(raw_llm_call_log, list)
        else []
    )
    inference_usage = state.get("inference_usage") or []
    llm_provenance = state.get("llm_provenance")
    transitive_targets_scanned = state.get("transitive_targets_scanned")
    transitive_bytes_scanned = state.get("transitive_bytes_scanned")
    transitive_truncation_reasons = [
        str(reason)
        for reason in state.get("transitive_truncation_reasons", [])
        if isinstance(reason, str)
    ]
    _llm_used, semantic_runtime_complete = semantic_runtime_accounting(
        enabled=bool(llm_requested and use_llm),
        result=state,
        discovered_modules=ANALYZER_MODULES,
    )
    semantic_runtime_incomplete = bool(llm_requested and use_llm and not semantic_runtime_complete)
    runtime_event = semantic_runtime_ledger_event(
        requested=llm_requested,
        enabled=use_llm,
        result=state,
        discovered_modules=ANALYZER_MODULES,
    )
    raw_inspection_ledger = state.get("inspection_ledger")
    inspection_ledger = raw_inspection_ledger if isinstance(raw_inspection_ledger, list) else []
    if runtime_event is not None and not has_semantic_runtime_event(
        inspection_ledger, runtime_event
    ):
        finalized_state = dict(state)
        finalized_state["inspection_ledger"] = [*inspection_ledger, runtime_event]
        analysis_completeness, _effective_ids = finalize_ledger(finalized_state)
        execution_successful = bool(analysis_completeness["execution_successful"])
    if transitive_truncation_reasons:
        analysis_completeness = dict(analysis_completeness)
        raw_limitations = analysis_completeness.get("limitations")
        limitations = list(raw_limitations) if isinstance(raw_limitations, list) else []
        transitive_limitation = "Transitive traversal truncated: " + "; ".join(
            transitive_truncation_reasons
        )
        if transitive_limitation not in limitations:
            limitations.append(transitive_limitation)
        analysis_completeness["limitations"] = limitations
        if analysis_completeness.get("policy_accepted") is True:
            analysis_completeness["policy_accepted"] = False
            raw_warnings = analysis_completeness.get("warnings")
            if isinstance(raw_warnings, list):
                analysis_completeness["warnings"] = [
                    {**warning, "accepted_by_policy": False}
                    if isinstance(warning, Mapping)
                    else warning
                    for warning in raw_warnings
                ]
        analysis_completeness["is_complete"] = False
        if analysis_completeness.get("status", "complete") in {
            "complete",
            "complete_with_caveats",
        }:
            analysis_completeness["status"] = "partial"
    _attempted, _succeeded, degraded = _llm_runtime_status(llm_requested, llm_call_log)
    remaining = transitive_remaining_seconds(state)
    if not llm_requested:
        provider_available, provider_error = False, None
    elif not use_llm and "llm_preflight_error" in state:
        provider_available = False
        provider_error = redact_llm_error(state.get("llm_preflight_error"))
    elif remaining is not None and remaining <= 0:
        provider_available = any(successful_llm_record(record) for record in llm_call_log)
        provider_error = (
            None
            if provider_available
            else "Workflow deadline reached before LLM availability could be confirmed."
        )
    else:
        provider_available, provider_error = is_llm_available(
            timeout=remaining if remaining is not None else 120
        )
    if (
        llm_requested
        and provider_available
        and all_llm_calls_failed_with_structured_output_rejection(llm_call_log)
    ):
        # Preflight only proves credentials resolve and the model constructs.
        # When every recorded call failed because the gateway rejects
        # structured output, the provider was never usable for this scan:
        # report it unavailable instead of a clean-looking llm_available.
        provider_available = False
        provider_error = (
            "Configured provider rejected structured output (response_format "
            "unsupported; tool-calling fallback also rejected); no LLM "
            "assessment ran."
        )
    runtime_available = llm_runtime_available(
        preflight_available=provider_available,
        result=state,
    )
    has_recorded_failure = any(not successful_llm_record(record) for record in llm_call_log)
    unavailable_before_execution = bool(llm_requested and not use_llm)
    provider_unavailable = bool(
        llm_requested
        and not provider_available
        and (has_recorded_failure or unavailable_before_execution)
    )
    degraded = (
        degraded
        or provider_unavailable
        or unavailable_before_execution
        or semantic_runtime_incomplete
    )
    degraded_notice = _llm_degradation_notice(llm_requested, llm_call_log)
    if unavailable_before_execution:
        degraded_notice = (
            "LLM analysis was requested but unavailable during preflight; "
            "results reflect STATIC analysis only."
        )
    elif provider_unavailable and degraded_notice is None:
        degraded_notice = (
            "LLM analysis was requested but the configured provider was unavailable"
            f" ({provider_error or 'unknown reason'}); results may reflect static analysis only."
        )
    elif semantic_runtime_incomplete and degraded_notice is None:
        degraded_notice = (
            "LLM analysis was requested but semantic runtime telemetry was incomplete; "
            "results may reflect static analysis only."
        )
    if format_recovery_policy_accepted(analysis_completeness):
        degraded_notice = (
            "The full AI assessment could not be verified after formatting recovery. "
            "The scan is accepted with a warning by policy; known findings remain."
        )
    if unavailable_before_execution:
        logger.warning(
            "LLM stage unavailable during preflight; report reflects static analysis only"
        )
    elif runtime_event is not None:
        logger.warning(
            "LLM stage degraded: semantic runtime telemetry was incomplete; "
            "report may reflect static analysis only"
        )
    elif degraded:
        logger.warning(
            "LLM stage degraded: %d/%d LLM call(s) failed; "
            "affected AI assessments are incomplete; completed results are retained",
            _attempted - _succeeded,
            _attempted,
        )

    baseline = state.get("baseline")
    show_suppressed = state.get("show_suppressed", False)
    active_findings, suppressed = partition_findings(
        selected_findings,
        baseline if isinstance(baseline, Baseline) else None,
        file_cache=file_cache,
        scanner_version=skillspector_version,
    )
    risk_score, risk_severity, risk_recommendation = _compute_risk_score(
        active_findings, has_executable_scripts, component_metadata
    )
    reported_findings = _bounded_report_findings(deduplicate(active_findings))
    remaining_output_records = max(
        0,
        MAX_FINDING_OUTPUT_RECORDS - _finding_output_record_count(reported_findings),
    )
    suppressed = _bounded_suppressed_findings(
        suppressed,
        limit=remaining_output_records,
    )
    display_findings = _expand_occurrences(reported_findings)
    exceptions = analysis_completeness.get("ledger_exceptions", [])
    fatal_exception = (
        any(
            isinstance(exception, Mapping) and bool(exception.get("fatal"))
            for exception in exceptions
        )
        if isinstance(exceptions, list)
        else False
    )
    entirely_uninspected_value = analysis_completeness.get("entirely_uninspected_files", 0)
    entirely_uninspected = (
        entirely_uninspected_value if isinstance(entirely_uninspected_value, int) else 0
    )
    # Fail closed for any incomplete/degraded scan while preserving the honest
    # score and severity. Transitive traversal limits are an additional source
    # of incomplete coverage.
    incomplete = not bool(analysis_completeness.get("is_complete", True))
    if (
        degraded
        or fatal_exception
        or entirely_uninspected > 0
        or incomplete
        or transitive_truncation_reasons
    ) and risk_recommendation == "SAFE":
        risk_recommendation = "CAUTION"

    raw_exceptions = analysis_completeness.get("ledger_exceptions")
    if isinstance(raw_exceptions, list):
        analysis_completeness = {
            **analysis_completeness,
            "ledger_exceptions": [
                {**row, "message": _inspection_exception_message(row)}
                if isinstance(row, Mapping)
                and sanitize_parser_diagnostic(row.get("parser_diagnostic")) is not None
                else row
                for row in raw_exceptions
            ],
        }

    sarif_report = _build_sarif(
        reported_findings,
        suppressed,
        degraded_notice=degraded_notice,
        analysis_completeness=analysis_completeness,
        execution_successful=execution_successful,
        structured_summaries=structured_summaries,
        origin=origin,
    )
    if output_format == "terminal":
        report_body = _format_terminal(
            display_findings,
            component_metadata,
            manifest,
            skill_path,
            risk_score,
            risk_severity,
            risk_recommendation,
            has_executable_scripts,
            use_llm=llm_requested,
            llm_call_log=llm_call_log,
            degraded_notice=degraded_notice,
            suppressed=suppressed,
            structured_summaries=structured_summaries,
            show_suppressed=show_suppressed,
            analysis_completeness=analysis_completeness,
            execution_successful=execution_successful,
            origin=origin,
        )
    elif output_format == "json":
        report_body = _format_json(
            display_findings,
            component_metadata,
            manifest,
            skill_path,
            risk_score,
            risk_severity,
            risk_recommendation,
            has_executable_scripts,
            use_llm=llm_requested,
            llm_call_log=llm_call_log,
            inference_usage=inference_usage,
            llm_provenance=llm_provenance,
            analysis_completeness=analysis_completeness,
            suppressed=suppressed,
            execution_successful=execution_successful,
            transitive_targets_scanned=(
                int(transitive_targets_scanned)
                if isinstance(transitive_targets_scanned, int)
                else None
            ),
            transitive_bytes_scanned=(
                int(transitive_bytes_scanned) if isinstance(transitive_bytes_scanned, int) else None
            ),
            transitive_truncation_reasons=transitive_truncation_reasons,
            structured_summaries=structured_summaries,
            llm_execution_enabled=use_llm,
            semantic_runtime_incomplete=semantic_runtime_incomplete,
            runtime_available=runtime_available,
            provider_availability=(provider_available, provider_error),
            origin=origin,
        )
    elif output_format == "markdown":
        report_body = _format_markdown(
            display_findings,
            component_metadata,
            manifest,
            skill_path,
            risk_score,
            risk_severity,
            risk_recommendation,
            has_executable_scripts,
            use_llm=llm_requested,
            llm_call_log=llm_call_log,
            degraded_notice=degraded_notice,
            suppressed=suppressed,
            structured_summaries=structured_summaries,
            show_suppressed=show_suppressed,
            analysis_completeness=analysis_completeness,
            execution_successful=execution_successful,
            origin=origin,
        )
    else:
        report_body = json.dumps(sarif_report, indent=2)

    logger.debug(
        "Report generated: format=%s, findings_count=%d, suppressed_count=%d",
        output_format,
        len(active_findings),
        len(suppressed),
    )
    return {
        "sarif_report": sarif_report,
        "risk_score": risk_score,
        "risk_severity": risk_severity,
        "risk_recommendation": risk_recommendation,
        "report_body": report_body,
        "filtered_findings": reported_findings,
        "suppressed_findings": suppressed,
        "active_findings": active_findings,
        "execution_successful": execution_successful,
        "analysis_completeness": dict(analysis_completeness),
        "transitive_targets_scanned": transitive_targets_scanned,
        "transitive_bytes_scanned": transitive_bytes_scanned,
        "transitive_truncated": bool(transitive_truncation_reasons),
        "transitive_truncation_reasons": transitive_truncation_reasons,
    }
