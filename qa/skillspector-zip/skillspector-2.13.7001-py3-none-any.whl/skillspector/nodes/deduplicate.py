# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Collision-resistant, occurrence-preserving finding compaction."""

from __future__ import annotations

import json
from dataclasses import replace
from hashlib import sha256

from skillspector.logging_config import get_logger
from skillspector.models import (
    OCCURRENCE_CODE_SNIPPET_KEY,
    OCCURRENCE_FINDING_ID_KEY,
    OCCURRENCE_FINDING_TEXT_KEY,
    Finding,
)
from skillspector.surface import SURFACES, infer_surface

logger = get_logger(__name__)

_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


def _occurrences(finding: Finding) -> list[dict[str, object]]:
    if finding.occurrences:
        occurrences = [dict(item) for item in finding.occurrences]
        for occurrence in occurrences:
            occurrence.setdefault(OCCURRENCE_FINDING_ID_KEY, finding.finding_id)
            occurrence.setdefault(
                OCCURRENCE_CODE_SNIPPET_KEY,
                finding.code_snippet or finding.context,
            )
            occurrence.setdefault(OCCURRENCE_FINDING_TEXT_KEY, finding.finding)
        return occurrences
    return [
        {
            "file": finding.file,
            "start_line": finding.start_line,
            "end_line": finding.end_line,
            **({"start_column": finding.start_column} if finding.start_column is not None else {}),
            **({"end_column": finding.end_column} if finding.end_column is not None else {}),
            "source_url": finding.source_url,
            "source_identity": finding.source_identity,
            "source_digest": finding.source_digest,
            "transitive_depth": finding.transitive_depth,
            OCCURRENCE_FINDING_ID_KEY: finding.finding_id,
            OCCURRENCE_CODE_SNIPPET_KEY: finding.code_snippet or finding.context,
            OCCURRENCE_FINDING_TEXT_KEY: finding.finding,
        }
    ]


def _line(value: object, default: int) -> int:
    return value if isinstance(value, int) else default


def _finding_source_scope(finding: Finding) -> str:
    """Return immutable provenance, including occurrence-only compatibility data."""
    direct = finding.source_identity or finding.source_digest or finding.source_url
    if direct:
        return direct
    for occurrence in finding.occurrences:
        candidate = (
            occurrence.get("source_identity")
            or occurrence.get("source_digest")
            or occurrence.get("source_url")
        )
        if candidate:
            return str(candidate)
    return ""


def _evidence_metadata_key(finding: Finding) -> tuple[str, object]:
    """Return a bounded, fail-closed identity for classification evidence."""
    try:
        canonical = json.dumps(
            finding.evidence,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
    except (RecursionError, TypeError, ValueError):
        # ``Finding.evidence`` intentionally accepts arbitrary plugin metadata.
        # Ambiguous values must never crash a scan or merge distinct findings.
        return ("opaque", id(finding))
    return ("sha256", sha256(canonical).digest())


def classification_metadata_key(
    finding: Finding,
    *,
    ignored_tags: frozenset[str] = frozenset(),
) -> tuple[object, ...]:
    """Return the classification semantics compacted occurrences must share.

    Occurrence expansion reuses one representative finding's report fields.
    Keeping classification fields in the compaction identity prevents a
    benign-context match and an unsafe match with the same rule fingerprint
    from inheriting each other's classification or evidence. Confidence and
    location-specific context are intentionally excluded because compaction
    retains one highest-confidence representative for equivalent findings.
    """
    return (
        finding.message,
        finding.severity,
        finding.category,
        finding.pattern,
        finding.explanation,
        finding.remediation,
        finding.intent,
        tuple(sorted(tag for tag in finding.tags if tag not in ignored_tags)),
        _evidence_metadata_key(finding),
    )


def _representative_key(finding: Finding) -> tuple[object, ...]:
    """Return a stable semantic rank without using opaque run-unique IDs."""
    return (
        _SEVERITY_ORDER.get(finding.severity.upper(), 4),
        -finding.confidence,
        finding.file,
        finding.start_line,
        finding.end_line is not None,
        finding.end_line or 0,
        finding.start_column is None,
        finding.start_column or 0,
        finding.end_column is None,
        finding.end_column or 0,
        finding.rule_id,
        finding.message,
        finding.category or "",
        finding.pattern or "",
        finding.finding or "",
        finding.explanation or "",
        finding.remediation or "",
        finding.code_snippet or "",
        finding.intent or "",
        tuple(finding.tags),
        finding.context or "",
        finding.matched_text or "",
        finding.source_identity or "",
        finding.source_digest or "",
        finding.source_url or "",
        finding.transitive_depth,
    )


def _output_key(finding: Finding) -> tuple[object, ...]:
    """Return a total semantic order for bounded downstream consumers."""
    return (
        _SEVERITY_ORDER.get(finding.severity.upper(), 4),
        finding.file,
        finding.start_line,
        finding.rule_id,
        _representative_key(finding),
        _finding_source_scope(finding),
        finding.fingerprint() or "",
        json.dumps(
            [
                {
                    key: value
                    for key, value in occurrence.items()
                    if key
                    not in {
                        OCCURRENCE_FINDING_ID_KEY,
                        OCCURRENCE_CODE_SNIPPET_KEY,
                        OCCURRENCE_FINDING_TEXT_KEY,
                    }
                }
                for occurrence in finding.occurrences
            ],
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ),
    )


def _occurrence_surface(finding: Finding, occurrence: dict[str, object]) -> str:
    """Return the surface label to record against one occurrence.

    The finding's own label is reused when the occurrence sits in the finding's
    file. An occurrence pointing at another file (exact-match dedup aggregates
    across files) falls back to a path-only inference, because the matched line
    for that other file is not retained here.
    """
    recorded_surface = occurrence.get("surface")
    if isinstance(recorded_surface, str) and recorded_surface in SURFACES:
        return recorded_surface
    file = str(occurrence.get("file", finding.file))
    if file == finding.file and finding.surface:
        return finding.surface
    return infer_surface(file)


def deduplicate(findings: list[Finding]) -> list[Finding]:
    """Aggregate classification-equivalent exact matches while preserving occurrences."""
    groups: dict[tuple[str, str, str, tuple[object, ...]], list[Finding]] = {}
    unique_without_match: list[Finding] = []
    for finding in findings:
        fingerprint = finding.fingerprint()
        if fingerprint is None:
            unique_without_match.append(finding)
            continue
        source_scope = _finding_source_scope(finding)
        groups.setdefault(
            (
                source_scope,
                finding.rule_id,
                fingerprint,
                classification_metadata_key(finding),
            ),
            [],
        ).append(finding)

    compacted: list[Finding] = []
    for (
        _source_scope,
        _rule_id,
        _fingerprint,
        _classification_metadata,
    ), group in groups.items():
        representative = min(group, key=_representative_key)
        occurrences: dict[tuple[object, ...], tuple[object, object, object, str]] = {}
        for finding in sorted(group, key=_representative_key):
            for occurrence in _occurrences(finding):
                location = (
                    str(occurrence.get("file", "")),
                    _line(occurrence.get("start_line"), 1),
                    occurrence.get("end_line"),
                    occurrence.get("start_column"),
                    occurrence.get("end_column"),
                    str(occurrence.get("source_identity") or finding.source_identity or ""),
                    str(occurrence.get("source_digest") or finding.source_digest or ""),
                    str(occurrence.get("source_url") or finding.source_url or ""),
                    _line(occurrence.get("transitive_depth"), finding.transitive_depth),
                )
                occurrences.setdefault(
                    location,
                    (
                        occurrence.get(OCCURRENCE_FINDING_ID_KEY, finding.finding_id),
                        occurrence.get(
                            OCCURRENCE_CODE_SNIPPET_KEY,
                            finding.code_snippet or finding.context,
                        ),
                        occurrence.get(OCCURRENCE_FINDING_TEXT_KEY, finding.finding),
                        _occurrence_surface(finding, occurrence),
                    ),
                )
        ordered_occurrences = [
            {
                "file": file,
                "start_line": start,
                "end_line": end,
                **({"start_column": start_column} if start_column is not None else {}),
                **({"end_column": end_column} if end_column is not None else {}),
                **({"source_identity": source_identity} if source_identity else {}),
                **({"source_digest": source_digest} if source_digest else {}),
                **({"source_url": source_url} if source_url else {}),
                **({"transitive_depth": transitive_depth} if transitive_depth else {}),
                **({"surface": surface} if surface else {}),
                OCCURRENCE_FINDING_ID_KEY: report_finding_id,
                OCCURRENCE_CODE_SNIPPET_KEY: report_code_snippet,
                OCCURRENCE_FINDING_TEXT_KEY: report_finding_text,
            }
            for (
                (
                    file,
                    start,
                    end,
                    start_column,
                    end_column,
                    source_identity,
                    source_digest,
                    source_url,
                    transitive_depth,
                ),
                (report_finding_id, report_code_snippet, report_finding_text, surface),
            ) in sorted(
                occurrences.items(),
                key=lambda item: (
                    item[0][5],
                    item[0][6],
                    item[0][7],
                    item[0][8],
                    item[0][0],
                    item[0][1],
                    _line(item[0][2], item[0][1]),
                    _line(item[0][3], -1),
                    _line(item[0][4], -1),
                ),
            )
        ]
        compacted.append(
            replace(
                representative,
                occurrences=ordered_occurrences,
            )
        )

    compacted.extend(unique_without_match)
    compacted.sort(key=_output_key)
    removed = len(findings) - len(compacted)
    if removed:
        logger.info(
            "Deduplication: %d -> %d findings (%d exact duplicates aggregated)",
            len(findings),
            len(compacted),
            removed,
        )
    return compacted
