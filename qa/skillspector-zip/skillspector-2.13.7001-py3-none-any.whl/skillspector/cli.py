# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CLI for Skillspector — thin wrapper over the LangGraph workflow.

Maps CLI args to initial state, invokes the graph, then maps result to output and exit code.
No business logic; workflow lives in the graph.
"""

from __future__ import annotations

import json
import math
import os
import sys
import warnings
from copy import deepcopy
from dataclasses import dataclass, field, replace
from enum import StrEnum
from functools import partial
from hashlib import sha256
from pathlib import Path
from stat import S_ISDIR
from time import monotonic
from typing import TYPE_CHECKING, Annotated, cast
from urllib.parse import quote

import typer
from click.core import ParameterSource
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.text import Text
from rich.tree import Tree

from skillspector import __version__, transitive
from skillspector.cleanup import TempDirTracker, cleanup_result
from skillspector.cli_entry import create_app
from skillspector.cli_entry import main as main
from skillspector.cli_entry import version_callback as version_callback
from skillspector.file_output import require_secure_file_output, write_text_no_follow
from skillspector.graph_proxy import graph
from skillspector.input_handler import _normalize_root_owned_alias, validate_local_input_path
from skillspector.inspection_ledger import (
    MAX_INSPECTION_LEDGER_EVENTS,
    REASON_MESSAGES,
    InspectionLedgerException,
    LedgerOutcome,
    LedgerReason,
    LedgerRecordType,
    finalize_ledger,
    inspection_work_id,
    ledger_event,
)
from skillspector.logging_config import get_logger, set_level
from skillspector.mcp_registry import scan_registry
from skillspector.models import OCCURRENCE_FINDING_ID_KEY, Finding
from skillspector.multi_skill import (
    MultiSkillDetectionResult,
    SkillDirectory,
    _manifest_file,
    detect_skills,
)
from skillspector.sarif_models import SARIF_SCHEMA_URI, validate_sarif_report
from skillspector.scan_policy import RISK_THRESHOLD
from skillspector.semantic_runtime import (
    has_semantic_runtime_event,
    semantic_runtime_intent,
    semantic_runtime_ledger_event,
)
from skillspector.state import MAX_WORKFLOW_BYTES, MAX_WORKFLOW_SECONDS
from skillspector.suppression import (
    Baseline,
    build_baseline_dict,
    discover_baseline,
    dump_baseline,
    effective_findings,
    load_baseline,
    serialize_baseline,
    source_content_key,
)
from skillspector.terminal_text import visible_terminal_text as _visible_terminal_text

if TYPE_CHECKING:
    from langchain_core.runnables import RunnableConfig

    from skillspector.state import SkillspectorState

logger = get_logger(__name__)


def __getattr__(name: str) -> object:
    """Keep analyzer compatibility exports lazy until a scan needs them."""
    if name in {"ANALYZER_MODULES", "ANALYZER_NODE_IDS"}:
        from skillspector.nodes import analyzers

        value = getattr(analyzers, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def report(state: SkillspectorState) -> dict[str, object]:
    """Load the scanner report builder only for actual skill reports."""
    from skillspector.nodes.report import report as build_report

    return build_report(state)


def unsupported_control_error(timeout: float | None = 120) -> str | None:
    """Keep the preflight hook patchable without loading providers for help."""
    from skillspector.llm_utils import unsupported_control_error as check_controls

    return check_controls(timeout=timeout)


def risk_severity_and_recommendation(score: int) -> tuple[str, str]:
    """Keep recursive verdict policy patchable while deferring report imports."""
    from skillspector.nodes.report import risk_severity_and_recommendation as assess_score

    return assess_score(score)


def _ensure_utf8_streams() -> None:
    """Reconfigure stdout/stderr to UTF-8 so Unicode report output does not crash.

    On Windows the default console encoding (e.g. cp1252) cannot encode the
    box-drawing characters and icons used in the terminal report, which raises
    UnicodeEncodeError. Reconfiguring with errors="replace" makes output robust
    across platforms without crashing.
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                logger.debug("Could not reconfigure %s to UTF-8", stream)


_ensure_utf8_streams()

app = create_app()

console = Console()
err_console = Console(stderr=True)


def _literal_line(label: str, style: str, message: object) -> Text:
    """Render a labelled line literally: no Rich markup, emoji or control characters."""
    lines = str(message).split("\n")
    body = "\n".join(_visible_terminal_text(line) for line in lines)
    return Text.assemble((f"{label}:", style), " ", body)


def _error_line(message: object) -> Text:
    """Render an error line literally."""
    return _literal_line("Error", "red", message)


def _warning_line(message: object) -> Text:
    """Render a warning line literally."""
    return _literal_line("Warning", "yellow", message)


_PROGRESS_TREE_MAX_PATHS = 200
_PROGRESS_TREE_MAX_NODES = 1_000
_TRANSITIVE_MAX_TARGETS = 32
_TRANSITIVE_MAX_BYTES = 10 * 1024 * 1024
_TRANSITIVE_MAX_SECONDS = MAX_WORKFLOW_SECONDS
_TRANSITIVE_MAX_ARTIFACTS = 10_000
_TRANSITIVE_MAX_FINDINGS = 10_000
_TRANSITIVE_MAX_COMPONENTS = 10_000
_TRANSITIVE_MAX_STATUS_EVENTS = 10_000
_TRANSITIVE_MAX_REFERENCES = 10_000
_MULTI_SKILL_MAX_SKILLS = 32
_MULTI_SKILL_MAX_PUBLIC_RECORDS = 10_000
_MULTI_SKILL_MAX_REPORT_CHARACTERS = 4 * 1024 * 1024


class FormatChoice(StrEnum):
    """Output format choices for the CLI."""

    terminal = "terminal"
    json = "json"
    markdown = "markdown"
    sarif = "sarif"


# Reports that tools parse from stdout, so status text must go to stderr.
_MACHINE_READABLE_FORMATS = frozenset({FormatChoice.json, FormatChoice.sarif})


class TransportChoice(StrEnum):
    """Transport choices for the MCP server."""

    stdio = "stdio"
    http = "http"


@dataclass(slots=True)
class _TransitiveBudget:
    max_targets: int = _TRANSITIVE_MAX_TARGETS
    max_bytes: int = _TRANSITIVE_MAX_BYTES
    max_seconds: float = _TRANSITIVE_MAX_SECONDS
    max_artifacts: int = _TRANSITIVE_MAX_ARTIFACTS
    max_findings: int = _TRANSITIVE_MAX_FINDINGS
    max_components: int = _TRANSITIVE_MAX_COMPONENTS
    max_ledger_events: int = MAX_INSPECTION_LEDGER_EVENTS
    max_status_events: int = _TRANSITIVE_MAX_STATUS_EVENTS
    max_references: int = _TRANSITIVE_MAX_REFERENCES


@dataclass(slots=True)
class _CachedTransitiveResult:
    source_url: str
    source_identity: str
    source_digest: str
    filtered_findings: list[Finding]
    findings: list[Finding]
    effective_finding_ids: list[str]
    inspection_ledger: list[dict[str, object]]
    analyzer_status_events: list[dict[str, object]]
    llm_call_log: list[dict[str, object]]
    inference_usage: list[dict[str, object]]
    components: list[str]
    component_metadata: list[dict[str, object]]
    file_cache: dict[str, str]
    local_file_cache: dict[str, str]
    artifact_inventory: list[dict[str, object]]
    artifact_references: list[dict[str, object]]
    has_executable_scripts: bool
    execution_successful: bool
    meta_review_required: bool
    refs: list[str]


@dataclass(slots=True)
class _TransitiveTraversalState:
    cache: dict[tuple[str, bool], _CachedTransitiveResult] = field(default_factory=dict)
    budget: _TransitiveBudget = field(default_factory=_TransitiveBudget)
    started_at: float | None = None
    scanned_targets: int = 0
    scanned_bytes: int = 0
    scanned_artifacts: int = 0
    truncation_reasons: list[str] = field(default_factory=list)
    resource_limit_reached: bool = False
    budget_exhausted: bool = False
    paused_at: float | None = None

    def note_truncation(self, reason: str) -> None:
        self.resource_limit_reached = True
        self._note_incomplete(reason)

    def exhaust_traversal(self, reason: str) -> None:
        """Record a limit that prevents additional target execution."""
        self.budget_exhausted = True
        self.note_truncation(reason)

    def _note_incomplete(self, reason: str) -> None:
        if len(self.truncation_reasons) >= 256:
            sentinel = "additional transitive limitations omitted"
            if self.truncation_reasons[-1] != sentinel:
                self.truncation_reasons[-1] = sentinel
            return
        if reason not in self.truncation_reasons:
            self.truncation_reasons.append(reason)

    def note_child_scan_failure(self, target: str) -> None:
        self._note_incomplete(f"transitive child scan failed for {target}")

    def _ensure_started(self) -> None:
        if self.started_at is None:
            self.started_at = monotonic()

    def can_scan_more(self) -> bool:
        self._ensure_started()
        if self.budget_exhausted:
            return False
        if self.scanned_targets >= self.budget.max_targets:
            self.exhaust_traversal(f"target budget {self.budget.max_targets} reached")
            return False
        if self.remaining_bytes() <= 0:
            self.exhaust_traversal(f"byte budget {self.budget.max_bytes} reached")
            return False
        if self.remaining_artifacts() <= 0:
            self.exhaust_traversal(f"artifact budget {self.budget.max_artifacts} reached")
            return False
        if self.remaining_seconds() <= 0:
            self.exhaust_traversal(f"time budget {self.budget.max_seconds:.0f}s reached")
            return False
        return True

    def record_scan(self) -> None:
        self._ensure_started()
        self.scanned_targets += 1
        if self.remaining_bytes() <= 0:
            self.exhaust_traversal(f"byte budget {self.budget.max_bytes} reached")
        if self.remaining_seconds() <= 0:
            self.exhaust_traversal(f"time budget {self.budget.max_seconds:.0f}s reached")

    def record_bytes(self, bytes_scanned: int) -> None:
        self._ensure_started()
        self.scanned_bytes += max(0, bytes_scanned)

    def remaining_seconds(self) -> float:
        self._ensure_started()
        assert self.started_at is not None
        end = self.paused_at if self.paused_at is not None else monotonic()
        return max(0.0, self.budget.max_seconds - (end - self.started_at))

    def remaining_bytes(self) -> int:
        return max(0, self.budget.max_bytes - self.scanned_bytes)

    def remaining_artifacts(self) -> int:
        return max(0, self.budget.max_artifacts - self.scanned_artifacts)

    def record_artifacts(self, artifacts: int) -> None:
        self._ensure_started()
        self.scanned_artifacts += max(0, artifacts)
        if self.scanned_artifacts > self.budget.max_artifacts:
            self.exhaust_traversal(f"artifact budget {self.budget.max_artifacts} reached")

    def pause_deadline(self) -> None:
        if self.started_at is not None and self.paused_at is None:
            self.paused_at = monotonic()

    def resume_deadline(self) -> None:
        if self.paused_at is not None:
            assert self.started_at is not None
            self.started_at += monotonic() - self.paused_at
            self.paused_at = None


def _scan_state(
    input_path: str,
    format: FormatChoice,
    no_llm: bool,
    yara_rules_dir: str | None = None,
    baseline: Path | None = None,
    show_suppressed: bool = False,
    source_local_only: bool = False,
    exclude_patterns: list[str] | None = None,
    use_shipped_baseline: bool = False,
) -> dict[str, object]:
    """Build initial graph state from scan CLI args."""
    state: dict[str, object] = {
        "input_path": input_path,
        "output_format": format.value,
        "use_llm": not no_llm,
        "llm_requested": not no_llm,
        "source_local_only": source_local_only,
    }
    if exclude_patterns:
        state["exclude_patterns"] = list(exclude_patterns)
    if use_shipped_baseline:
        state["use_shipped_baseline"] = True
        state["show_suppressed"] = show_suppressed
    if yara_rules_dir is not None:
        state["yara_rules_dir"] = yara_rules_dir
    if baseline is not None:
        # Loading may raise FileNotFoundError/ValueError, mapped to exit code 2 by scan().
        state["baseline"] = load_baseline(baseline)
        state["baseline_path"] = os.path.abspath(baseline.expanduser())
        state["show_suppressed"] = show_suppressed
    return state


def _shipped_baseline_notice(shipped: Path | None, input_path: Path, apply: bool) -> None:
    if shipped is not None:
        if apply:
            err_console.print(_literal_line("Applying author-shipped baseline", "yellow", shipped))
            err_console.print(
                "[dim]Suppressed findings do not count toward the risk score; "
                "use --show-suppressed to list them.[/dim]"
            )
        else:
            err_console.print(
                _literal_line("Shipped baseline detected (not applied)", "yellow", shipped)
            )
            err_console.print(
                "[dim]Review it, then re-run with --use-shipped-baseline to apply its "
                "suppressions. Findings and risk score are unaffected until you opt in.[/dim]"
            )
    elif apply:
        err_console.print(
            Text(
                _visible_terminal_text(
                    f"--use-shipped-baseline: no shipped baseline found in {input_path}; "
                    "scanning without a baseline."
                ),
                style="dim",
            )
        )


def _result_body(result: dict) -> str:
    report_body = result.get("report_body") or ""
    if not report_body and result.get("sarif_report") is not None:
        report_body = json.dumps(result["sarif_report"], indent=2)
    return report_body


def _validate_report_destination(input_path: Path, output: Path | None) -> None:
    """Reject reports that would overwrite an input, including path aliases."""
    if output is None:
        return
    if input_path.is_dir():
        input_path = _manifest_file(input_path) or input_path
    # The writer collapses lexical aliases (including missing/..). Retain the
    # original-path check too: a symlink followed by .. can name a different file.
    if input_path.is_file() and any(
        candidate.exists() and candidate.samefile(input_path)
        for candidate in (output, _normalize_root_owned_alias(output))
    ):
        raise ValueError("--output points to the input file. Choose a different output path.")
    # Reject an existing directory output before any scan work starts:
    # write_text_no_follow() would refuse it only after the analysis has
    # already consumed its tokens. Only directories are rejected here:
    # symlinks and other non-regular paths are deliberately left to the
    # existing downstream validation, which reports them with more
    # specific messages (input-file alias, "must be a regular file").
    # A missing path passes here and is still validated at write time.
    try:
        mode = os.lstat(output).st_mode
    except FileNotFoundError:
        pass
    else:
        if S_ISDIR(mode):
            raise ValueError(
                f"--output points to a non-regular path {str(output)!r}. "
                "Choose a regular file path for the report."
            )


def _write_result(
    result: dict[str, object],
    output: Path | None,
    format: FormatChoice,
) -> None:
    """Write report_body to file or stdout. Uses sarif_report if report_body missing."""
    report_body = _result_body(result)
    if output:
        write_text_no_follow(output, report_body)
        if format == FormatChoice.terminal:
            console.print(Text.assemble("\n", _literal_line("Report saved to", "green", output)))
        else:
            console.print(_literal_line("Report saved to", "", output))
    else:
        if format == FormatChoice.terminal:
            console.print(report_body, markup=False, emoji=False)
        else:
            print(report_body)


def _exit_on_unsupported_llm_controls(no_llm: bool) -> None:
    """Exit 2 before any analysis when a configured model rejects a requested control."""
    if no_llm:
        return
    error = unsupported_control_error()
    if error is not None:
        err_console.print(_error_line(error))
        raise typer.Exit(code=2)


def _validate_min_coverage(value: float | None) -> float | None:
    """Accept only finite percentage thresholds in the CLI's supported range."""
    if value is not None and (not math.isfinite(value) or not 0 <= value <= 100):
        raise typer.BadParameter("must be a finite number between 0 and 100")
    return value


def _coverage_below_threshold(result: dict[str, object], threshold: float | None) -> bool:
    """Compare finalized canonical coverage with the requested threshold."""
    if threshold is None:
        return False
    completeness = result.get("analysis_completeness")
    coverage = completeness.get("coverage_percent") if isinstance(completeness, dict) else None
    if isinstance(coverage, bool) or not isinstance(coverage, (int, float)):
        return True
    if not math.isfinite(coverage):
        return True
    return coverage < threshold


def _omissions_fail_threshold(omitted_skills: int, threshold: float | None) -> bool:
    """Known omitted skills leave coverage below any positive threshold."""
    return bool(omitted_skills) and threshold is not None and threshold > 0


def _recursive_json_payload(result: dict[str, object]) -> dict[str, object] | None:
    """Return parsed report_body when it is valid JSON object text."""
    raw_report_body = result.get("report_body")
    if not isinstance(raw_report_body, str):
        return None

    try:
        parsed = json.loads(raw_report_body)
    except json.JSONDecodeError:
        return None

    return parsed if isinstance(parsed, dict) else None


def _multi_skill_limitation_events(
    detection: MultiSkillDetectionResult,
) -> list[dict[str, object]]:
    """Project bounded pre-scan discovery limits into the canonical ledger."""
    events: list[dict[str, object]] = []
    for limitation in detection.limitations[:MAX_INSPECTION_LEDGER_EVENTS]:
        raw_reason = str(limitation.reason_code)
        try:
            reason = LedgerReason(raw_reason)
        except ValueError:
            reason = LedgerReason.READ_ERROR
        events.append(
            dict(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="multi_skill_discovery",
                    path="SKILL.md",
                    reason=reason,
                    stage=str(limitation.resource),
                    observed_characters=limitation.observed_characters,
                    limit_characters=limitation.limit_characters,
                    observed_bytes=limitation.observed_bytes,
                    limit_bytes=limitation.limit_bytes,
                    observed_artifacts=limitation.observed_artifacts,
                    limit_artifacts=limitation.limit_artifacts,
                    observed_depth=limitation.observed_depth,
                    limit_depth=limitation.limit_depth,
                    observed_seconds=limitation.observed_seconds,
                    limit_seconds=limitation.limit_seconds,
                )
            )
        )
    return events


@app.command()
def scan(
    ctx: typer.Context,
    input_path: Annotated[
        str,
        typer.Argument(
            help="Path or URL to scan. Supports: Git URL, file URL, zip file, .md file, or directory.",
        ),
    ],
    format: Annotated[
        FormatChoice,
        typer.Option(
            "--format",
            "-f",
            help="Output format.",
            case_sensitive=False,
        ),
    ] = FormatChoice.terminal,
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            "-o",
            help="Output file path. If not specified, prints to stdout.",
        ),
    ] = None,
    exclude: Annotated[
        list[str] | None,
        typer.Option(
            "--exclude",
            help="Exclude a relative POSIX path glob (repeatable). Local single-skill directories "
            "only; exclusions are reported as uninspected, partial coverage. SKILL.md is required.",
        ),
    ] = None,
    no_llm: Annotated[
        bool,
        typer.Option(
            "--no-llm",
            help="Skip LLM analysis (faster, less accurate). Uses static analysis only.",
        ),
    ] = False,
    yara_rules_dir: Annotated[
        Path | None,
        typer.Option(
            "--yara-rules-dir",
            help="Directory containing additional YARA rule files (.yar/.yara) to load alongside built-in rules.",
        ),
    ] = None,
    recursive: Annotated[
        bool,
        typer.Option(
            "--recursive",
            "-r",
            help="Scan immediate child directories with SKILL.md, skill.md, or a supported "
            "AISOP/AISP bundle as independent skills. A Markdown skill manifest at the scan "
            "root selects a single-skill scan.",
        ),
    ] = False,
    max_skills: Annotated[
        int | None,
        typer.Option(
            "--max-skills",
            min=1,
            help="Maximum skills in a local --recursive multi-skill scan (default: 32). "
            "Other aggregate safety limits still apply; no unlimited value.",
        ),
    ] = None,
    baseline: Annotated[
        Path | None,
        typer.Option(
            "--baseline",
            "-b",
            help="Baseline file (YAML/JSON) of suppressed findings. Matching findings "
            "are dropped before scoring. Generate one with 'skillspector baseline'.",
        ),
    ] = None,
    show_suppressed: Annotated[
        bool,
        typer.Option(
            "--show-suppressed",
            help="List findings suppressed by the baseline in the report (they still "
            "do not count toward the risk score).",
        ),
    ] = False,
    use_shipped_baseline: Annotated[
        bool,
        typer.Option(
            "--use-shipped-baseline",
            help="Apply a baseline shipped at the top level of the scanned skill "
            "directory or local ZIP (.skillspector-baseline.yaml). Off by default: a skill "
            "author's baseline can suppress findings in your scan, so a discovered "
            "baseline is only reported until you opt in. Ignored when --baseline "
            "is given. Not supported for recursive multi-skill scans; scan each "
            "sub-skill separately.",
        ),
    ] = False,
    inspect_dependencies: Annotated[
        bool,
        typer.Option(
            "--inspect-dependencies",
            help="Statically inspect SHA-512-verified public npm artifacts from v2/v3 lockfiles. Never installs packages or executes package code.",
        ),
    ] = False,
    transitive_enabled: Annotated[
        bool,
        typer.Option(
            "--transitive",
            help="Follow transitive external references after the initial scan.",
        ),
    ] = False,
    transitive_depth: Annotated[
        int,
        typer.Option(
            "--transitive-depth",
            help="Maximum transitive depth to scan for external references.",
        ),
    ] = 1,
    transitive_allow_prefix: Annotated[
        list[str] | None,
        typer.Option(
            "--transitive-allow-prefix",
            help=(
                "Only scan transitive targets matching at least one canonical prefix. Repeatable."
            ),
        ),
    ] = None,
    transitive_deny_prefix: Annotated[
        list[str] | None,
        typer.Option(
            "--transitive-deny-prefix",
            help=("Skip transitive targets matching any canonical prefix. Repeatable."),
        ),
    ] = None,
    fail_on_incomplete: Annotated[
        bool,
        typer.Option(
            "--fail-on-incomplete",
            help="Exit 1 when relevant analysis is partial or incomplete.",
        ),
    ] = False,
    min_coverage: Annotated[
        float | None,
        typer.Option(
            "--min-coverage",
            help="Exit 1 when canonical analysis coverage is below this percentage (0-100).",
            callback=_validate_min_coverage,
        ),
    ] = None,
    fail_on_findings: Annotated[
        bool,
        typer.Option(
            "--fail-on-findings",
            help="Exit 1 when the scan reports one or more active findings.",
        ),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-V",
            help="Show detailed progress.",
        ),
    ] = False,
    mcp_registry: Annotated[
        bool,
        typer.Option(
            "--mcp-registry",
            help="Scan an MCP Registry payload or URL instead of a skill.",
        ),
    ] = False,
    mcp_registry_compare: Annotated[
        Path | None,
        typer.Option(
            "--mcp-registry-compare",
            help="Compare registry snapshots with a previous local JSON report; requires --mcp-registry.",
        ),
    ] = None,
) -> None:
    """
    Scan a skill for security vulnerabilities.

    Examples:

        skillspector scan ./my-skill/
        skillspector scan ./my-skill/ --format json --output report.json
        skillspector scan https://github.com/user/my-skill --no-llm
        skillspector scan ./skill-collection/ --recursive

    Environment variables:

        SKILLSPECTOR_PROVIDER  Active LLM provider: openai | anthropic |
                               anthropic_proxy | bedrock | minimax | nv_build |
                               nv_inference | ollama | azure_openai |
                               openai_compatible | gemini | claude_cli |
                               gemini_cli | opencode_cli. Defaults to the NVIDIA path
                               (nv_inference, falling back to nv_build in
                               OSS builds).
        SKILLSPECTOR_MODEL     Override the active provider's default
                               model (applies to every analyzer slot).
        SKILLSPECTOR_LOG_LEVEL DEBUG | INFO | WARNING | ERROR (default WARNING).

    Provider credentials (one of):

        OPENAI_API_KEY [+ OPENAI_BASE_URL]   for SKILLSPECTOR_PROVIDER=openai
        ANTHROPIC_API_KEY                    for SKILLSPECTOR_PROVIDER=anthropic
        MINIMAX_API_KEY                      for SKILLSPECTOR_PROVIDER=minimax
        ANTHROPIC_PROXY_API_KEY +
          ANTHROPIC_PROXY_ENDPOINT_URL       for anthropic_proxy
        AWS_PROFILE (optional) + AWS_REGION  for SKILLSPECTOR_PROVIDER=bedrock
                                             (AWS_PROFILE: standard boto3 credential
                                             chain when unset; AWS_REGION default: us-west-2)
        NVIDIA_INFERENCE_KEY                 for the NVIDIA providers
        AZURE_OPENAI_API_KEY +
          AZURE_OPENAI_ENDPOINT              for azure_openai
        SKILLSPECTOR_COMPAT_API_KEY +
          SKILLSPECTOR_COMPAT_BASE_URL       for openai_compatible
        SKILLSPECTOR_COMPAT_HEADERS          optional JSON object of string headers
                                             for openai_compatible
        GOOGLE_CLOUD_PROJECT [+ GOOGLE_CLOUD_LOCATION]
                                             for gemini (uses Application
                                             Default Credentials / Workload Identity)

        ollama uses the local Ollama service. claude_cli,
        gemini_cli, and opencode_cli use their CLI's existing local
        authentication session. codex_cli is registered but disabled because
        its read-only sandbox permits host-file reads; use another provider.
    """
    if max_skills is not None and (not recursive or mcp_registry or not Path(input_path).is_dir()):
        err_console.print(
            "[red]Error:[/red] --max-skills requires a local --recursive multi-skill directory"
        )
        raise typer.Exit(code=2)
    if mcp_registry_compare is not None and not mcp_registry:
        err_console.print("[red]Error:[/red] --mcp-registry-compare requires --mcp-registry")
        raise typer.Exit(code=2)
    if exclude and (
        recursive
        or transitive_enabled
        or mcp_registry
        or not Path(input_path).is_dir()
        or _manifest_file(Path(input_path)) is None
    ):
        err_console.print(
            "[red]Error:[/red] --exclude requires a local single-skill directory with SKILL.md or skill.md "
            "and cannot be combined with --recursive, --transitive, or --mcp-registry"
        )
        raise typer.Exit(code=2)

    if output is not None:
        try:
            require_secure_file_output()
        except ValueError as exc:
            err_console.print(_error_line(exc))
            raise typer.Exit(code=2) from exc

    if mcp_registry:
        if (
            recursive
            or baseline is not None
            or show_suppressed
            or yara_rules_dir is not None
            or min_coverage is not None
            or use_shipped_baseline
            or inspect_dependencies
            or transitive_enabled
            or transitive_allow_prefix
            or transitive_deny_prefix
            # Even an explicitly supplied default depth requests an unsupported option.
            or ctx.get_parameter_source("transitive_depth") not in (None, ParameterSource.DEFAULT)
        ):
            err_console.print(
                "[red]Error:[/red] --mcp-registry cannot be combined with "
                "--recursive, --baseline, --show-suppressed, --yara-rules-dir, "
                "--min-coverage, --use-shipped-baseline, --inspect-dependencies, --transitive, "
                "--transitive-depth, --transitive-allow-prefix, or --transitive-deny-prefix"
            )
            raise typer.Exit(code=2)
        if format != FormatChoice.json:
            err_console.print(
                "[red]Error:[/red] --mcp-registry currently supports only --format json"
            )
            raise typer.Exit(code=2)
        try:
            _validate_report_destination(Path(input_path), output)
            if mcp_registry_compare is not None:
                _validate_report_destination(mcp_registry_compare, output)
            result = (
                scan_registry(input_path, compare_path=mcp_registry_compare)
                if mcp_registry_compare is not None
                else scan_registry(input_path)
            )
            report = json.dumps(result, indent=2)
            if output:
                write_text_no_follow(output, report)
                console.print(_literal_line("Report saved to", "", output))
            else:
                print(report)
            if fail_on_findings and result["findings"]:
                raise typer.Exit(code=1)
            if result["risk_score"] > RISK_THRESHOLD:
                raise typer.Exit(code=1)
        except typer.Exit:
            raise
        except Exception as e:
            err_console.print(_error_line(e))
            raise typer.Exit(code=2) from e
        return

    if verbose:
        set_level("DEBUG")

    resolved_path = Path(input_path)
    if not input_path.startswith(("http://", "https://", "git@")):
        try:
            resolved_path = validate_local_input_path(resolved_path)
            _validate_report_destination(resolved_path, output)
        except (OSError, ValueError) as e:
            err_console.print(_error_line(e))
            raise typer.Exit(code=2) from e
    try:
        transitive_allow_prefix, transitive_deny_prefix = transitive.normalize_prefixes(
            transitive_allow_prefix, transitive_deny_prefix
        )
    except ValueError as exc:
        err_console.print(_error_line(f"invalid transitive prefix: {exc}"))
        raise typer.Exit(code=2) from exc
    _exit_on_unsupported_llm_controls(no_llm)
    yara_dir = str(yara_rules_dir.resolve()) if yara_rules_dir else None
    pre_scan_ledger_events: list[dict[str, object]] = []
    discovery_console = (
        err_console if output is None and format is not FormatChoice.terminal else console
    )
    recursive_omitted_skills = 0
    if recursive and resolved_path.is_dir():
        detection = detect_skills(resolved_path)
        recursive_omitted_skills = detection.omitted_symlink_entries
        if not detection.complete:
            pre_scan_ledger_events = _multi_skill_limitation_events(detection)
            err_console.print(
                "[yellow]Warning:[/yellow] Recursive skill discovery was incomplete; "
                "continuing with a bounded scan and reporting partial coverage."
            )
        if detection.skills:
            if baseline is not None:
                err_console.print(
                    "[red]Error:[/red] --baseline is not supported for recursive "
                    "multi-skill scans; scan each sub-skill with its own baseline"
                )
                raise typer.Exit(code=2)
            if use_shipped_baseline:
                err_console.print(
                    "[red]Error:[/red] --use-shipped-baseline is not supported for recursive "
                    "multi-skill scans; scan each sub-skill separately with --use-shipped-baseline"
                )
                raise typer.Exit(code=2)
            # Same error contract as the single-skill scan below: an error that
            # escapes the combined report (e.g. an unwritable --output) exits 2,
            # not with a traceback and exit 1, which means "risk found".
            try:
                scan_multi_skill = (
                    partial(_scan_multi_skill, inspect_dependencies=True)
                    if inspect_dependencies
                    else _scan_multi_skill
                )
                scan_multi_skill(
                    detection,
                    format=format,
                    output=output,
                    no_llm=no_llm,
                    baseline=baseline,
                    show_suppressed=show_suppressed,
                    transitive_enabled=transitive_enabled,
                    transitive_depth=transitive_depth,
                    transitive_allow_prefix=transitive_allow_prefix,
                    transitive_deny_prefix=transitive_deny_prefix,
                    yara_dir=yara_dir,
                    verbose=verbose,
                    fail_on_incomplete=fail_on_incomplete,
                    fail_on_findings=fail_on_findings,
                    max_skills=max_skills,
                    min_coverage=min_coverage,
                )
            except typer.Exit:
                raise
            except (FileNotFoundError, ValueError) as e:
                err_console.print(_error_line(e))
                raise typer.Exit(code=2) from e
            except Exception as e:
                if verbose:
                    err_console.print_exception()
                else:
                    err_console.print(_error_line(e))
                raise typer.Exit(code=2) from e
            return
        if max_skills is not None:
            err_console.print(
                "[red]Error:[/red] --max-skills requires detected sub-skills; "
                "scan this input without --max-skills"
            )
            raise typer.Exit(code=2)
        if detection.complete and not detection.has_root_skill and len(detection.skills) == 0:
            discovery_console.print(
                "[yellow]Warning:[/yellow] --recursive specified but no sub-skills "
                "detected. Scanning as single skill."
            )
    elif resolved_path.is_dir():
        detection = detect_skills(resolved_path)
        if not detection.complete:
            pre_scan_ledger_events = _multi_skill_limitation_events(detection)
            err_console.print(
                "[yellow]Warning:[/yellow] Skill discovery was incomplete; continuing "
                "with a bounded scan and reporting partial coverage."
            )
        if exclude and detection.is_multi_skill:
            err_console.print("[red]Error:[/red] --exclude is not supported for multi-skill scans")
            raise typer.Exit(code=2)
        if detection.is_multi_skill:
            discovery_console.print(
                f"[yellow]Warning:[/yellow] Found {len(detection.skills)} skills in "
                f"this directory. Use --recursive to scan each independently."
            )

    zip_baseline = (
        use_shipped_baseline
        and baseline is None
        and resolved_path.is_file()
        and resolved_path.suffix.lower() == ".zip"
    )
    if baseline is None and not zip_baseline:
        shipped = discover_baseline(resolved_path) if resolved_path.is_dir() else None
        _shipped_baseline_notice(shipped, resolved_path, use_shipped_baseline)
        if use_shipped_baseline:
            baseline = shipped

    result = None
    try:
        if baseline is not None:
            _validate_report_destination(baseline, output)
        scan_skill = partial(_scan_skill, exclude_patterns=exclude) if exclude else _scan_skill
        if inspect_dependencies:
            scan_skill = partial(scan_skill, inspect_dependencies=True)
        if zip_baseline:
            scan_skill = partial(scan_skill, use_shipped_baseline=True)
        result = scan_skill(
            input_path=input_path,
            format=format,
            no_llm=no_llm,
            baseline=baseline,
            yara_rules_dir=Path(yara_dir) if yara_dir else None,
            verbose=verbose,
            show_suppressed=show_suppressed,
            transitive_enabled=transitive_enabled,
            transitive_depth=transitive_depth,
            transitive_allow_prefix=transitive_allow_prefix,
            transitive_deny_prefix=transitive_deny_prefix,
            pre_scan_ledger_events=pre_scan_ledger_events,
        )
        _write_result(result, output, format)

        if result.get("execution_successful") is False:
            raise typer.Exit(code=2)
        completeness_value = result.get("analysis_completeness")
        is_complete = (
            bool(completeness_value.get("is_complete", True))
            if isinstance(completeness_value, dict)
            else True
        )
        if fail_on_incomplete and not is_complete:
            raise typer.Exit(code=1)
        if fail_on_findings and effective_findings(result):
            raise typer.Exit(code=1)
        if _coverage_below_threshold(result, min_coverage) or _omissions_fail_threshold(
            recursive_omitted_skills, min_coverage
        ):
            raise typer.Exit(code=1)
        if (result.get("risk_score") or 0) > RISK_THRESHOLD:
            raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except (FileNotFoundError, ValueError) as e:
        err_console.print(_error_line(e))
        raise typer.Exit(code=2) from e
    except Exception as e:
        if verbose:
            err_console.print_exception()
        else:
            err_console.print(_error_line(e))
        raise typer.Exit(code=2) from e
    finally:
        if result is not None:
            cleanup_result(result)


def _build_trace_config(input_path: str, format: FormatChoice, no_llm: bool) -> RunnableConfig:
    """Build LangSmith trace config for a scan invocation."""
    env = os.environ.get("ENV", "dev")
    tags = ["skillspector", f"environment:{env}"]
    extra_tags = os.environ.get("LANGCHAIN_TAGS_EXTRA", "")
    tags.extend(t.strip() for t in extra_tags.split(",") if t.strip())
    return {
        "run_name": "skillspector-scan",
        "tags": tags,
        "metadata": {
            "input_path": input_path,
            "use_llm": not no_llm,
            "output_format": format.value,
            "version": __version__,
        },
    }


def _coerce_str_path_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if isinstance(item, str)]


def _coerce_findings_list(value: object) -> list[Finding]:
    if not isinstance(value, list):
        return []
    return [finding for finding in value if isinstance(finding, Finding)]


def _coerce_finding_ids(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str)]


def _effective_finding_ids(result: dict[str, object]) -> list[str]:
    effective_ids = _coerce_finding_ids(result.get("effective_finding_ids"))
    if effective_ids:
        return effective_ids
    return [
        finding.finding_id for finding in _coerce_findings_list(result.get("filtered_findings"))
    ]


def _coerce_llm_call_log(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _coerce_dict_list(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _coerce_raw_file_cache(value: object) -> dict[str, bytes]:
    if not isinstance(value, dict):
        return {}
    return {
        str(path): content
        for path, content in value.items()
        if isinstance(path, str) and isinstance(content, bytes)
    }


def _source_content_digest(
    raw_file_cache: dict[str, bytes], local_file_cache: dict[str, str]
) -> str:
    """Hash the exact bounded child snapshot without constructing a combined payload."""
    digest = sha256()
    digest.update(b"skillspector-transitive-source-v1\0")
    if raw_file_cache:
        records = ((path, content) for path, content in sorted(raw_file_cache.items()))
    else:
        records = (
            (path, content.encode("utf-8", errors="replace"))
            for path, content in sorted(local_file_cache.items())
        )
    for path, content in records:
        encoded_path = path.encode("utf-8", errors="replace")
        digest.update(len(encoded_path).to_bytes(8, "big"))
        digest.update(encoded_path)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return f"sha256:{digest.hexdigest()}"


def _source_identity(target: str, source_digest: str) -> str:
    digest = sha256()
    digest.update(b"skillspector-transitive-identity-v1\0")
    digest.update(target.encode("utf-8", errors="replace"))
    digest.update(b"\0")
    digest.update(source_digest.encode())
    return f"external/{digest.hexdigest()}"


def _scoped_finding_id(source_identity: str, finding_id: str) -> str:
    digest = sha256(f"{source_identity}\x1f{finding_id}".encode()).hexdigest()
    return f"finding-{digest}"


def _ledger_work_identity(entry: dict[str, object]) -> str:
    analyzer_id = entry.get("analyzer_id")
    if isinstance(analyzer_id, str) and analyzer_id:
        return analyzer_id
    record_type = entry.get("record_type", LedgerRecordType.WORK_ITEM)
    record_value = getattr(record_type, "value", record_type)
    return f"{record_value}:{entry.get('phase', '')}"


def _ledger_work_identities(value: object) -> dict[str, str]:
    """Map each child ledger row's own work ID to the identity it was built from.

    A status ``planned_work`` target carries only the child's work ID, path and
    range, not the identity behind it. Rows whose identity is not the
    analyzer's own -- the static_yara rule-set row is ``rule_set:static``, not
    ``static_yara`` -- must be re-scoped with that same identity in the status
    path, or the status target and its ledger row get different scoped IDs
    and the target is dropped as unretained.
    """
    identities: dict[str, str] = {}
    for event in _coerce_dict_list(value):
        work_id = event.get("work_id")
        if isinstance(work_id, str) and work_id:
            identities[work_id] = _ledger_work_identity(event)
    return identities


def _source_scoped_work_id(identity: str, item: dict[str, object]) -> str:
    """Build the scoped work ID for an already re-pathed ledger row or status target.

    Shared by :func:`_source_aware_ledger` and :func:`_source_aware_status_events`
    so the two scoping paths cannot derive different IDs for the same work.
    """
    start_line = item.get("start_line")
    end_line = item.get("end_line")
    return inspection_work_id(
        identity,
        str(item.get("path", "SKILL.md")),
        start_line if isinstance(start_line, int) else None,
        end_line if isinstance(end_line, int) else None,
    )


def _source_aware_ledger(
    value: object,
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
    finding_id_map: dict[str, str],
) -> list[dict[str, object]]:
    events: list[dict[str, object]] = []
    for event in _coerce_dict_list(value):
        entry = dict(event)
        path = entry.get("path")
        if isinstance(path, str) and path:
            entry["path"] = _transitive_component_key(source_identity, path)
        entry["source_url"] = source_url
        entry["source_identity"] = source_identity
        entry["source_digest"] = source_digest
        for id_field in ("input_finding_ids", "emitted_finding_ids"):
            ids = entry.get(id_field)
            if isinstance(ids, list):
                entry[id_field] = [
                    finding_id_map.get(str(item), _scoped_finding_id(source_identity, str(item)))
                    for item in ids
                    if isinstance(item, str)
                ]
        entry["work_id"] = _source_scoped_work_id(_ledger_work_identity(entry), entry)
        events.append(entry)
    return events


def _source_aware_status_events(
    value: object,
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
    retained_work_ids: set[str],
    max_planned_work: int,
    work_identities: dict[str, str] | None = None,
) -> list[dict[str, object]]:
    statuses: list[dict[str, object]] = []
    identities = work_identities or {}
    planned_retained = 0
    for status in _coerce_dict_list(value):
        if len(statuses) >= _TRANSITIVE_MAX_STATUS_EVENTS:
            break
        entry = dict(status)
        analyzer_id = str(entry.get("analyzer_id", ""))
        entry["source_url"] = source_url
        entry["source_identity"] = source_identity
        entry["source_digest"] = source_digest
        planned_work = entry.get("planned_work")
        if isinstance(planned_work, list):
            scoped_work: list[dict[str, object]] = []
            for target in planned_work:
                if planned_retained >= max(0, max_planned_work):
                    break
                if not isinstance(target, dict):
                    continue
                scoped_target = dict(target)
                path = scoped_target.get("path")
                if isinstance(path, str) and path:
                    scoped_target["path"] = _transitive_component_key(source_identity, path)
                # Re-scope with the identity the matching ledger row used, so
                # both paths agree on the scoped ID; the analyzer ID is only the
                # fallback for targets with no child ledger row.
                identity = identities.get(str(target.get("work_id", "")), analyzer_id)
                scoped_target["work_id"] = _source_scoped_work_id(identity, scoped_target)
                if scoped_target["work_id"] not in retained_work_ids:
                    continue
                scoped_work.append(scoped_target)
                planned_retained += 1
            entry["planned_work"] = scoped_work
        statuses.append(entry)
    return statuses


def _source_aware_llm_call_log(
    value: object,
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
) -> list[dict[str, object]]:
    """Bind child LLM telemetry to its immutable transitive source scope."""
    records: list[dict[str, object]] = []
    for record in _coerce_llm_call_log(value):
        records.append(
            {
                **record,
                "source_url": source_url,
                "source_identity": source_identity,
                "source_digest": source_digest,
            }
        )
    return records


def _coerce_file_cache(value: object) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {
        str(path): content
        for path, content in value.items()
        if isinstance(path, str) and isinstance(content, str)
    }


def _transitive_component_key(source_identity: str | None, path: str) -> str:
    if not source_identity:
        return path
    normalized = path.replace("\\", "/").lstrip("/") or "SKILL.md"
    return f"{source_identity}/{normalized}"


def _decorate_component_metadata(
    metadata: list[dict[str, object]],
    source_identity: str | None,
    *,
    source_url: str | None = None,
    source_digest: str | None = None,
) -> list[dict[str, object]]:
    decorated: list[dict[str, object]] = []
    for item in metadata:
        path = str(item.get("path", ""))
        entry = {**item, "coverage_key": _transitive_component_key(source_identity, path)}
        if source_url:
            entry["source_url"] = source_url
        if source_identity:
            entry["source_identity"] = source_identity
        if source_digest:
            entry["source_digest"] = source_digest
        decorated.append(entry)
    return decorated


def _source_aware_components(paths: list[str], source_identity: str | None) -> list[str]:
    return [_transitive_component_key(source_identity, path) for path in paths]


def _source_aware_file_cache(
    file_cache: dict[str, str], source_identity: str | None
) -> dict[str, str]:
    return {
        (source_content_key(source_identity, path) if source_identity else path): content
        for path, content in file_cache.items()
    }


def _source_aware_inventory(
    value: object,
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
) -> list[dict[str, object]]:
    inventory: list[dict[str, object]] = []
    for item in _coerce_dict_list(value)[:_TRANSITIVE_MAX_COMPONENTS]:
        entry = dict(item)
        entry["path"] = _transitive_component_key(
            source_identity, str(entry.get("path", "SKILL.md"))
        )
        if isinstance(entry.get("inspected_members"), list):
            entry["inspected_members"] = [
                _transitive_component_key(source_identity, str(path))
                for path in entry["inspected_members"]
            ]
        entry["source_url"] = source_url
        entry["source_identity"] = source_identity
        entry["source_digest"] = source_digest
        inventory.append(entry)
    return inventory


def _source_aware_references(
    value: object,
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
) -> list[dict[str, object]]:
    references: list[dict[str, object]] = []
    for item in _coerce_dict_list(value)[:_TRANSITIVE_MAX_REFERENCES]:
        entry = dict(item)
        for key in ("source_path", "target_path"):
            path = entry.get(key)
            if isinstance(path, str) and path:
                entry[key] = _transitive_component_key(source_identity, path)
        entry["source_url"] = source_url
        entry["source_identity"] = source_identity
        entry["source_digest"] = source_digest
        references.append(entry)
    return references


def _component_identity(item: dict[str, object]) -> str:
    coverage_key = item.get("coverage_key")
    if isinstance(coverage_key, str) and coverage_key:
        return coverage_key
    path = str(item.get("path", ""))
    source_identity = item.get("source_identity")
    return _transitive_component_key(
        source_identity if isinstance(source_identity, str) else None, path
    )


def _merge_unique_component_metadata(items: list[dict[str, object]]) -> list[dict[str, object]]:
    merged: list[dict[str, object]] = []
    seen: set[str] = set()
    for item in items:
        identity = _component_identity(item)
        if identity in seen:
            continue
        seen.add(identity)
        merged.append(item)
    return merged


def _transitive_limit_event(
    limitation: transitive.TransitiveResourceLimitation,
    *,
    phase: str,
    path: str,
) -> dict[str, object]:
    observed_bytes: int | None = None
    limit_bytes: int | None = None
    observed_records: int | None = None
    limit_records: int | None = None
    observed_artifacts: int | None = None
    limit_artifacts: int | None = None
    observed_seconds: float | None = None
    limit_seconds: float | None = None
    if limitation.resource in {"source_bytes"}:
        observed_bytes = int(limitation.observed)
        limit_bytes = int(limitation.limit)
    elif limitation.resource in {"runtime"}:
        observed_seconds = float(limitation.observed)
        limit_seconds = float(limitation.limit)
    elif limitation.resource in {
        "output_records",
        "frontier_references",
        "frontier_waves",
    }:
        observed_records = int(limitation.observed)
        limit_records = int(limitation.limit)
    else:
        observed_artifacts = int(limitation.observed)
        limit_artifacts = int(limitation.limit)
    return dict(
        ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase=phase,
            path=path,
            reason=LedgerReason.REFERENCE_EXTRACTION_LIMIT,
            stage=limitation.resource,
            observed_bytes=observed_bytes,
            limit_bytes=limit_bytes,
            observed_records=observed_records,
            limit_records=limit_records,
            observed_artifacts=observed_artifacts,
            limit_artifacts=limit_artifacts,
            observed_seconds=observed_seconds,
            limit_seconds=limit_seconds,
        )
    )


def _cache_transitive_result(
    target: str,
    child_result: dict[str, object],
    traversal: _TransitiveTraversalState,
) -> _CachedTransitiveResult:
    child_local_cache = _coerce_file_cache(
        child_result.get("local_file_cache") or child_result.get("file_cache")
    )
    child_file_cache = _coerce_file_cache(child_result.get("file_cache"))
    child_raw_cache = _coerce_raw_file_cache(child_result.get("raw_file_cache"))
    source_digest = _source_content_digest(child_raw_cache, child_local_cache)
    source_identity = _source_identity(target, source_digest)

    child_filtered = _coerce_findings_list(child_result.get("filtered_findings"))
    child_findings = _coerce_findings_list(child_result.get("findings"))
    all_ids = {finding.finding_id for finding in [*child_filtered, *child_findings]}
    all_ids.update(
        occurrence_id
        for finding in [*child_filtered, *child_findings]
        for occurrence in finding.occurrences
        if isinstance((occurrence_id := occurrence.get(OCCURRENCE_FINDING_ID_KEY)), str)
    )
    all_ids.update(_effective_finding_ids(child_result))
    finding_id_map = {
        finding_id: _scoped_finding_id(source_identity, finding_id) for finding_id in all_ids
    }

    def _scope_finding(finding: Finding) -> Finding:
        occurrences = []
        for raw in finding.occurrences:
            occurrence = dict(raw)
            occurrence_id = occurrence.get(OCCURRENCE_FINDING_ID_KEY)
            if isinstance(occurrence_id, str):
                occurrence[OCCURRENCE_FINDING_ID_KEY] = finding_id_map[occurrence_id]
            occurrences.append(occurrence)
        return replace(
            finding,
            finding_id=finding_id_map[finding.finding_id],
            source_url=target,
            source_identity=source_identity,
            source_digest=source_digest,
            occurrences=occurrences,
        )

    scoped_filtered = [_scope_finding(item) for item in child_filtered[:_TRANSITIVE_MAX_FINDINGS]]
    scoped_findings = [_scope_finding(item) for item in child_findings[:_TRANSITIVE_MAX_FINDINGS]]
    scoped_finding_ids = {item.finding_id for item in scoped_findings}
    scoped_findings.extend(
        item for item in scoped_filtered if item.finding_id not in scoped_finding_ids
    )
    scoped_findings = scoped_findings[:_TRANSITIVE_MAX_FINDINGS]
    if (
        len(child_filtered) > _TRANSITIVE_MAX_FINDINGS
        or len(child_findings) > _TRANSITIVE_MAX_FINDINGS
    ):
        traversal.note_truncation(
            f"finding budget {_TRANSITIVE_MAX_FINDINGS} reached for {source_identity}"
        )

    scoped_ledger = _source_aware_ledger(
        child_result.get("inspection_ledger"),
        source_url=target,
        source_identity=source_identity,
        source_digest=source_digest,
        finding_id_map=finding_id_map,
    )
    required_failure_events = _distinct_failed_ledger_events(scoped_ledger)
    retained_finding_ids = {item.finding_id for item in scoped_findings}
    for event in scoped_ledger:
        for id_field in ("input_finding_ids", "emitted_finding_ids"):
            ids = event.get(id_field)
            if isinstance(ids, list):
                event[id_field] = [
                    item for item in ids if isinstance(item, str) and item in retained_finding_ids
                ]
    extraction_deadline = monotonic() + traversal.remaining_seconds()
    extraction = transitive.extract_external_refs_with_metadata(
        child_local_cache,
        deadline=extraction_deadline,
    )
    for limitation in extraction.limitations:
        traversal.note_truncation(
            f"transitive reference {limitation.resource} limit at "
            f"{limitation.source_scope or source_identity}"
        )
        scoped_ledger.append(
            _transitive_limit_event(
                limitation,
                phase="transitive_reference_extraction",
                path=(limitation.source_scope or source_identity) + "/SKILL.md",
            )
        )
    scoped_ledger = _merge_bounded_ledger(
        [],
        scoped_ledger,
        limit=traversal.budget.max_ledger_events,
        traversal=traversal,
    )
    if required_failure_events:
        scoped_ledger = _ensure_required_failure_events(
            scoped_ledger,
            required_failure_events,
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
            failures_already_observed=True,
        )
    retained_work_ids = {
        str(event.get("work_id", "")) for event in scoped_ledger if event.get("work_id")
    }
    scoped_statuses = _source_aware_status_events(
        child_result.get("analyzer_status_events"),
        source_url=target,
        source_identity=source_identity,
        source_digest=source_digest,
        retained_work_ids=retained_work_ids,
        max_planned_work=len(retained_work_ids),
        work_identities=_ledger_work_identities(child_result.get("inspection_ledger")),
    )
    child_metadata = _decorate_component_metadata(
        _coerce_component_metadata(child_result.get("component_metadata")),
        source_identity,
        source_url=target,
        source_digest=source_digest,
    )
    child_components = _coerce_str_path_list(child_result.get("components"))
    if len(child_components) > _TRANSITIVE_MAX_COMPONENTS:
        traversal.note_truncation(
            f"component budget {_TRANSITIVE_MAX_COMPONENTS} reached for {source_identity}"
        )
        child_components = child_components[:_TRANSITIVE_MAX_COMPONENTS]
    return _CachedTransitiveResult(
        source_url=target,
        source_identity=source_identity,
        source_digest=source_digest,
        filtered_findings=scoped_filtered,
        findings=scoped_findings,
        effective_finding_ids=[
            finding_id_map.get(item, _scoped_finding_id(source_identity, item))
            for item in _effective_finding_ids(child_result)[:_TRANSITIVE_MAX_FINDINGS]
        ],
        inspection_ledger=scoped_ledger,
        analyzer_status_events=scoped_statuses,
        llm_call_log=_source_aware_llm_call_log(
            child_result.get("llm_call_log"),
            source_url=target,
            source_identity=source_identity,
            source_digest=source_digest,
        ),
        inference_usage=_coerce_dict_list(child_result.get("inference_usage")),
        components=_source_aware_components(child_components, source_identity),
        component_metadata=child_metadata,
        file_cache=_source_aware_file_cache(child_file_cache, source_identity),
        local_file_cache=_source_aware_file_cache(child_local_cache, source_identity),
        artifact_inventory=_source_aware_inventory(
            child_result.get("artifact_inventory"),
            source_url=target,
            source_identity=source_identity,
            source_digest=source_digest,
        ),
        artifact_references=_source_aware_references(
            child_result.get("artifact_references"),
            source_url=target,
            source_identity=source_identity,
            source_digest=source_digest,
        ),
        has_executable_scripts=bool(child_result.get("has_executable_scripts", False))
        or any(bool(entry.get("executable", False)) for entry in child_metadata),
        execution_successful=child_result.get("execution_successful") is not False,
        meta_review_required=child_result.get("meta_review_required") is True,
        refs=extraction.references,
    )


def _discovered_files_tree(paths: list[str]) -> Tree:
    """Build a literal, control-safe tree for paths from an untrusted bundle."""
    tree = Tree(Text("Discovered Files to Scan", style="bold blue"))
    nodes = {"": tree}
    ordered_paths = sorted(dict.fromkeys(paths))
    displayed_paths = 0
    node_count = 1
    for path in ordered_paths[:_PROGRESS_TREE_MAX_PATHS]:
        parts = Path(path).parts
        current = ""
        path_complete = True
        for index, part in enumerate(parts):
            parent = current
            current = f"{current}/{part}" if current else part
            if current in nodes:
                continue
            if node_count >= _PROGRESS_TREE_MAX_NODES:
                path_complete = False
                break
            is_file = index == len(parts) - 1
            icon = "📄 " if is_file else "📁 "
            style = "green" if is_file else "cyan"
            label = Text(f"{icon}{_visible_terminal_text(part)}", style=style)
            nodes[current] = nodes[parent].add(label)
            node_count += 1
        if not path_complete:
            break
        displayed_paths += 1

    omitted_paths = len(ordered_paths) - displayed_paths
    if omitted_paths:
        noun = "path" if omitted_paths == 1 else "paths"
        tree.add(
            Text(
                f"… {omitted_paths} additional {noun} omitted",
                style="dim yellow",
            )
        )
    return tree


def _wired_analyzer_node_ids() -> frozenset[str]:
    """Return only analyzers present in the compiled graph."""
    node_ids = sys.modules[__name__].ANALYZER_NODE_IDS
    graph_nodes = getattr(graph, "nodes", {})
    if not isinstance(graph_nodes, dict):
        return frozenset(node_ids)
    return frozenset(node_id for node_id in node_ids if node_id in graph_nodes)


def _run_graph_scan(
    input_path: str,
    format: FormatChoice,
    no_llm: bool,
    yara_dir: str | None = None,
    baseline: Path | None = None,
    show_suppressed: bool = False,
    transitive_traversal: _TransitiveTraversalState | None = None,
    initial_inspection_ledger: list[dict[str, object]] | None = None,
    source_local_only: bool = False,
    stream_progress: bool = False,
    exclude_patterns: list[str] | None = None,
    inspect_dependencies: bool = False,
    use_shipped_baseline: bool = False,
) -> dict[str, object]:
    state = _scan_state(
        input_path=input_path,
        format=format,
        no_llm=no_llm,
        yara_rules_dir=yara_dir,
        baseline=baseline,
        show_suppressed=show_suppressed,
        source_local_only=source_local_only,
        exclude_patterns=exclude_patterns,
        use_shipped_baseline=use_shipped_baseline,
    )
    if inspect_dependencies:
        state["inspect_dependencies"] = True
    if transitive_traversal is not None:
        state["transitive_traversal_state"] = transitive_traversal
    if initial_inspection_ledger:
        state["inspection_ledger"] = initial_inspection_ledger
    trace_config = _build_trace_config(input_path, format, no_llm)
    # A scan that raises or is interrupted returns no result for the caller to
    # clean up, so remove the temp directory resolve_input made here instead.
    temp_dir_tracker = TempDirTracker()
    trace_config["callbacks"] = [temp_dir_tracker]
    if not stream_progress:
        with temp_dir_tracker.removing_on_error():
            return cast(dict[str, object], graph.invoke(state, config=trace_config))

    analyzer_node_ids = _wired_analyzer_node_ids()
    total_analyzers = len(analyzer_node_ids)
    total_steps = 6 + total_analyzers
    result = dict(state)

    with (
        warnings.catch_warnings(),
        Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=err_console,
            transient=True,
        ) as progress,
        temp_dir_tracker.removing_on_error(),
    ):
        warnings.filterwarnings("ignore", category=UserWarning, module="pydantic")
        task_id = progress.add_task("Resolving input...", total=total_steps)
        num_files = 0
        analyzers_done = 0

        stream = graph.stream(
            state,
            config=trace_config,
            stream_mode=["updates", "values"],
        )
        for stream_mode, chunk in stream:
            if stream_mode == "values":
                if isinstance(chunk, dict):
                    result = dict(chunk)
                continue
            if stream_mode != "updates" or not isinstance(chunk, dict):
                continue

            for node_name, node_output in chunk.items():
                progress.advance(task_id)
                if not isinstance(node_output, dict):
                    continue

                if node_name == "resolve_input":
                    progress.update(task_id, description="Building context...")
                elif node_name == "build_context":
                    raw_components = node_output.get("components")
                    components = raw_components if isinstance(raw_components, list) else []
                    paths = sorted(str(path) for path in components)
                    num_files = len(paths)
                    progress.update(
                        task_id,
                        description=(
                            f"Analyzing {num_files} files (0/{total_analyzers} rules applied)..."
                        ),
                    )

                    err_console.print(_discovered_files_tree(paths))
                    err_console.print()
                elif node_name in analyzer_node_ids:
                    analyzers_done += 1
                    progress.update(
                        task_id,
                        description=(
                            f"Analyzing {num_files} files "
                            f"({analyzers_done}/{total_analyzers} rules applied)..."
                        ),
                    )
                    err_console.print(f"[dim]✔ Rule completed: {node_name}[/dim]")
                elif node_name == "meta_analyzer":
                    progress.update(task_id, description="Generating report...")
                    err_console.print(
                        "[dim]✔ Rule completed: meta_analyzer (filtering findings)[/dim]"
                    )

    return result


def _run_graph_scan_for_source(
    input_path: str,
    format: FormatChoice,
    no_llm: bool,
    yara_dir: str | None = None,
    baseline: Path | None = None,
    show_suppressed: bool = False,
    transitive_traversal: _TransitiveTraversalState | None = None,
    initial_inspection_ledger: list[dict[str, object]] | None = None,
    source_local_only: bool = False,
    stream_progress: bool = False,
    exclude_patterns: list[str] | None = None,
    inspect_dependencies: bool = False,
    use_shipped_baseline: bool = False,
) -> dict[str, object]:
    """Invoke a scan without widening the legacy call contract for public sources."""
    run_graph_scan = (
        partial(_run_graph_scan, stream_progress=True) if stream_progress else _run_graph_scan
    )
    if exclude_patterns:
        run_graph_scan = partial(run_graph_scan, exclude_patterns=exclude_patterns)
    if inspect_dependencies:
        run_graph_scan = partial(run_graph_scan, inspect_dependencies=True)
    if use_shipped_baseline:
        run_graph_scan = partial(run_graph_scan, use_shipped_baseline=True)
    if initial_inspection_ledger is not None:
        if source_local_only:
            return run_graph_scan(
                input_path=input_path,
                format=format,
                no_llm=no_llm,
                yara_dir=yara_dir,
                baseline=baseline,
                show_suppressed=show_suppressed,
                transitive_traversal=transitive_traversal,
                initial_inspection_ledger=initial_inspection_ledger,
                source_local_only=True,
            )
        return run_graph_scan(
            input_path=input_path,
            format=format,
            no_llm=no_llm,
            yara_dir=yara_dir,
            baseline=baseline,
            show_suppressed=show_suppressed,
            transitive_traversal=transitive_traversal,
            initial_inspection_ledger=initial_inspection_ledger,
        )
    if source_local_only:
        return run_graph_scan(
            input_path=input_path,
            format=format,
            no_llm=no_llm,
            yara_dir=yara_dir,
            baseline=baseline,
            show_suppressed=show_suppressed,
            transitive_traversal=transitive_traversal,
            source_local_only=True,
        )
    return run_graph_scan(
        input_path=input_path,
        format=format,
        no_llm=no_llm,
        yara_dir=yara_dir,
        baseline=baseline,
        show_suppressed=show_suppressed,
        transitive_traversal=transitive_traversal,
    )


def _annotate_transitive_findings(
    findings: list[Finding],
    *,
    source_url: str,
    source_identity: str,
    source_digest: str,
    transitive_depth: int,
) -> list[Finding]:
    annotated: list[Finding] = []
    for finding in findings:
        base_occurrences = finding.occurrences or [
            {
                "file": finding.file,
                "start_line": finding.start_line,
                "end_line": finding.end_line,
            }
        ]
        occurrences = [
            {
                **occurrence,
                "source_url": source_url,
                "source_identity": source_identity,
                "source_digest": source_digest,
                "transitive_depth": transitive_depth,
            }
            for occurrence in base_occurrences
        ]
        annotated.append(
            replace(
                finding,
                transitive_depth=transitive_depth,
                source_url=source_url,
                source_identity=source_identity,
                source_digest=source_digest,
                occurrences=occurrences,
            )
        )
    return annotated


def _bounded_extend[T](
    destination: list[T],
    values: list[T],
    *,
    limit: int,
    traversal: _TransitiveTraversalState,
    resource: str,
) -> None:
    remaining = max(0, limit - len(destination))
    destination.extend(values[:remaining])
    if len(values) > remaining:
        traversal.note_truncation(f"{resource} budget {limit} reached")


def _bounded_cache_update(
    destination: dict[str, str],
    values: dict[str, str],
    *,
    limit: int,
    traversal: _TransitiveTraversalState,
    resource: str,
) -> None:
    for path in sorted(values):
        if path in destination:
            # Source-scoped keys are disjoint from root paths. A repeated key
            # refers to the same cached result within this traversal.
            continue
        if len(destination) >= limit:
            traversal.note_truncation(f"{resource} budget {limit} reached")
            break
        destination[path] = values[path]


def _bounded_root_status_events(
    value: object,
    *,
    retained_work_ids: set[str],
    limit: int,
) -> list[dict[str, object]]:
    statuses: list[dict[str, object]] = []
    planned_retained = 0
    for status in _coerce_dict_list(value):
        if len(statuses) >= limit:
            break
        entry = dict(status)
        planned = entry.get("planned_work")
        if isinstance(planned, list):
            bounded_planned: list[dict[str, object]] = []
            for target in planned:
                if planned_retained >= limit:
                    break
                if not isinstance(target, dict):
                    continue
                work_id = str(target.get("work_id", ""))
                if work_id not in retained_work_ids:
                    continue
                bounded_planned.append(dict(target))
                planned_retained += 1
            entry["planned_work"] = bounded_planned
        statuses.append(entry)
    return statuses


def _status_planned_work_count(statuses: list[dict[str, object]]) -> int:
    total = 0
    for status in statuses:
        planned = status.get("planned_work")
        if isinstance(planned, list):
            total += len(planned)
    return total


def _merge_bounded_ledger(
    existing: list[dict[str, object]],
    updates: list[dict[str, object]],
    *,
    limit: int,
    traversal: _TransitiveTraversalState | None = None,
) -> list[dict[str, object]]:
    """Merge traversal ledger rows under the caller's shared record ceiling."""
    effective_limit = max(1, limit)
    if existing and existing[-1].get("phase") == "ledger_output":
        if updates and traversal is not None:
            traversal.note_truncation(f"inspection ledger budget {effective_limit} reached")
        prior = existing[-1]
        observed_value = prior.get("observed_records")
        prior_observed = observed_value if isinstance(observed_value, int) else len(existing)
        return [
            *existing[:-1][: effective_limit - 1],
            dict(
                ledger_event(
                    outcome=LedgerOutcome.PARTIAL,
                    record_type=LedgerRecordType.SYSTEM,
                    phase="ledger_output",
                    path=str(prior.get("path", "SKILL.md")),
                    reason=LedgerReason.OUTPUT_LIMIT,
                    observed_records=max(prior_observed, len(existing)) + len(updates),
                    limit_records=effective_limit,
                )
            ),
        ]
    combined = [*existing, *updates]
    if len(combined) <= effective_limit:
        return combined
    if traversal is not None:
        traversal.note_truncation(f"inspection ledger budget {effective_limit} reached")
    overflow = combined[effective_limit - 1]
    return [
        *combined[: effective_limit - 1],
        dict(
            ledger_event(
                outcome=LedgerOutcome.PARTIAL,
                record_type=LedgerRecordType.SYSTEM,
                phase="ledger_output",
                path=str(overflow.get("path", "SKILL.md")),
                reason=LedgerReason.OUTPUT_LIMIT,
                observed_records=len(combined),
                limit_records=effective_limit,
            )
        ),
    ]


def _is_failed_ledger_event(event: dict[str, object]) -> bool:
    outcome = event.get("outcome")
    return getattr(outcome, "value", outcome) == LedgerOutcome.FAILED.value


def _distinct_failed_ledger_events(
    events: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Return failed work items once each, preserving their observed order."""
    failures: list[dict[str, object]] = []
    work_ids: set[str] = set()
    for event in events:
        work_id = str(event.get("work_id", ""))
        if not _is_failed_ledger_event(event) or work_id in work_ids:
            continue
        failures.append(event)
        work_ids.add(work_id)
    return failures


def _transitive_child_failure_event(source_identity: str) -> dict[str, object]:
    """Return one deterministic, payload-free fatal fact for an opaque child failure."""
    return dict(
        ledger_event(
            outcome=LedgerOutcome.FAILED,
            record_type=LedgerRecordType.SYSTEM,
            phase="transitive_child_scan",
            path=f"{source_identity}/SKILL.md",
            reason=LedgerReason.TRANSITIVE_CHILD_SCAN_FAILED,
        )
    )


def _ensure_required_failure_events(
    events: list[dict[str, object]],
    failures: list[dict[str, object]],
    *,
    limit: int,
    traversal: _TransitiveTraversalState,
    failures_already_observed: bool = False,
) -> list[dict[str, object]]:
    """Retain distinct fatal facts before non-fatal rows at the shared bound.

    Pre-observed failures came from the input that produced an existing sentinel;
    synthesized failures are new observations and remain the required fatal facts.
    """
    effective_limit = max(1, limit)
    incoming_failures = _distinct_failed_ledger_events(failures)
    required_failures = _distinct_failed_ledger_events([*events, *failures])
    if not required_failures:
        return events[:effective_limit]
    required_work_ids = {str(event.get("work_id", "")) for event in required_failures}
    event_work_ids = {str(event.get("work_id", "")) for event in events}
    missing_failures = [
        event for event in required_failures if str(event.get("work_id", "")) not in event_work_ids
    ]

    prior_sentinel = next(
        (event for event in reversed(events) if event.get("phase") == "ledger_output"),
        None,
    )
    would_overflow = len(events) + len(missing_failures) > effective_limit
    if prior_sentinel is None and not would_overflow:
        combined = [*events, *missing_failures]
        if len(combined) < effective_limit:
            return combined
        non_failures = [
            event for event in combined if str(event.get("work_id", "")) not in required_work_ids
        ]
        return [*required_failures, *non_failures][:effective_limit]

    traversal.note_truncation(f"inspection ledger budget {effective_limit} reached")
    if effective_limit == 1:
        return (incoming_failures or required_failures)[:1]
    observed_value = prior_sentinel.get("observed_records") if prior_sentinel else None
    observed_records = observed_value if isinstance(observed_value, int) else len(events)
    newly_observed = (
        0 if prior_sentinel is not None and failures_already_observed else len(missing_failures)
    )
    sentinel_path = (
        str(prior_sentinel.get("path", "SKILL.md"))
        if prior_sentinel is not None and failures_already_observed
        else str((incoming_failures or required_failures)[0].get("path", "SKILL.md"))
    )
    sentinel = dict(
        ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase="ledger_output",
            path=sentinel_path,
            reason=LedgerReason.OUTPUT_LIMIT,
            observed_records=max(observed_records, len(events)) + newly_observed,
            limit_records=effective_limit,
        )
    )
    failure_slots = effective_limit - 1
    if failures_already_observed:
        retained_failures = required_failures[:failure_slots]
    else:
        incoming_work_ids = {str(event.get("work_id", "")) for event in incoming_failures}
        retained_incoming = incoming_failures[:failure_slots]
        retained_existing = [
            event
            for event in required_failures
            if str(event.get("work_id", "")) not in incoming_work_ids
        ][: failure_slots - len(retained_incoming)]
        retained_failures = [*retained_existing, *retained_incoming]
    retained_work_ids = {str(event.get("work_id", "")) for event in retained_failures}
    retained_non_failures = [
        event
        for event in events
        if event.get("phase") != "ledger_output"
        and str(event.get("work_id", "")) not in retained_work_ids
        and not _is_failed_ledger_event(event)
    ][: failure_slots - len(retained_failures)]
    return [*retained_failures, *retained_non_failures, sentinel]


def _scan_transitive(
    initial_result: dict[str, object],
    format: FormatChoice,
    no_llm: bool,
    max_depth: int,
    transitive_allow_prefix: tuple[str, ...] | list[str] | None,
    transitive_deny_prefix: tuple[str, ...] | list[str] | None,
    baseline: Path | None,
    show_suppressed: bool,
    visited: set[str],
    scan_cache: dict[tuple[str, bool], _CachedTransitiveResult] | None = None,
    budget: _TransitiveBudget | None = None,
    yara_dir: str | None = None,
    traversal: _TransitiveTraversalState | None = None,
    source_local_only: bool = False,
    inspect_dependencies: bool = False,
) -> dict[str, object]:
    scan_child = (
        partial(_run_graph_scan_for_source, inspect_dependencies=True)
        if inspect_dependencies
        else _run_graph_scan_for_source
    )
    if max_depth <= 0:
        report_result = cast(dict[str, object], report(initial_result))
        report_result["temp_dir_for_cleanup"] = initial_result.get("temp_dir_for_cleanup")
        report_result["transitive_finding_count"] = 0
        report_result["transitive_sources"] = []
        report_result["transitive_targets_scanned"] = 0
        report_result["transitive_bytes_scanned"] = 0
        report_result["transitive_artifacts_scanned"] = 0
        report_result["transitive_truncated"] = False
        report_result["transitive_truncation_reasons"] = []
        report_result["analysis_completeness"] = initial_result.get("analysis_completeness", {})
        return report_result

    if traversal is None:
        traversal = _TransitiveTraversalState(
            cache=scan_cache if scan_cache is not None else {},
            budget=budget if budget is not None else _TransitiveBudget(),
        )
    elif scan_cache is not None and traversal.cache is not scan_cache:
        traversal.cache = scan_cache
    transitive_sources: set[str] = set()
    merged_filtered_findings = _coerce_findings_list(initial_result.get("filtered_findings"))[
        : traversal.budget.max_findings
    ]
    merged_findings = _coerce_findings_list(initial_result.get("findings"))[
        : traversal.budget.max_findings
    ]
    merged_llm_call_log = _coerce_llm_call_log(initial_result.get("llm_call_log"))[
        :MAX_INSPECTION_LEDGER_EVENTS
    ]
    merged_inference_usage = _coerce_dict_list(initial_result.get("inference_usage"))[
        :MAX_INSPECTION_LEDGER_EVENTS
    ]
    merged_effective_finding_ids = _effective_finding_ids(initial_result)[
        : traversal.budget.max_findings
    ]
    root_inspection_ledger = _coerce_dict_list(initial_result.get("inspection_ledger"))
    required_root_failure_events = _distinct_failed_ledger_events(root_inspection_ledger)
    merged_inspection_ledger = _merge_bounded_ledger(
        [],
        root_inspection_ledger,
        limit=traversal.budget.max_ledger_events,
        traversal=traversal,
    )
    if required_root_failure_events:
        merged_inspection_ledger = _ensure_required_failure_events(
            merged_inspection_ledger,
            required_root_failure_events,
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
            failures_already_observed=True,
        )
    retained_work_ids = {
        str(event.get("work_id", "")) for event in merged_inspection_ledger if event.get("work_id")
    }
    merged_analyzer_status_events = _bounded_root_status_events(
        initial_result.get("analyzer_status_events"),
        retained_work_ids=retained_work_ids,
        limit=traversal.budget.max_status_events,
    )
    merged_components = _source_aware_components(
        _coerce_str_path_list(initial_result.get("components"))[: traversal.budget.max_components],
        None,
    )
    file_cache = _coerce_file_cache(initial_result.get("file_cache"))
    merged_file_cache = _source_aware_file_cache(file_cache, None)
    local_file_cache = _coerce_file_cache(
        initial_result.get("local_file_cache") or initial_result.get("file_cache")
    )
    merged_local_file_cache = _source_aware_file_cache(local_file_cache, None)
    merged_artifact_inventory = _coerce_dict_list(initial_result.get("artifact_inventory"))[
        : traversal.budget.max_components
    ]
    merged_artifact_references = _coerce_dict_list(initial_result.get("artifact_references"))[
        : traversal.budget.max_references
    ]
    component_metadata = _decorate_component_metadata(
        _coerce_component_metadata(initial_result.get("component_metadata")), None
    )[: traversal.budget.max_components]
    has_executable_scripts = bool(initial_result.get("has_executable_scripts", False))
    merged_meta_review_required = initial_result.get("meta_review_required") is True

    root_extraction = transitive.extract_external_refs_with_metadata(
        local_file_cache,
        deadline=monotonic() + traversal.remaining_seconds(),
    )
    for limitation in root_extraction.limitations:
        traversal.note_truncation(
            f"transitive reference {limitation.resource} limit at "
            f"{limitation.source_scope or 'root'}"
        )
        merged_inspection_ledger = _merge_bounded_ledger(
            merged_inspection_ledger,
            [
                _transitive_limit_event(
                    limitation,
                    phase="transitive_reference_extraction",
                    path=(limitation.source_scope or "SKILL.md"),
                )
            ],
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
        )
    frontier = transitive.BoundedTransitiveFrontier(
        deadline=monotonic() + traversal.remaining_seconds(),
        max_waves=min(max(1, max_depth), transitive.MAX_TRANSITIVE_FRONTIER_WAVES),
        max_references=min(
            traversal.budget.max_references,
            transitive.MAX_TRANSITIVE_FRONTIER_REFERENCES,
        ),
    )
    frontier.append(1, root_extraction.references)
    recorded_frontier_limitations = 0

    while frontier:
        if not traversal.can_scan_more():
            break
        wave = frontier.popleft()
        if wave is None:
            break
        current_depth, refs = wave.depth, wave.references
        plan = transitive.plan_transitive_targets_with_metadata(
            refs=refs,
            visited=visited,
            current_depth=current_depth,
            max_depth=max_depth,
            allow_prefixes=transitive_allow_prefix,
            deny_prefixes=transitive_deny_prefix,
            deadline=monotonic() + traversal.remaining_seconds(),
        )
        for limitation in plan.limitations:
            traversal.note_truncation(f"transitive plan {limitation.resource} limit")
            merged_inspection_ledger = _merge_bounded_ledger(
                merged_inspection_ledger,
                [
                    _transitive_limit_event(
                        limitation,
                        phase="transitive_target_planning",
                        path="SKILL.md",
                    )
                ],
                limit=traversal.budget.max_ledger_events,
                traversal=traversal,
            )
        for target in plan.targets:
            if not traversal.can_scan_more():
                break
            child_result: dict[str, object] | None = None
            try:
                # Privacy mode is part of the computation identity: sharing a
                # cache entry across modes could either suppress a public LLM
                # pass or leak provider-derived state into a local-only scan.
                cache_key = (target, source_local_only)
                cached = traversal.cache.get(cache_key)
                if cached is None:
                    traversal.record_scan()
                    child_result = scan_child(
                        input_path=target,
                        format=format,
                        no_llm=no_llm,
                        yara_dir=yara_dir,
                        # A root baseline cannot pre-suppress dependency findings
                        # before source provenance is attached. Suppression is
                        # applied exactly once to the merged, source-bound set.
                        baseline=None,
                        show_suppressed=False,
                        transitive_traversal=traversal,
                        source_local_only=source_local_only,
                    )
                    cached = _cache_transitive_result(target, child_result, traversal)
                    traversal.cache[cache_key] = cached
                if not cached.execution_successful:
                    traversal.note_child_scan_failure(target)
                    if not any(
                        _is_failed_ledger_event(event) for event in cached.inspection_ledger
                    ):
                        cached.inspection_ledger = _ensure_required_failure_events(
                            cached.inspection_ledger,
                            [_transitive_child_failure_event(cached.source_identity)],
                            limit=traversal.budget.max_ledger_events,
                            traversal=traversal,
                        )
                transitive_sources.add(target)
                merged_inspection_ledger = _merge_bounded_ledger(
                    merged_inspection_ledger,
                    cached.inspection_ledger,
                    limit=traversal.budget.max_ledger_events,
                    traversal=traversal,
                )
                child_failure_events = _distinct_failed_ledger_events(cached.inspection_ledger)
                if child_failure_events:
                    merged_inspection_ledger = _ensure_required_failure_events(
                        merged_inspection_ledger,
                        child_failure_events,
                        limit=traversal.budget.max_ledger_events,
                        traversal=traversal,
                        failures_already_observed=True,
                    )
                global_work_ids = {
                    str(event.get("work_id", ""))
                    for event in merged_inspection_ledger
                    if event.get("work_id")
                }
                bounded_statuses: list[dict[str, object]] = []
                for status in cached.analyzer_status_events:
                    entry = dict(status)
                    planned = entry.get("planned_work")
                    if isinstance(planned, list):
                        entry["planned_work"] = [
                            item
                            for item in planned
                            if isinstance(item, dict)
                            and str(item.get("work_id", "")) in global_work_ids
                        ][
                            : max(
                                0,
                                traversal.budget.max_ledger_events
                                - _status_planned_work_count(merged_analyzer_status_events),
                            )
                        ]
                    bounded_statuses.append(entry)
                _bounded_extend(
                    merged_analyzer_status_events,
                    bounded_statuses,
                    limit=traversal.budget.max_status_events,
                    traversal=traversal,
                    resource="analyzer status",
                )
                _bounded_extend(
                    merged_llm_call_log,
                    cached.llm_call_log,
                    limit=MAX_INSPECTION_LEDGER_EVENTS,
                    traversal=traversal,
                    resource="LLM call log",
                )
                _bounded_extend(
                    merged_inference_usage,
                    cached.inference_usage,
                    limit=MAX_INSPECTION_LEDGER_EVENTS,
                    traversal=traversal,
                    resource="inference usage",
                )
                annotated_filtered = _annotate_transitive_findings(
                    cached.filtered_findings,
                    source_url=cached.source_url,
                    source_identity=cached.source_identity,
                    source_digest=cached.source_digest,
                    transitive_depth=current_depth,
                )
                annotated_findings = _annotate_transitive_findings(
                    cached.findings,
                    source_url=cached.source_url,
                    source_identity=cached.source_identity,
                    source_digest=cached.source_digest,
                    transitive_depth=current_depth,
                )
                _bounded_extend(
                    merged_filtered_findings,
                    annotated_filtered,
                    limit=traversal.budget.max_findings,
                    traversal=traversal,
                    resource="finding",
                )
                _bounded_extend(
                    merged_findings,
                    annotated_findings,
                    limit=traversal.budget.max_findings,
                    traversal=traversal,
                    resource="finding",
                )
                _bounded_extend(
                    merged_effective_finding_ids,
                    [
                        item
                        for item in cached.effective_finding_ids
                        if item
                        in {
                            finding.finding_id
                            for finding in [*annotated_findings, *annotated_filtered]
                        }
                    ],
                    limit=traversal.budget.max_findings,
                    traversal=traversal,
                    resource="effective finding",
                )

                _bounded_extend(
                    component_metadata,
                    cached.component_metadata,
                    limit=traversal.budget.max_components,
                    traversal=traversal,
                    resource="component metadata",
                )
                if cached.has_executable_scripts:
                    has_executable_scripts = True
                if cached.meta_review_required:
                    merged_meta_review_required = True
                _bounded_extend(
                    merged_components,
                    cached.components,
                    limit=traversal.budget.max_components,
                    traversal=traversal,
                    resource="component",
                )
                _bounded_cache_update(
                    merged_file_cache,
                    cached.file_cache,
                    limit=traversal.budget.max_components,
                    traversal=traversal,
                    resource="provider cache",
                )
                _bounded_cache_update(
                    merged_local_file_cache,
                    cached.local_file_cache,
                    limit=traversal.budget.max_components,
                    traversal=traversal,
                    resource="local cache",
                )
                _bounded_extend(
                    merged_artifact_inventory,
                    cached.artifact_inventory,
                    limit=traversal.budget.max_components,
                    traversal=traversal,
                    resource="artifact inventory",
                )
                _bounded_extend(
                    merged_artifact_references,
                    cached.artifact_references,
                    limit=traversal.budget.max_references,
                    traversal=traversal,
                    resource="artifact reference",
                )

                if current_depth < max_depth:
                    frontier.append(current_depth + 1, cached.refs)
                new_frontier_limitations = frontier.limitations[recorded_frontier_limitations:]
                recorded_frontier_limitations += len(new_frontier_limitations)
                for limitation in new_frontier_limitations:
                    traversal.note_truncation(f"transitive frontier {limitation.resource} limit")
                    merged_inspection_ledger = _merge_bounded_ledger(
                        merged_inspection_ledger,
                        [
                            _transitive_limit_event(
                                limitation,
                                phase="transitive_frontier",
                                path=cached.source_identity + "/SKILL.md",
                            )
                        ],
                        limit=traversal.budget.max_ledger_events,
                        traversal=traversal,
                    )
            except Exception:
                transitive_sources.add(target)
                traversal.note_child_scan_failure(target)
                merged_inspection_ledger = _ensure_required_failure_events(
                    merged_inspection_ledger,
                    [
                        _transitive_child_failure_event(
                            _source_identity(target, "transitive-child-scan-failed")
                        )
                    ],
                    limit=traversal.budget.max_ledger_events,
                    traversal=traversal,
                )
                if format in _MACHINE_READABLE_FORMATS or format is FormatChoice.markdown:
                    logger.warning("Transitive scan failed for %s", target)
                else:
                    console.print(_warning_line(f"Transitive scan failed for {target}"))
            finally:
                if child_result is not None:
                    cleanup_result(child_result)

    for limitation in frontier.limitations[recorded_frontier_limitations:]:
        traversal.note_truncation(f"transitive frontier {limitation.resource} limit")
        merged_inspection_ledger = _merge_bounded_ledger(
            merged_inspection_ledger,
            [
                _transitive_limit_event(
                    limitation,
                    phase="transitive_frontier",
                    path="SKILL.md",
                )
            ],
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
        )

    if traversal.resource_limit_reached:
        required_failure_events = _distinct_failed_ledger_events(merged_inspection_ledger)
        traversal_event = ledger_event(
            outcome=LedgerOutcome.PARTIAL,
            record_type=LedgerRecordType.SYSTEM,
            phase="transitive_traversal",
            path="SKILL.md",
            reason=LedgerReason.OUTPUT_LIMIT,
        )
        merged_inspection_ledger = _merge_bounded_ledger(
            merged_inspection_ledger,
            [dict(traversal_event)],
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
        )
        if required_failure_events:
            merged_inspection_ledger = _ensure_required_failure_events(
                merged_inspection_ledger,
                required_failure_events,
                limit=traversal.budget.max_ledger_events,
                traversal=traversal,
                failures_already_observed=True,
            )

    retained_work_ids = {
        str(event.get("work_id", "")) for event in merged_inspection_ledger if event.get("work_id")
    }
    merged_analyzer_status_events = _bounded_root_status_events(
        merged_analyzer_status_events,
        retained_work_ids=retained_work_ids,
        limit=traversal.budget.max_status_events,
    )

    merged_result: dict[str, object] = {
        **initial_result,
        "filtered_findings": merged_filtered_findings,
        "findings": merged_findings,
        "components": merged_components,
        "component_metadata": _merge_unique_component_metadata(component_metadata),
        "file_cache": merged_file_cache,
        "local_file_cache": merged_local_file_cache,
        "artifact_inventory": merged_artifact_inventory,
        "artifact_references": merged_artifact_references,
        "has_executable_scripts": has_executable_scripts,
        "meta_review_required": merged_meta_review_required,
        "use_llm": initial_result.get("use_llm", not no_llm),
        "llm_requested": initial_result.get("llm_requested", not no_llm),
        "llm_call_log": merged_llm_call_log,
        "inference_usage": merged_inference_usage,
        "effective_finding_ids": list(dict.fromkeys(merged_effective_finding_ids)),
        "inspection_ledger": merged_inspection_ledger,
        "analyzer_status_events": merged_analyzer_status_events,
        "baseline": initial_result.get(
            "baseline", baseline if isinstance(baseline, Baseline) else None
        ),
        "show_suppressed": initial_result.get("show_suppressed", show_suppressed),
        "transitive_targets_scanned": traversal.scanned_targets,
        "transitive_bytes_scanned": traversal.scanned_bytes,
        "transitive_artifacts_scanned": traversal.scanned_artifacts,
        "transitive_truncated": bool(traversal.truncation_reasons),
        "transitive_truncation_reasons": traversal.truncation_reasons,
    }
    llm_requested, llm_enabled = semantic_runtime_intent(merged_result)
    runtime_event = semantic_runtime_ledger_event(
        requested=llm_requested,
        enabled=llm_enabled,
        result=merged_result,
        discovered_modules=sys.modules[__name__].ANALYZER_MODULES,
    )
    pre_runtime_failure_events = _distinct_failed_ledger_events(merged_inspection_ledger)
    if runtime_event is not None and not has_semantic_runtime_event(
        merged_inspection_ledger, runtime_event
    ):
        merged_inspection_ledger = _merge_bounded_ledger(
            merged_inspection_ledger,
            [dict(runtime_event)],
            limit=traversal.budget.max_ledger_events,
            traversal=traversal,
        )
        if pre_runtime_failure_events:
            merged_inspection_ledger = _ensure_required_failure_events(
                merged_inspection_ledger,
                pre_runtime_failure_events,
                limit=traversal.budget.max_ledger_events,
                traversal=traversal,
                failures_already_observed=True,
            )
        merged_result["inspection_ledger"] = merged_inspection_ledger
    if merged_inspection_ledger or merged_analyzer_status_events:
        completeness, effective_ids = finalize_ledger(merged_result)
        merged_result["analysis_completeness"] = completeness
        merged_result["execution_successful"] = completeness["execution_successful"]
        merged_result["effective_finding_ids"] = effective_ids
    report_result = cast(dict[str, object], report(merged_result))
    report_result["analysis_completeness"] = merged_result.get("analysis_completeness", {})
    report_result["meta_review_required"] = merged_meta_review_required
    report_result["temp_dir_for_cleanup"] = initial_result.get("temp_dir_for_cleanup")
    active_findings = _coerce_findings_list(report_result.get("filtered_findings"))
    report_result["transitive_finding_count"] = sum(
        1
        for finding in active_findings
        if isinstance(finding, Finding) and finding.source_url is not None
    )
    report_result["transitive_sources"] = sorted(transitive_sources)
    report_result["transitive_targets_scanned"] = traversal.scanned_targets
    report_result["transitive_bytes_scanned"] = traversal.scanned_bytes
    report_result["transitive_artifacts_scanned"] = traversal.scanned_artifacts
    report_result["transitive_truncated"] = bool(traversal.truncation_reasons)
    report_result["transitive_truncation_reasons"] = traversal.truncation_reasons
    return report_result


def _coerce_component_metadata(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _scan_skill(
    input_path: str,
    format: FormatChoice,
    no_llm: bool,
    baseline: Path | None,
    yara_rules_dir: Path | None,
    verbose: bool,
    show_suppressed: bool,
    transitive_enabled: bool,
    transitive_depth: int,
    transitive_allow_prefix: tuple[str, ...] | list[str] | None,
    transitive_deny_prefix: tuple[str, ...] | list[str] | None,
    transitive_cache: dict[tuple[str, bool], _CachedTransitiveResult] | None = None,
    transitive_traversal: _TransitiveTraversalState | None = None,
    pre_scan_ledger_events: list[dict[str, object]] | None = None,
    source_local_only: bool = False,
    exclude_patterns: list[str] | None = None,
    inspect_dependencies: bool = False,
    use_shipped_baseline: bool = False,
) -> dict[str, object]:
    yara_dir = str(yara_rules_dir.resolve()) if yara_rules_dir else None
    active_visited: set[str] = set()
    if verbose:
        progress_console = console if format is FormatChoice.terminal else err_console
        progress_console.print("[dim]Running scan...[/dim]")
    logger.debug(
        "Scan started: input_path=%s, format=%s, use_llm=%s, transitive=%s",
        input_path,
        format,
        not no_llm,
        transitive_enabled,
    )
    if transitive_enabled and transitive_traversal is None:
        transitive_traversal = _TransitiveTraversalState(cache=transitive_cache or {})
    stream_progress = not verbose and err_console.is_terminal
    run_for_source = _run_graph_scan_for_source
    if inspect_dependencies:
        run_for_source = partial(run_for_source, inspect_dependencies=True)
    if exclude_patterns:
        run_for_source = partial(run_for_source, exclude_patterns=exclude_patterns)
    if use_shipped_baseline:
        run_for_source = partial(run_for_source, use_shipped_baseline=True)
    if pre_scan_ledger_events:
        result = run_for_source(
            input_path=input_path,
            format=format,
            no_llm=no_llm,
            yara_dir=yara_dir,
            baseline=baseline,
            show_suppressed=show_suppressed,
            transitive_traversal=transitive_traversal,
            initial_inspection_ledger=pre_scan_ledger_events,
            source_local_only=source_local_only,
            stream_progress=stream_progress,
        )
    else:
        result = run_for_source(
            input_path=input_path,
            format=format,
            no_llm=no_llm,
            yara_dir=yara_dir,
            baseline=baseline,
            show_suppressed=show_suppressed,
            transitive_traversal=transitive_traversal,
            source_local_only=source_local_only,
            stream_progress=stream_progress,
        )
    if use_shipped_baseline:
        try:
            selected = result.get("baseline_path")
            _shipped_baseline_notice(
                Path(selected) if isinstance(selected, str) else None, Path(input_path), True
            )
        except BaseException:
            cleanup_result(result)
            raise
    if not transitive_enabled:
        return result
    if transitive_traversal is None:  # Defensive: transitive scans initialize before root work.
        transitive_traversal = _TransitiveTraversalState(cache=transitive_cache or {})
    transitive_allow_prefix, transitive_deny_prefix = transitive.normalize_prefixes(
        transitive_allow_prefix, transitive_deny_prefix
    )
    try:
        active_visited.add(transitive.canonicalize_source_identity(input_path))
    except ValueError:
        pass
    # The root graph has returned, so its tracker no longer guards the root's
    # temp dir. If the transitive phase is interrupted or raises, nothing is
    # returned for the caller's cleanup_result, so remove it here. On success
    # the merged result carries the same temp_dir_for_cleanup for the caller.
    try:
        scan_transitive = (
            partial(_scan_transitive, inspect_dependencies=True)
            if inspect_dependencies
            else _scan_transitive
        )
        return scan_transitive(
            initial_result=result,
            format=format,
            no_llm=no_llm,
            max_depth=transitive_depth,
            transitive_allow_prefix=transitive_allow_prefix,
            transitive_deny_prefix=transitive_deny_prefix,
            baseline=baseline,
            show_suppressed=show_suppressed,
            visited=active_visited,
            scan_cache=transitive_cache,
            yara_dir=yara_dir,
            traversal=transitive_traversal,
            source_local_only=source_local_only,
        )
    except BaseException:
        cleanup_result(result)
        raise


def _multi_skill_public_record_count(result: dict[str, object]) -> int:
    """Count bounded active and suppressed occurrence records in one child report."""
    count = 0
    active = effective_findings(result)
    suppressed = result.get("suppressed_findings")
    candidates: list[object] = [*active]
    if isinstance(suppressed, list):
        candidates.extend(
            finding
            for item in suppressed
            if (finding := getattr(item, "finding", None)) is not None
        )
    for finding in candidates:
        occurrences = getattr(finding, "occurrences", None)
        count += max(1, len(occurrences)) if isinstance(occurrences, list) else 1
        if count > _MULTI_SKILL_MAX_PUBLIC_RECORDS:
            return count
    return count


def _multi_skill_analysis_completeness(
    *,
    total_skills: int,
    complete_skills: int,
    partial_skills: int,
    failed_skills: int,
    omitted_skills: int,
    limitations: list[str],
    excluded_root_paths: tuple[str, ...] = (),
) -> dict[str, object]:
    """Build one conservative machine-readable completeness summary for recursion."""
    is_complete = (
        not limitations and not partial_skills and not failed_skills and not omitted_skills
    )
    execution_successful = failed_skills == 0
    status = "failed" if not execution_successful else "complete" if is_complete else "partial"
    denominator = max(1, total_skills)
    completeness: dict[str, object] = {
        "is_complete": is_complete,
        "execution_successful": execution_successful,
        "status": status,
        "coverage_percent": round(100.0 * complete_skills / denominator, 2),
        "fully_inspected_files": complete_skills,
        "partially_inspected_files": partial_skills,
        "entirely_uninspected_files": failed_skills + omitted_skills,
        "total_files": total_skills,
        "limitations": limitations,
        "scope": "recursive_skills",
    }
    if excluded_root_paths:
        reason = LedgerReason.EXCLUDED_DIRECTORY
        exclusions: list[InspectionLedgerException] = [
            {
                "outcome": LedgerOutcome.OUT_OF_SCOPE,
                "phase": "multi_skill_discovery",
                "reason_code": reason,
                "message": REASON_MESSAGES[reason],
                "path": path,
                "start_line": None,
                "end_line": None,
                "fatal": False,
            }
            for path in excluded_root_paths
        ]
        completeness["scope_exclusions"] = exclusions
    return completeness


_RECURSIVE_SERIALIZED_OUTPUT_LIMIT_PREFIX = "recursive serialized report character budget "
_RECURSIVE_CHILD_SCAN_FAILED_MESSAGE = "A recursive child scan failed before complete inspection."


def _multi_skill_sarif_notifications(
    completeness: dict[str, object],
) -> list[dict[str, object]]:
    """Project exact aggregate outcomes without inventing an output-limit cause."""
    notifications: list[dict[str, object]] = []
    status = str(completeness.get("status", "partial"))
    raw_limitations = completeness.get("limitations")
    limitations = (
        [str(item) for item in raw_limitations if isinstance(item, str)]
        if isinstance(raw_limitations, list)
        else []
    )
    if status == "failed":
        notifications.append(
            {
                "message": {"text": "One or more recursive skill scans failed."},
                "level": "error",
                "properties": {"kind": "inspection_failure"},
            }
        )
    for limitation in limitations:
        properties: dict[str, object] = {"kind": "inspection_limitation"}
        if limitation.startswith(_RECURSIVE_SERIALIZED_OUTPUT_LIMIT_PREFIX):
            properties["reasonCode"] = LedgerReason.OUTPUT_LIMIT.value
        notifications.append(
            {
                "message": {"text": limitation},
                "level": "warning",
                "properties": properties,
            }
        )
    if status == "partial" and not limitations:
        notifications.append(
            {
                "message": {
                    "text": "One or more recursive skill scans were incomplete; "
                    "see child run notifications."
                },
                "level": "warning",
                "properties": {"kind": "inspection_limitation"},
            }
        )
    return notifications


def _multi_skill_text_completeness(completeness: dict[str, object]) -> str:
    """Render the aggregate state without downgrading a failed child to partial."""
    status = str(completeness.get("status", "partial"))
    raw_limitations = completeness.get("limitations")
    limitations = (
        [str(item) for item in raw_limitations if isinstance(item, str)]
        if isinstance(raw_limitations, list)
        else []
    )
    if status == "failed":
        limitations.insert(0, "One or more recursive skill scans failed.")
    elif status == "partial" and not limitations:
        limitations.append("One or more recursive skill scans were incomplete.")
    details = "\n".join(f"- {item}" for item in limitations)
    exclusions = cast("list[InspectionLedgerException]", completeness.get("scope_exclusions", []))
    if exclusions:
        scope_details = "\n".join(f"- `{row['path']}` — {row['message']}" for row in exclusions)
        details = "\n\n".join(filter(None, (details, f"Scope exclusions\n\n{scope_details}")))
    return f"--- Recursive Inspection Completeness ---\n\nStatus: {status}\n\n{details}"


def _multi_skill_risk_assessment(
    max_score: int,
    *,
    execution_failed: bool,
    analysis_incomplete: bool,
) -> dict[str, object]:
    """Return bounded aggregate risk evidence independent of child retention."""
    severity, recommendation = risk_severity_and_recommendation(max_score)
    if execution_failed:
        recommendation = "DO_NOT_INSTALL"
    elif analysis_incomplete and recommendation == "SAFE":
        recommendation = "CAUTION"
    return {
        "max_risk_score": max_score,
        "severity": severity,
        "recommendation": recommendation,
    }


def _multi_skill_text_summary(
    completeness: dict[str, object],
    risk_assessment: dict[str, object],
) -> str:
    """Render aggregate risk and completeness even when child bodies are omitted."""
    recommendation = str(risk_assessment.get("recommendation", "CAUTION")).replace("_", " ")
    risk = (
        "--- Recursive Risk Assessment ---\n\n"
        f"Maximum score: {risk_assessment.get('max_risk_score', 0)}/100\n\n"
        f"Severity: {risk_assessment.get('severity', 'LOW')}\n\n"
        f"Recommendation: {recommendation}"
    )
    return f"{risk}\n\n{_multi_skill_text_completeness(completeness)}"


# uriBaseId key used to scope recursive child-run result URIs to their own
# skill directory (SARIF 2.1.0 section 3.14.14).
_RECURSIVE_SARIF_URI_BASE_ID = "SKILLROOT"


def _multi_skill_sarif_report(
    processed_skills: list[SkillDirectory],
    results: list[dict[str, object]],
    completeness: dict[str, object],
    risk_assessment: dict[str, object] | None = None,
) -> dict[str, object]:
    """Merge bounded child SARIF runs and append one aggregate invocation run."""
    runs: list[dict[str, object]] = []
    for skill, result in zip(processed_skills, results, strict=True):
        sarif = result.get("sarif_report")
        if not isinstance(sarif, dict):
            parsed = _recursive_json_payload(result)
            sarif = parsed if isinstance(parsed, dict) and "runs" in parsed else None
        if not isinstance(sarif, dict):
            continue
        child_runs = sarif.get("runs")
        if not isinstance(child_runs, list):
            continue
        for raw_run in child_runs:
            if not isinstance(raw_run, dict):
                continue
            run = deepcopy(raw_run)
            properties = run.get("properties")
            run_properties = dict(properties) if isinstance(properties, dict) else {}
            run_properties["recursiveSkill"] = {
                "name": skill.name,
                "path": skill.relative_path,
            }
            run["properties"] = run_properties
            # SARIF 2.1.0 sections 3.4.4 and 3.14.14: scope each child run's
            # skill-relative URIs to its own skill directory so results from
            # different skills stop collapsing onto one repo-root-relative
            # path. Single-skill output is untouched: only recursive merges
            # set uriBaseId.
            relative = quote(skill.path.name, safe="")
            if relative:
                for result in run.get("results", []):
                    if not isinstance(result, dict):
                        continue
                    for location in result.get("locations", []):
                        physical = (
                            location.get("physicalLocation") if isinstance(location, dict) else None
                        )
                        artifact = (
                            physical.get("artifactLocation") if isinstance(physical, dict) else None
                        )
                        if isinstance(artifact, dict):
                            provenance = artifact.get("properties")
                            if isinstance(provenance, dict) and any(
                                key in provenance
                                for key in (
                                    "sourceIdentity",
                                    "sourceUrl",
                                    "sourceDigest",
                                    "transitiveDepth",
                                )
                            ):
                                continue
                            artifact["uriBaseId"] = _RECURSIVE_SARIF_URI_BASE_ID
                run["originalUriBaseIds"] = {
                    "SCANROOT": {"uri": skill.path.parent.resolve().as_uri() + "/"},
                    _RECURSIVE_SARIF_URI_BASE_ID: {
                        "uri": f"{relative}/",
                        "uriBaseId": "SCANROOT",
                    },
                }
            runs.append(run)

    invocation_properties: dict[str, object] = {"analysisCompleteness": completeness}
    if risk_assessment is not None:
        invocation_properties["riskAssessment"] = {
            "maxRiskScore": risk_assessment.get("max_risk_score", 0),
            "severity": risk_assessment.get("severity", "LOW"),
            "recommendation": risk_assessment.get("recommendation", "CAUTION"),
        }
    aggregate_invocation: dict[str, object] = {
        "executionSuccessful": bool(completeness.get("execution_successful", False)),
        "properties": invocation_properties,
    }
    notifications = _multi_skill_sarif_notifications(completeness)
    if notifications:
        aggregate_invocation["toolExecutionNotifications"] = notifications
    runs.append(
        {
            "tool": {"driver": {"name": "skillspector", "version": __version__}},
            "results": [],
            "invocations": [aggregate_invocation],
            "properties": {"kind": "recursiveAggregate"},
        }
    )
    merged: dict[str, object] = {
        "$schema": SARIF_SCHEMA_URI,
        "version": "2.1.0",
        "runs": runs,
    }
    validate_sarif_report(merged)
    return merged


def _mark_recursive_output_limited(
    completeness: dict[str, object],
) -> tuple[dict[str, object], list[str]]:
    """Return a fail-closed aggregate state after serialized output overflow."""
    reason = (
        f"recursive serialized report character budget {_MULTI_SKILL_MAX_REPORT_CHARACTERS} reached"
    )
    # Once the output itself is over budget, retain one content-free sentinel
    # rather than copying a potentially large list of earlier limitations into
    # the fallback document.
    bounded_limitations = [reason]
    limited = dict(completeness)
    limited["is_complete"] = False
    if limited.get("status") != "failed":
        limited["status"] = "partial"
    limited["limitations"] = bounded_limitations
    return limited, bounded_limitations


def _ensure_recursive_output_bound(rendered: str) -> None:
    """Refuse to write a recursive report that exceeds its public ceiling."""
    if len(rendered) > _MULTI_SKILL_MAX_REPORT_CHARACTERS:
        raise RuntimeError("recursive report could not fit the configured output budget")


def _scan_multi_skill(
    detection: MultiSkillDetectionResult,
    format: FormatChoice,
    output: Path | None,
    no_llm: bool,
    baseline: Path | None = None,
    show_suppressed: bool = False,
    transitive_enabled: bool = False,
    transitive_depth: int = 1,
    transitive_allow_prefix: tuple[str, ...] | list[str] | None = None,
    transitive_deny_prefix: tuple[str, ...] | list[str] | None = None,
    yara_dir: str | None = None,
    verbose: bool = False,
    fail_on_incomplete: bool = False,
    min_coverage: float | None = None,
    fail_on_findings: bool = False,
    max_skills: int | None = None,
    inspect_dependencies: bool = False,
    **legacy_kwargs: object,
) -> None:
    """Scan each detected sub-skill independently and produce a combined report."""
    skill_limit = _MULTI_SKILL_MAX_SKILLS if max_skills is None else max_skills
    if isinstance(skill_limit, bool) or not isinstance(skill_limit, int) or skill_limit < 1:
        raise ValueError("max_skills must be a positive integer")
    if yara_dir is None and isinstance(legacy_kwargs.get("yara_rules_dir"), Path):
        yara_dir = str(legacy_kwargs["yara_rules_dir"])
    skills = detection.skills
    # Check every discovered input before scan budgets can omit a child.
    for skill in skills:
        _validate_report_destination(skill.primary_path or skill.path, output)
    progress_console = (
        err_console if output is None and format is not FormatChoice.terminal else console
    )
    progress_console.print(
        f"[bold]Multi-skill directory detected:[/bold] {len(skills)} skills found\n"
    )

    shared_transitive_cache: dict[tuple[str, bool], _CachedTransitiveResult] = {}
    shared_transitive_traversal = _TransitiveTraversalState(
        cache=shared_transitive_cache,
        budget=_TransitiveBudget(
            max_bytes=_TRANSITIVE_MAX_BYTES if transitive_enabled else MAX_WORKFLOW_BYTES
        ),
    )
    results: list[dict[str, object]] = []
    processed_skills: list[SkillDirectory] = []
    max_score = 0
    execution_failed = False
    transitive_finding_count = 0
    transitive_sources: set[str] = set()
    analysis_incomplete = not detection.complete
    has_findings = False
    aggregate_limitations = [
        f"recursive discovery {limitation.resource} limit reached"
        for limitation in detection.limitations[:256]
        # Symlink omissions get their own clearer aggregate message below;
        # listing the generic one too would double-report the same entries.
        if limitation.resource != "multi_skill_symlinked_entry"
        or not detection.omitted_symlink_entries
    ]
    retained_public_records = 0
    retained_report_characters = 0
    complete_skill_count = 0
    partial_skill_count = 0
    failed_skill_count = 0
    coverage_failed = False

    for i, skill in enumerate(skills, 1):
        if i > skill_limit:
            analysis_incomplete = True
            aggregate_limitations.append(f"recursive skill count budget {skill_limit} reached")
            progress_console.print(
                f"[yellow]Recursive skill count budget {skill_limit} reached.[/yellow] "
                "Use --recursive --max-skills N with a larger positive N, or scan "
                "sub-skills separately. Other aggregate safety limits still apply."
            )
            break
        if retained_public_records >= _MULTI_SKILL_MAX_PUBLIC_RECORDS:
            analysis_incomplete = True
            aggregate_limitations.append(
                f"recursive public finding record budget {_MULTI_SKILL_MAX_PUBLIC_RECORDS} reached"
            )
            break
        if retained_report_characters >= _MULTI_SKILL_MAX_REPORT_CHARACTERS:
            analysis_incomplete = True
            aggregate_limitations.append(
                f"recursive report character budget {_MULTI_SKILL_MAX_REPORT_CHARACTERS} reached"
            )
            break
        if not shared_transitive_traversal.can_scan_more():
            analysis_incomplete = True
            aggregate_limitations.extend(shared_transitive_traversal.truncation_reasons)
            break
        progress_console.print(
            Text.assemble(
                f"  [{i}/{len(skills)}] Scanning ",
                (_visible_terminal_text(str(skill.name)), "bold"),
                f" ({_visible_terminal_text(str(skill.relative_path))}/)",
            )
        )
        result: dict[str, object] | None = None
        try:
            scan_skill = (
                partial(_scan_skill, inspect_dependencies=True)
                if inspect_dependencies
                else _scan_skill
            )
            result = scan_skill(
                input_path=str(skill.path),
                format=format,
                no_llm=no_llm,
                baseline=baseline,
                yara_rules_dir=Path(yara_dir) if yara_dir else None,
                verbose=verbose,
                show_suppressed=show_suppressed,
                transitive_enabled=transitive_enabled,
                transitive_depth=transitive_depth,
                transitive_allow_prefix=transitive_allow_prefix,
                transitive_deny_prefix=transitive_deny_prefix,
                transitive_cache=shared_transitive_cache,
                transitive_traversal=shared_transitive_traversal,
                source_local_only=skill.local_only,
            )
            child_failed = result.get("execution_successful") is False
            if not child_failed and _coverage_below_threshold(result, min_coverage):
                coverage_failed = True
            completeness_value = result.get("analysis_completeness")
            child_partial = (
                not child_failed
                and isinstance(completeness_value, dict)
                and not bool(completeness_value.get("is_complete", True))
            )
            score = result.get("risk_score") or 0
            try:
                score = int(score)
            except (TypeError, ValueError):
                score = 0
            child_transitive_count = result.get("transitive_finding_count")
            child_transitive_increment = (
                child_transitive_count if isinstance(child_transitive_count, int) else 0
            )
            child_transitive_sources = _coerce_str_path_list(result.get("transitive_sources"))
            severity = result.get("risk_severity") or "LOW"
            progress_console.print(f"         Score: {score}/100 ({severity})\n")

            result_body = _result_body(result)
            result_characters = len(result_body)
            result_records = _multi_skill_public_record_count(result)
            child_has_findings = bool(effective_findings(result))
            exceeds_record_limit = (
                retained_public_records + result_records > _MULTI_SKILL_MAX_PUBLIC_RECORDS
            )
            exceeds_character_limit = (
                retained_report_characters + result_characters > _MULTI_SKILL_MAX_REPORT_CHARACTERS
            )
            if exceeds_record_limit or exceeds_character_limit:
                cleanup_result(result)

            if child_failed:
                execution_failed = True
                failed_skill_count += 1
            elif child_partial:
                analysis_incomplete = True
                partial_skill_count += 1
            else:
                complete_skill_count += 1
            max_score = max(max_score, score)
            transitive_finding_count += child_transitive_increment
            transitive_sources.update(child_transitive_sources)
            has_findings = has_findings or child_has_findings

            if exceeds_record_limit or exceeds_character_limit:
                analysis_incomplete = True
                if exceeds_record_limit:
                    aggregate_limitations.append(
                        "recursive public finding record budget "
                        f"{_MULTI_SKILL_MAX_PUBLIC_RECORDS} reached"
                    )
                if exceeds_character_limit:
                    aggregate_limitations.append(
                        "recursive report character budget "
                        f"{_MULTI_SKILL_MAX_REPORT_CHARACTERS} reached"
                    )
                break
            results.append(result)
            processed_skills.append(skill)
            retained_public_records += result_records
            retained_report_characters += result_characters
        except Exception:
            if result is not None and not any(item is result for item in results):
                try:
                    cleanup_result(result)
                except Exception:
                    logger.warning("Recursive child result cleanup failed")
            error_message = _RECURSIVE_CHILD_SCAN_FAILED_MESSAGE
            err_console.print(f"         [red]Error:[/red] {error_message}\n")
            execution_failed = True
            failed_skill_count += 1
            results.append({"skill_name": skill.name, "error": error_message})
            processed_skills.append(skill)

    scanned_skill_count = complete_skill_count + partial_skill_count + failed_skill_count
    unscanned_skill_count = max(
        0,
        len(skills) - scanned_skill_count,
    )
    output_omitted_skill_count = max(0, scanned_skill_count - len(processed_skills))
    omitted_symlink_entry_count = detection.omitted_symlink_entries
    if omitted_symlink_entry_count:
        analysis_incomplete = True
        aggregate_limitations.append(
            f"{omitted_symlink_entry_count} symlinked recursive skill(s) omitted "
            "(directory symlinks are not followed)"
        )
        progress_console.print(
            f"[yellow]Warning:[/yellow] {omitted_symlink_entry_count} symlinked skill "
            "directories were skipped during recursive discovery and are not "
            "included in this scan."
        )
    skills_omitted_total = unscanned_skill_count + omitted_symlink_entry_count
    if output_omitted_skill_count:
        analysis_incomplete = True
        aggregate_limitations.append(
            f"{output_omitted_skill_count} scanned recursive skill report(s) omitted "
            "after an aggregate output limit"
        )
    if unscanned_skill_count:
        analysis_incomplete = True
        aggregate_limitations.append(
            f"{unscanned_skill_count} recursive skill(s) unscanned after an aggregate limit"
        )
    if _omissions_fail_threshold(skills_omitted_total, min_coverage):
        coverage_failed = True
    aggregate_limitations = list(dict.fromkeys(aggregate_limitations))[:256]
    aggregate_completeness = _multi_skill_analysis_completeness(
        total_skills=len(skills) + omitted_symlink_entry_count,
        complete_skills=complete_skill_count,
        partial_skills=partial_skill_count,
        failed_skills=failed_skill_count,
        omitted_skills=skills_omitted_total,
        limitations=aggregate_limitations,
        excluded_root_paths=detection.excluded_root_paths,
    )
    analysis_incomplete = not bool(aggregate_completeness["is_complete"])
    aggregate_risk_assessment = _multi_skill_risk_assessment(
        max_score,
        execution_failed=execution_failed,
        analysis_incomplete=analysis_incomplete,
    )

    progress_console.print("\n[bold]═══ Multi-Skill Summary ═══[/bold]\n")
    progress_console.print(
        f"  {'Skill':<30} {'Score':<8} {'Severity':<12} {'Findings':<10} {'Execution':<10}"
    )
    progress_console.print(f"  {'─' * 30} {'─' * 8} {'─' * 12} {'─' * 10} {'─' * 10}")

    for skill, result in zip(processed_skills, results, strict=True):
        if "error" in result:
            progress_console.print(
                Text(
                    f"  {_visible_terminal_text(str(skill.name)):<30} {'ERROR':<8} {'—':<12} {'—':<10} {'error':<10}"
                )
            )
            continue
        score = result.get("risk_score", 0)
        severity = result.get("risk_severity", "LOW")
        finding_count = len(effective_findings(result))
        execution = "failed" if result.get("execution_successful") is False else "successful"
        progress_console.print(
            Text(
                f"  {_visible_terminal_text(str(skill.name)):<30} {score:<8} {severity:<12} {finding_count:<10} {execution:<10}"
            )
        )
    if output_omitted_skill_count:
        progress_console.print(
            f"  {'<output omitted>':<30} {'—':<8} {'—':<12} "
            f"{output_omitted_skill_count:<10} {'partial':<10}"
        )
    if unscanned_skill_count:
        progress_console.print(
            f"  {'<unscanned>':<30} {'—':<8} {'—':<12} {unscanned_skill_count:<10} {'partial':<10}"
        )
    if omitted_symlink_entry_count:
        progress_console.print(
            f"  {'<symlink omitted>':<30} {'—':<8} {'—':<12} "
            f"{omitted_symlink_entry_count:<10} {'skipped':<10}"
        )
    if output_omitted_skill_count or unscanned_skill_count or omitted_symlink_entry_count:
        progress_console.print(
            "[yellow]Recursive scan incomplete:[/yellow] one or more skills were omitted "
            "after an aggregate safety limit or skipped as symlinks."
        )

    if format == FormatChoice.json:
        combined: dict[str, object] = {
            "multi_skill": True,
            "skill_count": len(skills),
            "max_risk_score": max_score,
            "risk_severity": aggregate_risk_assessment["severity"],
            "execution_successful": not execution_failed,
            "risk_recommendation": aggregate_risk_assessment["recommendation"],
            "analysis_completeness": aggregate_completeness,
            "skills_scanned": scanned_skill_count,
            "skills_omitted": skills_omitted_total,
            "skills_output_omitted": output_omitted_skill_count,
            "public_finding_records": retained_public_records,
            "report_characters": retained_report_characters,
            "transitive_finding_count": transitive_finding_count,
            "transitive_sources": sorted(transitive_sources),
            "skills": [],
        }
        combined_skills = cast(list[dict[str, object]], combined["skills"])
        for skill, result in zip(processed_skills, results, strict=True):
            if "error" in result:
                combined_skills.append({"name": skill.name, "error": result["error"]})
            else:
                payload = _recursive_json_payload(result) or {}
                finding_count = len(effective_findings(result))
                entry = {
                    "name": skill.name,
                    "path": skill.relative_path,
                    "risk_score": result.get("risk_score", 0),
                    "risk_severity": result.get("risk_severity", "LOW"),
                    "finding_count": finding_count,
                    "execution_successful": result.get("execution_successful", True),
                    "transitive_finding_count": result.get("transitive_finding_count", 0),
                    "transitive_sources": result.get("transitive_sources", []),
                }
                entry.update(payload)
                entry["name"] = skill.name
                entry["path"] = skill.relative_path
                entry["risk_score"] = result.get("risk_score", 0)
                entry["risk_severity"] = result.get("risk_severity", "LOW")
                entry["finding_count"] = finding_count
                entry["execution_successful"] = result.get("execution_successful", True)
                combined_skills.append(entry)
                entry["transitive_finding_count"] = result.get("transitive_finding_count", 0)
                entry["transitive_sources"] = result.get("transitive_sources", [])
        if output_omitted_skill_count:
            combined_skills.append(
                {
                    "omitted": True,
                    "omitted_count": output_omitted_skill_count,
                    "reason": "aggregate_output_limit",
                }
            )
        if unscanned_skill_count:
            combined_skills.append(
                {
                    "omitted": True,
                    "omitted_count": unscanned_skill_count,
                    "reason": "aggregate_scan_limit",
                }
            )
        if omitted_symlink_entry_count:
            combined_skills.append(
                {
                    "omitted": True,
                    "omitted_count": omitted_symlink_entry_count,
                    "reason": "symlink_not_followed",
                }
            )
        rendered = json.dumps(combined, indent=2)
        if len(rendered) > _MULTI_SKILL_MAX_REPORT_CHARACTERS:
            analysis_incomplete = True
            aggregate_completeness, aggregate_limitations = _mark_recursive_output_limited(
                aggregate_completeness,
            )
            combined = {
                "multi_skill": True,
                "skill_count": len(skills),
                "max_risk_score": max_score,
                "risk_severity": aggregate_risk_assessment["severity"],
                "execution_successful": not execution_failed,
                "risk_recommendation": _multi_skill_risk_assessment(
                    max_score,
                    execution_failed=execution_failed,
                    analysis_incomplete=True,
                )["recommendation"],
                "analysis_completeness": aggregate_completeness,
                "skills_scanned": scanned_skill_count,
                "skills_omitted": unscanned_skill_count,
                "skills_output_omitted": scanned_skill_count,
                "public_finding_records": 0,
                "transitive_finding_count": transitive_finding_count,
                "transitive_sources": [],
                "skills": [
                    {
                        "omitted": True,
                        "omitted_count": scanned_skill_count,
                        "reason": "aggregate_output_limit",
                    }
                ],
            }
            rendered = json.dumps(combined, indent=2)
        _ensure_recursive_output_bound(rendered)
        if output is not None:
            write_text_no_follow(output, rendered)
            progress_console.print(_literal_line("Combined report saved to", "green", output))
        else:
            sys.stdout.write(rendered)
    elif format == FormatChoice.sarif:
        merged_sarif = _multi_skill_sarif_report(
            processed_skills,
            results,
            aggregate_completeness,
            aggregate_risk_assessment,
        )
        rendered = json.dumps(merged_sarif, indent=2)
        if len(rendered) > _MULTI_SKILL_MAX_REPORT_CHARACTERS:
            analysis_incomplete = True
            aggregate_completeness, aggregate_limitations = _mark_recursive_output_limited(
                aggregate_completeness,
            )
            aggregate_risk_assessment = _multi_skill_risk_assessment(
                max_score,
                execution_failed=execution_failed,
                analysis_incomplete=True,
            )
            merged_sarif = _multi_skill_sarif_report(
                [], [], aggregate_completeness, aggregate_risk_assessment
            )
            rendered = json.dumps(merged_sarif, indent=2)
        _ensure_recursive_output_bound(rendered)
        if output is not None:
            write_text_no_follow(output, rendered)
            progress_console.print(_literal_line("Combined report saved to", "green", output))
        else:
            sys.stdout.write(rendered)
    else:
        sections: list[str] = []
        for skill, result in zip(processed_skills, results, strict=True):
            if "error" not in result:
                sections.append(f"--- {skill.relative_path} ---\n\n{_result_body(result)}")
        if analysis_incomplete or detection.excluded_root_paths:
            sections.append(
                _multi_skill_text_summary(
                    aggregate_completeness,
                    aggregate_risk_assessment,
                )
            )
        rendered = "\n\n".join(sections)
        if len(rendered) > _MULTI_SKILL_MAX_REPORT_CHARACTERS:
            analysis_incomplete = True
            aggregate_completeness, aggregate_limitations = _mark_recursive_output_limited(
                aggregate_completeness,
            )
            aggregate_risk_assessment = _multi_skill_risk_assessment(
                max_score,
                execution_failed=execution_failed,
                analysis_incomplete=True,
            )
            rendered = _multi_skill_text_summary(
                aggregate_completeness,
                aggregate_risk_assessment,
            )
        _ensure_recursive_output_bound(rendered)
        if output is not None:
            write_text_no_follow(output, rendered)
            progress_console.print(_literal_line("Combined report saved to", "green", output))
        elif format is FormatChoice.terminal:
            console.print(rendered, markup=False, emoji=False)
        else:
            sys.stdout.write(rendered)

    for result in results:
        cleanup_result(result)

    if execution_failed:
        raise typer.Exit(code=2)
    if fail_on_incomplete and analysis_incomplete:
        raise typer.Exit(code=1)
    if fail_on_findings and has_findings:
        raise typer.Exit(code=1)
    if coverage_failed:
        raise typer.Exit(code=1)
    if max_score > RISK_THRESHOLD:
        raise typer.Exit(code=1)


@app.command()
def mcp(
    transport: Annotated[
        TransportChoice,
        typer.Option(
            "--transport",
            "-t",
            help="Transport: FastMCP stdio for local CLI agents, http for loopback HTTP clients.",
            case_sensitive=False,
        ),
    ] = TransportChoice.stdio,
    host: Annotated[
        str,
        typer.Option(
            "--host", help="Loopback IP to bind (http transport only; localhost is accepted)."
        ),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option("--port", help="Port to bind (http transport only)."),
    ] = 8000,
) -> None:
    """
    Run SkillSpector as an MCP server.

    Exposes a single tool, ``scan_skill``, so any MCP-capable agent (Claude Code,
    Codex CLI, Gemini CLI) can scan a skill locally and gate installs
    on the verdict.

    Requires the optional mcp extra. Reinstall the GitHub tool package with
    that extra enabled, as shown in the README Quick Start section.

    Examples:

        skillspector mcp                      # FastMCP stdio for local CLI agents
        skillspector mcp --transport http --port 8000
    """
    try:
        from skillspector.mcp_server import run as run_mcp

        run_mcp(transport=transport.value, host=host, port=port)
    except (ModuleNotFoundError, ValueError) as e:
        err_console.print(_error_line(e))
        raise typer.Exit(code=2) from e


@app.command()
def baseline(
    input_path: Annotated[
        str,
        typer.Argument(
            help="Path or URL to scan. Supports: Git URL, file URL, zip file, .md file, or directory.",
        ),
    ],
    output: Annotated[
        Path,
        typer.Option(
            "--output",
            "-o",
            help="Baseline file (YAML; .json writes JSON), or - for JSON on stdout.",
        ),
    ] = Path(".skillspector-baseline.yaml"),
    no_llm: Annotated[
        bool,
        typer.Option(
            "--no-llm",
            help="Skip LLM analysis when generating the baseline (static analysis only).",
        ),
    ] = False,
    yara_rules_dir: Annotated[
        Path | None,
        typer.Option(
            "--yara-rules-dir",
            help="Directory containing additional YARA rule files (.yar/.yara) to load alongside built-in rules.",
        ),
    ] = None,
    reason: Annotated[
        str,
        typer.Option(
            "--reason",
            help="Reason recorded for every suppressed finding in the baseline.",
        ),
    ] = "Accepted finding (auto-generated baseline)",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-V", help="Show detailed progress."),
    ] = False,
) -> None:
    """
    Generate a baseline file that suppresses every finding in the current scan.

    Run this once to accept all existing findings, then commit the file and pass
    it to future scans with --baseline so only NEW findings are reported.

    Examples:

        skillspector baseline ./my-skill/
        skillspector baseline ./my-skill/ -o team-baseline.yaml --no-llm
        skillspector scan ./my-skill/ --baseline .skillspector-baseline.yaml
    """
    _exit_on_unsupported_llm_controls(no_llm)
    result = None
    try:
        to_stdout = str(output) == "-"
        if not to_stdout:
            require_secure_file_output()
            _validate_report_destination(Path(input_path), output)
        if verbose:
            set_level("DEBUG")
            err_console.print("[dim]Scanning to build baseline...[/dim]")
        # output_format is irrelevant here; we consume findings, not report_body.
        state = _scan_state(
            input_path,
            FormatChoice.json,
            no_llm,
            yara_rules_dir=str(yara_rules_dir.resolve()) if yara_rules_dir else None,
        )
        if not to_stdout:
            state["baseline_path"] = os.path.abspath(output.expanduser())
        result = graph.invoke(state)
        completeness_value = result.get("analysis_completeness")
        completeness = completeness_value if isinstance(completeness_value, dict) else {}
        if (
            result.get("execution_successful") is False
            or completeness.get("execution_successful") is False
            or completeness.get("status") == "failed"
        ):
            raise ValueError(
                "Cannot generate baseline because scan execution failed. "
                "Run 'skillspector scan' to inspect analysis completeness, "
                "resolve the failures, and retry."
            )
        if completeness.get("is_complete") is False or completeness.get("status") == "partial":
            err_console.print(
                "[yellow]Warning:[/yellow] Scan analysis is incomplete; the baseline "
                "accepts only observed findings and coverage gaps remain."
            )
        # Fingerprint every occurrence the next scan checks. The reported
        # findings are deduplicated and keep only one occurrence's evidence.
        findings = result["active_findings"]
        data = build_baseline_dict(
            findings,
            reason=reason,
            # Exact fingerprints must use the same local-only cache that fed
            # deterministic analyzers. The provider-safe cache intentionally
            # omits hidden, binary, and nested content.
            file_cache=result.get("local_file_cache") or result.get("file_cache") or {},
            scanner_version=__version__,
        )
        if to_stdout:
            sys.stdout.write(serialize_baseline(data, json_output=True) + "\n")
        else:
            dump_baseline(data, output)
            console.print(
                _literal_line(
                    f"Wrote baseline with {len(findings)} suppressed finding(s) to", "green", output
                )
            )
    except typer.Exit:
        raise
    except (FileNotFoundError, ValueError) as e:
        err_console.print(_error_line(e))
        raise typer.Exit(code=2) from e
    except Exception as e:
        if verbose:
            err_console.print_exception()
        else:
            err_console.print(_error_line(e))
        raise typer.Exit(code=2) from e
    finally:
        if result is not None:
            cleanup_result(result)


if __name__ == "__main__":
    app()
