# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Write reports without following attacker-replaced paths."""

from __future__ import annotations

import errno
import os
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from secrets import token_hex
from stat import S_ISREG, filemode

from skillspector.input_handler import _normalize_root_owned_alias

_SECURE_OUTPUT_SUPPORTED = (
    hasattr(os, "O_NOFOLLOW")
    and hasattr(os, "O_DIRECTORY")
    and {os.open, os.stat, os.rename, os.unlink} <= os.supports_dir_fd
    and os.stat in os.supports_follow_symlinks
)


def require_secure_file_output() -> None:
    """Reject unsupported file writes before starting potentially costly scans."""
    if not _SECURE_OUTPUT_SUPPORTED:
        raise ValueError(
            "Safe file output is unsupported on this platform. "
            "For scan or batch reports, omit --output; for baselines, use --output -. "
            "Redirect stdout to a new file outside the scan target, and replace "
            "an existing report only after the command succeeds."
        )


def restrict_temporary_access(descriptor: int, *, output_kind: str) -> None:
    """Remove inherited access before a temporary file receives output data."""
    if os.name == "posix":
        # Also masks named-user/group ACL grants on POSIX ACL implementations.
        os.fchmod(descriptor, 0o600)
    if sys.platform != "darwin":
        return

    # macOS extended ACL grants are independent of permission bits. Use the
    # already-open descriptor so clearing them cannot follow a swapped path.
    import ctypes

    try:
        libc = ctypes.CDLL(None, use_errno=True)
        init_acl = libc.acl_init
        set_acl = libc.acl_set_fd_np
        free_acl = libc.acl_free
    except AttributeError:
        # Filesystems/platforms without extended ACL support need only mode bits.
        return
    init_acl.argtypes = [ctypes.c_int]
    init_acl.restype = ctypes.c_void_p
    set_acl.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
    set_acl.restype = ctypes.c_int
    free_acl.argtypes = [ctypes.c_void_p]
    free_acl.restype = ctypes.c_int
    empty_acl = init_acl(0)
    if not empty_acl:
        raise OSError(ctypes.get_errno(), f"Could not initialize {output_kind} ACL")
    try:
        if set_acl(descriptor, empty_acl, 0x100) != 0:  # ACL_TYPE_EXTENDED
            error = ctypes.get_errno()
            if error not in {errno.ENOTSUP, errno.EOPNOTSUPP}:
                raise OSError(error, f"Could not clear inherited {output_kind} ACLs")
    finally:
        free_acl(empty_acl)


@contextmanager
def open_output_parent(path: str | Path) -> Iterator[tuple[Path, int]]:
    """Keep a no-follow parent descriptor open for all operations on an output."""
    require_secure_file_output()
    absolute = _normalize_root_owned_alias(Path(path))
    flags = os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_PATH", os.O_RDONLY)
    directory_fd = None
    try:
        try:
            directory_fd = os.open(absolute.anchor, flags)
            for part in absolute.parts[1:-1]:
                next_fd = os.open(part, flags, dir_fd=directory_fd)
                os.close(directory_fd)
                directory_fd = next_fd
        except OSError as exc:
            if exc.errno in {errno.ELOOP, errno.ENOTDIR}:
                detail = "an output directory is a symlink or is not a directory"
            elif isinstance(exc, FileNotFoundError):
                detail = "the output directory does not exist"
            else:
                detail = exc.strerror or str(exc)
            raise ValueError(
                f"Could not open output directory for {str(path)!r}: {detail}."
            ) from exc
        yield absolute, directory_fd
    finally:
        if directory_fd is not None:
            os.close(directory_fd)


def write_text_no_follow(path: str | Path, text: str) -> None:
    """Atomically replace a regular output through an anchored parent descriptor.

    Files are created privately, including replacements. A final-component swap
    cannot redirect the write; a parent swap cannot change the opened directory.
    Platforms without these guarantees must use explicitly managed stdout.
    """
    temporary_name = None
    try:
        with open_output_parent(path) as (absolute, directory_fd):
            try:
                try:
                    existing = os.stat(absolute.name, dir_fd=directory_fd, follow_symlinks=False)
                except FileNotFoundError:
                    pass
                else:
                    if not S_ISREG(existing.st_mode):
                        raise ValueError(
                            f"Refusing to overwrite non-regular output {str(path)!r} "
                            f"(type {filemode(existing.st_mode)[0]!r})."
                        )
                    descriptor = os.open(
                        absolute.name,
                        os.O_WRONLY | os.O_NONBLOCK | os.O_NOFOLLOW,
                        dir_fd=directory_fd,
                    )
                    try:
                        if not S_ISREG(os.fstat(descriptor).st_mode):
                            raise ValueError(
                                f"Refusing to overwrite non-regular output {str(path)!r}."
                            )
                    finally:
                        os.close(descriptor)
                candidate = f".skillspector-output-{token_hex(16)}"
                fd = os.open(
                    candidate,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                    0o600,
                    dir_fd=directory_fd,
                )
                temporary_name = candidate
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    restrict_temporary_access(stream.fileno(), output_kind="report")
                    stream.write(text)
                os.replace(
                    temporary_name,
                    absolute.name,
                    src_dir_fd=directory_fd,
                    dst_dir_fd=directory_fd,
                )
                temporary_name = None
            finally:
                if temporary_name is not None:
                    try:
                        os.unlink(temporary_name, dir_fd=directory_fd)
                    except FileNotFoundError:
                        pass
    except OSError as exc:
        if exc.errno in {errno.ELOOP, errno.ENOTDIR}:
            detail = "an output directory is a symlink or is not a directory"
        elif isinstance(exc, FileNotFoundError):
            detail = "the output directory does not exist"
        else:
            detail = exc.strerror or str(exc)
        raise ValueError(f"Could not write output {str(path)!r}: {detail}.") from exc
